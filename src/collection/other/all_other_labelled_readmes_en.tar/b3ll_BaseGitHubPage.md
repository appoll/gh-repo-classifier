# Cool Introduction

Add stuff to page.md, done.

Preview [here](http://b3ll.github.io/BaseGitHubPage/)

It's hella cool.

![hella cool](images/hellacool.jpg?raw=true)

# License?

Pretty much the BSD license, just don't repackage it and call it your own please!

Also if you do make some changes, feel free to make a pull request and help make things more awesome!
