This is used as a submodule by white (http://github.com/comex/white) and star (http://github.com/comex/starn).

(What, you wanted to know what it does?)
