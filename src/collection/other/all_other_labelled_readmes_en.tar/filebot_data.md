# FileBot Data Files

* FileBot Forums
  * Tips, Tricks and Tutorials
    * [Add Blacklisted Terms and Improve Movie / Series Detection](https://www.filebot.net/forums/viewtopic.php?f=3&t=359)
    * [Exclude Blacklist & Series-Mappings](https://www.filebot.net/forums/viewtopic.php?f=3&t=360)
  * Episode / Movie Naming Scheme
    * [Release Groups {group}](https://www.filebot.net/forums/viewtopic.php?f=5&t=4)
