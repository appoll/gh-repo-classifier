#大数据/数据挖掘/推荐系统/机器学习相关资源

Share my personal resources 

#书籍

* 各种书~各种ppt~更新中~ <https://pan.baidu.com/s/1c1Xp6Pa>

* 机器学习经典书籍小结 <http://www.cnblogs.com/snake-hand/archive/2013/06/10/3131145.html>

* 机器学习&深度学习经典资料汇总 <http://www.thebigdata.cn/JiShuBoKe/13299.html>

#视频

* 浙大数据挖掘系列 <http://v.youku.com/v_show/id_XNTgzNDYzMjg=.html?f=2740765>

* 用Python做科学计算 <http://www.tudou.com/listplay/fLDkg5e1pYM.html>

* R语言视频 <http://pan.baidu.com/s/1koSpZ>

* Hadoop视频 <http://pan.baidu.com/s/1b1xYd>

* 42区 . 技术 . 创业 . 第二讲 <http://v.youku.com/v_show/id_XMzAyMDYxODUy.html>

* 加州理工学院公开课：机器学习与数据挖掘 <http://v.163.com/special/opencourse/learningfromdata.html>

* William Huang教授--BI和数据挖掘技术 <https://www.youtube.com/watch?v=gPm8SOJ1Nao>

* Jingyuan Wang王静远-北航-机器学习工具在城市数据分析中的应用<https://www.youtube.com/watch?v=H2_BATE8uok>

* Tensor Flow 介紹 (1/2)<https://www.youtube.com/watch?v=jA4Bh-xj_mE>

* Tensor Flow 介紹 (2/2)<https://www.youtube.com/watch?v=YUCsOgkFqpk>

# 课程

### 机器学习

* Machine Learning Stanford University <https://www.coursera.org/learn/machine-learning>

* 機器學習基石 (Machine Learning Foundations) National Taiwan University <https://www.coursera.org/course/ntumlone>

# 会议

### 数据挖掘

* ACM SigKDD <http://www.kdd.org>

* ICDM <http://icdm2015.stonybrook.edu/>

* SIAM <http://www.siam.org/>


#QQ群

* 机器学习&模式识别 246159753

* 数据挖掘机器学习 236347059

* 推荐系统 274750470

#Github	

###推荐系统

* 推荐系统开源软件列表汇总和评点 <http://in.sdo.com/?p=1707>

* Mrec(Python) <https://github.com/mendeley/mrec>

* Crab(Python) <https://github.com/muricoca/crab>

* Python-recsys(Python) <https://github.com/ocelma/python-recsys>

* CofiRank(C++) <https://github.com/markusweimer/cofirank>

* GraphLab(C++) <https://github.com/graphlab-code/graphlab>

* EasyRec(Java) <https://github.com/hernad/easyrec>

* Lenskit(Java) <https://github.com/grouplens/lenskit>

* Mahout(Java) <https://github.com/apache/mahout>

* Recommendable(Ruby) <https://github.com/davidcelis/recommendable>

###库

* NLTK  <https://github.com/nltk/nltk>

* Pattern <https://github.com/clips/pattern>

* Pyrallel <https://github.com/pydata/pyrallel>

* Theano <https://github.com/Theano/Theano>

* Pylearn2 <https://github.com/lisa-lab/pylearn2>

* TextBlob <https://github.com/sloria/TextBlob>

* MBSP <https://github.com/clips/MBSP>

* Gensim <https://github.com/piskvorky/gensim>

* Langid.py <https://github.com/saffsd/langid.py>

* Jieba <https://github.com/fxsjy/jieba>

* xTAS <https://github.com/NLeSC/xtas>

* NumPy <https://github.com/numpy/numpy>

* SciPy <https://github.com/scipy/scipy>

* Matplotlib <https://github.com/matplotlib/matplotlib>

* scikit-learn <https://github.com/scikit-learn/scikit-learn>

* Pandas <https://github.com/pydata/pandas>

* MDP <http://mdp-toolkit.sourceforge.net/>

* PyBrain <https://github.com/pybrain/pybrain>

* PyML <http://pyml.sourceforge.net/>

* Milk <https://github.com/luispedro/milk>

* PyMVPA <https://github.com/PyMVPA/PyMVPA>

* TensorFlow <https://github.com/tensorflow/tensorflow>

# 博客

* 周涛 <http://blog.sciencenet.cn/home.php?mod=space&uid=3075>

* Greg Linden <http://glinden.blogspot.com/> 

* Marcel Caraciolo   <http://aimotion.blogspot.com/>

* RsysChina 	  <http://weibo.com/p/1005051686952981>

* 推荐系统人人小站	<http://zhan.renren.com/recommendersystem>

* 阿稳	<http://www.wentrue.net>

* 梁斌	<http://weibo.com/pennyliang>

* 刁瑞	<http://diaorui.net>

* guwendong <http://www.guwendong.com>

* xlvector <http://xlvector.net>

* 懒惰啊我 <http://www.cnblogs.com/flclain/>

* free mind <http://blog.pluskid.org/>

* lovebingkuai	<http://lovebingkuai.diandian.com/>

* LeftNotEasy <http://www.cnblogs.com/LeftNotEasy>

* LSRS 2013 <http://graphlab.org/lsrs2013/program/> 

* Google小组 <https://groups.google.com/forum/#!forum/resys>

* Journal of Machine Learning Research <http://jmlr.org/>

* 在线的机器学习社区 <http://www.52ml.net/16336.html>

* 清华大学信息检索组 <http://www.thuir.cn>

* 我爱自然语言处理 <http://www.52nlp.cn/>

* 数据挖掘与数据分析<http://spss-market.r.blog.163.com/>


#文章

* 心中永远的正能量  <http://blog.csdn.net/yunlong34574>

* 机器学习最佳入门学习资料汇总 <http://article.yeeyan.org/view/22139/410514>

* Books for Machine Learning with R <http://www.52ml.net/16312.html>

* 是什么阻碍了你的机器学习目标？ <http://www.52ml.net/16436.htm>

* 推荐系统初探 <http://yongfeng.me/attach/rs-survey-zhang-slices.pdf>

* 推荐系统中协同过滤算法若干问题的研究 <http://pan.baidu.com/s/1bnjDBYZ>

* Netflix 推荐系统：第一部分 <http://blog.csdn.net/bornhe/article/details/8222450>

* Netflix 推荐系统：第二部分 <http://blog.csdn.net/bornhe/article/details/8222497>

* 探索推荐引擎内部的秘密	<http://www.ibm.com/developerworks/cn/web/1103_zhaoct_recommstudy1/index.html>

* 推荐系统resys小组线下活动见闻2009-08-22	<http://www.tuicool.com/articles/vUvQVn>

* Recommendation Engines Seminar Paper, Thomas Hess, 2009: 推荐引擎的总结性文章 <http://www.slideshare.net/antiraum/recommender-engines-seminar-paper>

* Toward the Next Generation of Recommender Systems: A Survey of the State-of-the-Art and Possible Extensions, Adomavicius, G.; Tuzhilin, A., 2005 	<http://dl.acm.org/citation.cfm?id=1070751>

* A Taxonomy of RecommenderAgents on the Internet, Montaner, M.; Lopez, B.; de la Rosa, J. L., 2003 <http://www.springerlink.com/index/KK844421T5466K35.pdf>

* A Course in Machine Learning <http://ciml.info/>

* 基于mahout构建社会化推荐引擎  <http://www.doc88.com/p-745821989892.html>

* 个性化推荐技术漫谈 <http://blog.csdn.net/java060515/archive/2007/04/19/1570243.aspx>

* Design of Recommender System <http://www.slideshare.net/rashmi/design-of-recommender-systems>

* How to build a recommender system	<http://www.slideshare.net/blueace/how-to-build-a-recommender-system-presentation>

* 推荐系统架构小结  <http://blog.csdn.net/idonot/article/details/7996733>

* System Architectures for Personalization and Recommendation <http://techblog.netflix.com/2013/03/system-architectures-for.html>

* The Netflix Tech Blog <http://techblog.netflix.com/>

* 百分点推荐引擎——从需求到架构<http://www.infoq.com/cn/articles/baifendian-recommendation-engine>

* 推荐系统 在InfoQ上的内容  <http://www.infoq.com/cn/recommend>

* 推荐系统实时化的实践和思考 <http://www.infoq.com/cn/presentations/recommended-system-real-time-practice-thinking>

* 质量保证的推荐实践  <http://www.infoq.com/cn/news/2013/10/testing-practice/> 
 
* 推荐系统的工程挑战  <http://www.infoq.com/cn/presentations/Recommend-system-engineering>

* 社会化推荐在人人网的应用  <http://www.infoq.com/cn/articles/zyy-social-recommendation-in-renren/>

* 利用20%时间开发推荐引擎  <http://www.infoq.com/cn/presentations/twenty-percent-time-to-develop-recommendation-engine>

* 使用Hadoop和 Mahout实现推荐引擎 <http://www.jdon.com/44747>

* SVD 简介 <http://www.cnblogs.com/FengYan/archive/2012/05/06/2480664.html>

* Netflix推荐系统：从评分预测到消费者法则 <http://blog.csdn.net/lzt1983/article/details/7696578>

* 关于数据挖掘学习的讨论<https://www.zhihu.com/question/20751219>

# 论文

《推荐系统实战》引用

* [P1](http://en.wikipedia.org/wiki/Information_overload)
	
* [A Guide to Recommender System P4](http://www.readwriteweb.com/archives/recommender_systems.php)
	
* [Cross Selling P6](http://en.wikipedia.org/wiki/Cross-selling)
	
* [课程：Data Mining and E-Business: The Social Data Revolution P7)](http://stanford2009.wikispaces.com/ )
	
* [An Introduction to Search Engines and Web Navigation p7](http://thesearchstrategy.com/ebooks/an%20introduction%20to%20search%20engines%20and%20web%20navigation.pdf)
　　
* [p8](http://www.netflixprize.com/)

* [p9](http://cdn-0.nflximg.com/us/pdf/Consumer_Press_Kit.pdf)

* [(The Youtube video recommendation system) p9](http://stuyresearch.googlecode.com/hg-history/c5aa9d65d48c787fd72dcd0ba3016938312102bd/blake/resources/p293-davidson.pdf)
　　 
* [(PPT: Music Recommendation and Discovery) p12](http://www.slideshare.net/plamere/music-recommendation-and-discovery)

* [P13](http://www.facebook.com/instantpersonalization/)
　　 
* [(Digg Recommendation Engine Updates) P16](http://about.digg.com/blog/digg-recommendation-engine-updates)

* [(The Learning Behind Gmail Priority Inbox)p17](http://static.googleusercontent.com/external_content/untrusted_dlcp/research.google.com/en//pubs/archive/36955.pdf)
　　 
* [(Accurate is not always good: How Accuracy Metrics have hurt Recommender Systems) P20](http://www.grouplens.org/papers/pdf/mcnee-chi06-acc.pdf)
 
* [(Don’t Look Stupid: Avoiding Pitfalls when Recommending Research Papers)P23](http://www-users.cs.umn.edu/~mcnee/mcnee-cscw2006.pdf)
　　  
* [(Major componets of the gravity recommender system) P25](http://www.sigkdd.org/explorations/issues/9-2-2007-12/7-Netflix-2.pdf)
	
* [(What is a Good Recomendation Algorithm?) P26](http://cacm.acm.org/blogs/blog-cacm/22925-what-is-a-good-recommendation-algorithm/fulltext)

* [(Evaluation Recommendation Systems) P27](http://research.microsoft.com/pubs/115396/evaluationmetrics.tr.pdf )
　　  
* [(Music Recommendation and Discovery in the Long Tail) P29](http://mtg.upf.edu/static/media/PhD_ocelma.pdf)
　　 
* [(Internation Workshop on Novelty and Diversity in Recommender Systems) p29](http://ir.ii.uam.es/divers2011/)

* [(Auralist: Introducing Serendipity into Music Recommendation ) P30](http://www.cs.ucl.ac.uk/fileadmin/UCL-CS/research/Research_Notes/RN_11_21.pdf)
　　 
* [(Metrics for evaluating the serendipity of recommendation lists) P30](http://www.springerlink.com/content/978-3-540-78196-7/#section=239197&page=1&locus=21)
	
* [(The effects of transparency on trust in and acceptance of a content-based art recommender) P31](http://dare.uva.nl/document/131544) 
　　 
* [(Trust-aware recommender systems) P31](http://brettb.net/project/papers/2007%20Trust-aware%20recommender%20systems.pdf)
	
* [(Tutorial on robutness of recommender system) P32](http://recsys.acm.org/2011/pdfs/RobustTutorial.pdf)
	
* [(Five Stars Dominate Ratings) P37 ](http://youtube-global.blogspot.com/2009/09/five-stars-dominate-ratings.html)

* [(Book-Crossing Dataset) P38 ](http://www.informatik.uni-freiburg.de/~cziegler/BX/)

* [(Lastfm Dataset) P39](http://www.dtic.upf.edu/~ocelma/MusicRecommendationDataset/lastfm-1K.html)
　　 
* [浅谈网络世界的Power Law现象 P39](http://mmdays.com/2008/11/22/power_law_1/) 

* [(MovieLens Dataset) P42](http://www.grouplens.org/node/73/)

* [(Empirical Analysis of Predictive Algorithms for Collaborative Filtering) P49](http://research.microsoft.com/pubs/69656/tr-98-12.pdf)

* [(Digg Vedio) P50](http://vimeo.com/1242909)

* [(Amazon.com Recommendations Item-to-Item Collaborative Filtering) P59](http://www.cs.umd.edu/~samir/498/Amazon-Recommendations.pdf) 
	
* [(Greg Linden Blog) P63](http://glinden.blogspot.com/2006/03/early-amazon-similarities.html)

* [(One-Class Collaborative Filtering) P67](http://www.hpl.hp.com/techreports/2008/HPL-2008-48R1.pdf)

* [(Stochastic Gradient Descent) P68 ](http://en.wikipedia.org/wiki/Stochastic_gradient_descent)

* [(Latent Factor Models for Web Recommender Systems) P70 ](http://www.ideal.ece.utexas.edu/seminar/LatentFactorModels.pdf)

* [(Bipatite Graph) P73](http://en.wikipedia.org/wiki/Bipartite_graph)

* [(Random-Walk Computation of Similarities between Nodes of a Graph with Application to Collaborative Recommendation) P74](http://ieeexplore.ieee.org/xpl/login.jsp?tp=&arnumber=4072747&url=http%3A%2F%2Fieeexplore.ieee.org%2Fxpls%2Fabs_all.jsp%3Farnumber%3D4072747)

* [(Topic Sensitive Pagerank) P74](http://www-cs-students.stanford.edu/~taherh/papers/topic-sensitive-pagerank.pdf) 

* [(FAST ALGORITHMS FOR SPARSE MATRIX INVERSE COMPUTATIONS) P77](http://www.stanford.edu/dept/ICME/docs/thesis/Li-2009.pdf)

* [(LIFESTYLE FINDER: Intelligent User Profiling Using Large-Scale Demographic Data) P80](https://www.aaai.org/ojs/index.php/aimagazine/article/view/1292)

* [( adaptive bootstrapping of recommender systems using decision trees) P87](http://research.yahoo.com/files/wsdm266m-golbandi.pdf) 

* [(Vector Space Model) P90](http://en.wikipedia.org/wiki/Vector_space_model)

* [(冷启动问题的比赛) P92](http://tunedit.org/challenge/VLNetChallenge )

* [(Latent Dirichlet Allocation) P92](http://www.cs.princeton.edu/~blei/papers/BleiNgJordan2003.pdf)

* [(Kullback–Leibler divergence) P93](http://en.wikipedia.org/wiki/Kullback%E2%80%93Leibler_divergence)

* [(About The Music Genome Project) P94](http://www.pandora.com/about/mgp)

* [(Pandora Music Genome Project Attributes) P94](http://en.wikipedia.org/wiki/List_of_Music_Genome_Project_attributes )

* [(Jinni Movie Genome) P94](http://www.jinni.com/movie-genome.html) 

* [(Tagsplanations: Explaining Recommendations Using Tags) P96](http://www.shilad.com/papers/tagsplanations_iui2009.pdf)

* [(Tag Wikipedia) P96](http://en.wikipedia.org/wiki/Tag_(metadata))

* [(Nurturing Tagging Communities) P100](http://www.shilad.com/shilads_thesis.pdf )

* [(Why We Tag: Motivations for Annotation in Mobile and Online Media ) P100](http://www.stanford.edu/~morganya/research/chi2007-tagging.pdf )

* [(Delicious Dataset) P101](http://www.google.com/url?sa=t&rct=j&q=delicious%20dataset%20dai-larbor&amp;source=web&cd=1&ved=0CFIQFjAA&url=http%3A%2F%2Fwww.dai-labor.de%2Fen%2Fcompetence_centers%2Firml%2Fdatasets%2F&ei=1R4JUKyFOKu0iQfKvazzCQ&;usg=AFQjCNGuVzzKIKi3K2YFybxrCNxbtKqS4A&amp;cad=rjt)

* [(Finding Advertising Keywords on Web Pages) P118](http://research.microsoft.com/pubs/73692/yihgoca-www06.pdf )

* [(基于标签的推荐系统比赛) P119](http://www.kde.cs.uni-kassel.de/ws/rsdc08/ )

* [(Tag recommendations based on tensor dimensionality reduction）P119](http://delab.csd.auth.gr/papers/recsys.pdf)

* [(latent dirichlet allocation for tag recommendation) P119](http://www.l3s.de/web/upload/documents/1/recSys09.pdf)

* [(Folkrank: A ranking algorithm for folksonomies) P119](http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.94.5271&rep=rep1&amp;type=pdf) 

* [(Tagommenders: Connecting Users to Items through Tags) P119](http://www.grouplens.org/system/files/tagommenders_numbered.pdf) 

* [(The Quest for Quality Tags) P120](http://www.grouplens.org/system/files/group07-sen.pdf)

* [(Challenge on Context-aware Movie Recommendation) P123](http://2011.camrachallenge.com/)

* [(The Lifespan of a link) P125](http://bits.blogs.nytimes.com/2011/09/07/the-lifespan-of-a-link/ )

* [(Temporal Diversity in Recommender Systems) P129](http://www0.cs.ucl.ac.uk/staff/l.capra/publications/lathia_sigir10.pdf )

* [(Evaluating Collaborative Filtering Over Time) P129](http://staff.science.uva.nl/~kamps/ireval/papers/paper_14.pdf )

* [(Hotpot) P139 ](http://www.google.com/places/ )

* [(Google Launches Hotpot, A Recommendation Engine for Places) P139](http://www.readwriteweb.com/archives/google_launches_recommendation_engine_for_places.php) 

* [(geolocated recommendations) P140](http://xavier.amatriain.net/pubs/GeolocatedRecommendations.pdf )

* [(A Peek Into Netflix Queues) P141](http://www.nytimes.com/interactive/2010/01/10/nyregion/20100110-netflix-map.html )

* [(Distance Browsing in Spatial Databases1) P142](http://www.cs.umd.edu/users/meesh/420/neighbor.pdf )

* [(Efﬁcient Evaluation of k-Range Nearest Neighbor Queries in Road Networks) P143](http://www.eng.auburn.edu/~weishinn/papers/MDM2010.pdf )

* [(Global Advertising: Consumers Trust Real Friends and Virtual Strangers the Most) P144 ](http://blog.nielsen.com/nielsenwire/consumer/global-advertising-consumers-trust-real-friends-and-virtual-strangers-the-most/ )

* [(Suggesting Friends Using the Implicit Social Graph) P145](http://static.googleusercontent.com/external_content/untrusted_dlcp/research.google.com/en//pubs/archive/36371.pdf )

* [(Friends & Frenemies: Why We Add and Remove Facebook Friends) P147](http://blog.nielsen.com/nielsenwire/online_mobile/friends-frenemies-why-we-add-and-remove-facebook-friends/ )

* [(Stanford Large Network Dataset Collection) P149 ](http://snap.stanford.edu/data/ )

* [(Workshop on Context-awareness in Retrieval and Recommendation) P151](http://www.dai-labor.de/camra2010/ )

* [(Factorization vs. Regularization: Fusing Heterogeneous Social Relationships in Top-N Recommendation) P153 ](http://www.comp.hkbu.edu.hk/~lichen/download/p245-yuan.pdf )

* [(Twitter, an Evolving Architecture) P154](http://www.infoq.com/news/2009/06/Twitter-Architecture/ )

* [(Recommendations in taste related domains) P155](http://www.google.com/url?sa=t&rct=j&q=&esrc=s&amp;source=web&cd=2&ved=0CGQQFjAB&url=http%3A%2F%2Fciteseerx.ist.psu.edu%2Fviewdoc%2Fdownload%3Fdoi%3D10.1.1.165.3679%26rep%3Drep1%26type%3Dpdf&ei=dIIJUMzEE8WviQf5tNjcCQ&usg=AFQjCNGw2bHXJ6MdYpksL66bhUE8krS41w&sig2=5EcEDhRe9S5SQNNojWk7_Q )

* [(Comparing Recommendations Made by Online Systems and Friends) P155](http://www.ercim.eu/publication/ws-proceedings/DelNoe02/RashmiSinha.pdf) 

* [(EdgeRank: The Secret Sauce That Makes Facebook's News Feed Tick) P157](http://techcrunch.com/2010/04/22/facebook-edgerank/ )

* [(Speak Little and Well: Recommending Conversations in Online Social Streams) P158](http://www.grouplens.org/system/files/p217-chen.pdf )

* [(Learn more about “People You May Know”) P160](http://blog.linkedin.com/2008/04/11/learn-more-abou-2/ )

* [("Make New Friends, but Keep the Old" – Recommending People on Social Networking Sites) P164 ](http://domino.watson.ibm.com/cambridge/research.nsf/58bac2a2a6b05a1285256b30005b3953/8186a48526821924852576b300537839/$FILE/TR%202009.09%20Make%20New%20Frends.pdf) 

* [(SoRec: Social Recommendation Using Probabilistic Matrix) P165 ](http://www.google.com.hk/url?sa=t&rct=j&q=social+recommendation+using+prob&source=web&amp;cd=2&ved=0CFcQFjAB&url=http%3A%2F%2Fciteseerx.ist.psu.edu%2Fviewdoc%2Fdownload%3Fdoi%3D10.1.1.141.465%26rep%3Drep1%26type%3Dpdf&amp;ei=LY0JUJ7OL9GPiAfe8ZzyCQ&usg=AFQjCNH-xTUWrs9hkxTA8si5fztAdDAEng)

* [(A Dynamic Bayesian Network Click Model for Web Search Ranking) P177](http://olivier.chapelle.cc/pub/DBN_www2009.pdf )

* [(Online Learning from Click Data for Sponsored Search) P177](http://www.google.com.hk/url?sa=t&rct=j&q=online+learning+from+click+data+spnsored+search&amp;source=web&cd=1&ved=0CFkQFjAA&amp;url=http%3A%2F%2Fwww.research.yahoo.net%2Ffiles%2Fp227-ciaramita.pdf&ei=HY8JUJW8CrGuiQfpx-XyCQ&usg=AFQjCNE_CYbEs8DVo84V-0VXs5FeqaJ5GQ&cad=rjt)

* [(Contextual Advertising by Combining Relevance with Click Feedback) P177 ](http://www.cs.cmu.edu/~deepay/mywww/papers/www08-interaction.pdf) 

* [(Hulu 推荐系统架构) P178](http://tech.hulu.com/blog/2011/09/19/recommendation-system/ )

* [(MyMedia Project) P178](http://mymediaproject.codeplex.com/)

* [(item-based collaborative filtering recommendation algorithms) P185](http://www.grouplens.org/papers/pdf/www10_sarwar.pdf )

* [(Learning Collaborative Information Filters) P186 ](http://www.stanford.edu/~koutrika/Readings/res/Default/billsus98learning.pdf )
	
* [(Simon Funk Blog:Funk SVD) P187 ](http://sifter.org/~simon/journal/20061211.html )

* [(Factor in the Neighbors: Scalable and Accurate Collaborative Filtering) P190 ](http://courses.ischool.berkeley.edu/i290-dm/s11/SECURE/a1-koren.pdf )

* [(Time-dependent Models in Collaborative Filtering based Recommender System) P193 ](http://nlpr-web.ia.ac.cn/2009papers/gjhy/gh26.pdf )

* [(Collaborative filtering with temporal dynamics) P193](http://sydney.edu.au/engineering/it/~josiah/lemma/kdd-fp074-koren.pdf )

* [(Least Squares Wikipedia) P195](http://en.wikipedia.org/wiki/Least_squares )

* [(Improving regularized singular value decomposition for collaborative filtering) P195](http://www.mimuw.edu.pl/~paterek/ap_kdd.pdf )

* [(Factorization Meets the Neighborhood: a Multifaceted Collaborative Filtering Model) P195](http://public.research.att.com/~volinsky/netflix/kdd08koren.pdf )
　　  


<p style="line-height:16px;">
    
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90ACM%20RecSys%202009%20Workshop%E3%80%91Improving%20recommendation%20accuracy%20by%20clustering%20so.pdf&amp;id=37991"
    target="_blank">
        
    </a>
</p>
                
<p style="line-height:16px;">
    
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90CIKM%202012%20Best%20Stu%20Paper%E3%80%91Incorporating%20Occupancy%20into%20Frequent%20Pattern%20Mini.pdf&amp;id=37992"
    target="_blank">
        【CIKM 2012 Best Stu Paper】Incorporating Occupancy into Frequent Pattern
        Mini.pdf
    </a>
</p>
<p style="line-height:16px;">
   
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90CIKM%202012%20poster%E3%80%91A%20Latent%20Pairwise%20Preference%20Learning%20Approach%20for%20Recomme.pdf&amp;id=37993"
    target="_blank">
        【CIKM 2012 poster】A Latent Pairwise Preference Learning Approach for Recomme.pdf
    </a>
</p>
<p style="line-height:16px;">
    
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90CIKM%202012%20poster%E3%80%91An%20Effective%20Category%20Classification%20Method%20Based%20on%20a%20Lan.pdf&amp;id=37994"
    target="_blank">
        【CIKM 2012 poster】An Effective Category Classification Method Based on
        a Lan.pdf
    </a>
</p>
<p style="line-height:16px;">
    
   <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90CIKM%202012%20poster%E3%80%91Learning%20to%20Rank%20for%20Hybrid%20Recommendation.pdf&amp;id=37995"
    target="_blank">
        【CIKM 2012 poster】Learning to Rank for Hybrid Recommendation.pdf
    </a>
</p>
<p style="line-height:16px;">
    
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90CIKM%202012%20poster%E3%80%91Learning%20to%20Recommend%20with%20Social%20Relation%20Ensemble.pdf&amp;id=37996"
    target="_blank">
        【CIKM 2012 poster】Learning to Recommend with Social Relation Ensemble.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90CIKM%202012%20poster%E3%80%91Maximizing%20Revenue%20from%20Strategic%20Recommendations%20under%20De.pdf&amp;id=37997"
    target="_blank">
        【CIKM 2012 poster】Maximizing Revenue from Strategic Recommendations under
        De.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90CIKM%202012%20poster%E3%80%91On%20Using%20Catexperts%20for%20Improving%20the%20Performance%20an.pdf&amp;id=37998"
    target="_blank">
        【CIKM 2012 poster】On Using Category Experts for Improving the Performance
        an.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90CIKM%202012%20poster%E3%80%91Relation%20Regularized%20Subspace%20Recommending%20for%20Related%20Sci.pdf&amp;id=37999"
    target="_blank">
        【CIKM 2012 poster】Relation Regularized Subspace Recommending for Related
        Sci.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90CIKM%202012%20poster%E3%80%91Top-N%20Recommendation%20through%20Belief%20Propagation.pdf&amp;id=38000"
    target="_blank">
        【CIKM 2012 poster】Top-N Recommendation through Belief Propagation.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90CIKM%202012%20poster%E3%80%91Twitter%20Hyperlink%20Recommendation%20with%20User-Tweet-Hyperlink.pdf&amp;id=38001"
    target="_blank">
        【CIKM 2012 poster】Twitter Hyperlink Recommendation with User-Tweet-Hyperlink.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90CIKM%202012%20short%E3%80%91Automatic%20Query%20Expansion%20Based%20on%20Tag%20Recommendation.pdf&amp;id=38002"
    target="_blank">
        【CIKM 2012 short】Automatic Query Expansion Based on Tag Recommendation.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90CIKM%202012%20short%E3%80%91Graph-Based%20Workflow%20Recommendation-%20On%20Improving%20Business%20.pdf&amp;id=38003"
    target="_blank">
        【CIKM 2012 short】Graph-Based Workflow Recommendation- On Improving Business
        .pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90CIKM%202012%20short%E3%80%91Location-Sensitive%20Resources%20Recommendation%20in%20Social%20Taggi.pdf&amp;id=38004"
    target="_blank">
        【CIKM 2012 short】Location-Sensitive Resources Recommendation in Social
        Taggi.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90CIKM%202012%20short%E3%80%91More%20Than%20Relevance-%20High%20Utility%20Query%20Recommendation%20By%20M.pdf&amp;id=38005"
    target="_blank">
        【CIKM 2012 short】More Than Relevance- High Utility Query Recommendation
        By M.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90CIKM%202012%20short%E3%80%91PathRank-%20A%20Novel%20Node%20Ranking%20Measure%20on%20a%20Heterogeneous%20G.pdf&amp;id=38006"
    target="_blank">
        【CIKM 2012 short】PathRank- A Novel Node Ranking Measure on a Heterogeneous
        G.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90CIKM%202012%20short%E3%80%91PRemiSE-%20Personalized%20News%20Recommendation%20via%20Implicit%20Soci.pdf&amp;id=38007"
    target="_blank">
        【CIKM 2012 short】PRemiSE- Personalized News Recommendation via Implicit
        Soci.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90CIKM%202012%20short%E3%80%91Query%20Recommendation%20for%20Children.pdf&amp;id=38008"
    target="_blank">
        【CIKM 2012 short】Query Recommendation for Children.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90CIKM%202012%20short%E3%80%91The%20Early-Adopter%20Graph%20and%20its%20Application%20to%20Web-Page%20Rec.pdf&amp;id=38009"
    target="_blank">
        【CIKM 2012 short】The Early-Adopter Graph and its Application to Web-Page
        Rec.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90CIKM%202012%20short%E3%80%91Time-aware%20Topic%20Recommendation%20Based%20on%20Micro-blogs.pdf&amp;id=38010"
    target="_blank">
        【CIKM 2012 short】Time-aware Topic Recommendation Based on Micro-blogs.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90CIKM%202012%20short%E3%80%91Using%20Program%20Synthesis%20for%20Social%20Recommendations.pdf&amp;id=38011"
    target="_blank">
        【CIKM 2012 short】Using Program Synthesis for Social Recommendations.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90CIKM%202012%E3%80%91A%20Decentralized%20Recommender%20System%20for%20Effective%20Web%20Credibility%20.pdf&amp;id=38012"
    target="_blank">
        【CIKM 2012】A Decentralized Recommender System for Effective Web Credibility
        .pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90CIKM%202012%E3%80%91A%20Generalized%20Framework%20for%20Reciprocal%20Recommender%20Systems.pdf&amp;id=38013"
    target="_blank">
        【CIKM 2012】A Generalized Framework for Reciprocal Recommender Systems.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90CIKM%202012%E3%80%91Dynamic%20Covering%20for%20Recommendation%20Systems.pdf&amp;id=38014"
    target="_blank">
        【CIKM 2012】Dynamic Covering for Recommendation Systems.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90CIKM%202012%E3%80%91Efficient%20Retri.%20of%20Recommendations%20in%20a%20Matrix%20Factorization%20.pdf&amp;id=38015"
    target="_blank">
        【CIKM 2012】Efficient Retrieval of Recommendations in a Matrix Factorization
        .pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90CIKM%202012%E3%80%91Exploring%20Personal%20Impact%20for%20Group%20Recommendation.pdf&amp;id=38016"
    target="_blank">
        【CIKM 2012】Exploring Personal Impact for Group Recommendation.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90CIKM%202012%E3%80%91LogUCB-%20An%20Explore-Exploit%20Algorithm%20For%20Comments%20Recommendation.pdf&amp;id=38017"
    target="_blank">
        【CIKM 2012】LogUCB- An Explore-Exploit Algorithm For Comments Recommendation.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90CIKM%202012%E3%80%91Metaphor-%20A%20System%20for%20Related%20Search%20Recommendations.pdf&amp;id=38018"
    target="_blank">
        【CIKM 2012】Metaphor- A System for Related Search Recommendations.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90CIKM%202012%E3%80%91Social%20Contextual%20Recommendation.pdf&amp;id=38019"
    target="_blank">
        【CIKM 2012】Social Contextual Recommendation.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90CIKM%202012%E3%80%91Social%20Recommendation%20Across%20Multiple%20Relational%20Domains.pdf&amp;id=38020"
    target="_blank">
        【CIKM 2012】Social Recommendation Across Multiple Relational Domains.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90COMMUNICATIONS%20OF%20THE%20ACM%E3%80%91Recommender%20Systems.pdf&amp;id=38021"
    target="_blank">
        【COMMUNICATIONS OF THE ACM】Recommender Systems.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90ICDM%202012%20short___%E3%80%91Multiplicative%20Algorithms%20for%20Constrained%20Non-negative%20M.pdf&amp;id=38022"
    target="_blank">
        【ICDM 2012 short___】Multiplicative Algorithms for Constrained Non-negative
        M.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90ICDM%202012%20short%E3%80%91Collaborative%20Filtering%20with%20Aspect-based%20Opinion%20Mining-%20A.pdf&amp;id=38023"
    target="_blank">
        【ICDM 2012 short】Collaborative Filtering with Aspect-based Opinion Mining-
        A.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90ICDM%202012%20short%E3%80%91Learning%20Heterogeneous%20Similarity%20Measures%20for%20Hybrid-Recom.pdf&amp;id=38024"
    target="_blank">
        【ICDM 2012 short】Learning Heterogeneous Similarity Measures for Hybrid-Recom.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90ICDM%202012%20short%E3%80%91Mining%20Personal%20Context-Aware%20Preferences%20for%20Mobile%20Users.pdf&amp;id=38025"
    target="_blank">
        【ICDM 2012 short】Mining Personal Context-Aware Preferences for Mobile
        Users.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90ICDM%202012%E3%80%91Link%20Prediction%20and%20Recommendation%20across%20Heterogenous%20Social%20Networks.pdf&amp;id=38026"
    target="_blank">
        【ICDM 2012】Link Prediction and Recommendation across Heterogenous Social
        Networks.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90IEEE%20Computer%20Society%202009%E3%80%91Matrix%20factorization%20techniques%20for%20recommender%20.pdf&amp;id=38027"
    target="_blank">
        【IEEE Computer Society 2009】Matrix factorization techniques for recommender
        .pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90IEEE%20Consumer%20Communications%20and%20Networking%20Conference%202006%E3%80%91FilmTrust%20movie.pdf&amp;id=38028"
    target="_blank">
        【IEEE Consumer Communications and Networking Conference 2006】FilmTrust
        movie.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90IEEE%20Trans%20on%20Audio%2C%20Speech%20and%20Laguage%20Processing%202010%E3%80%91Personalized%20music%20.pdf&amp;id=38029"
    target="_blank">
        【IEEE Trans on Audio, Speech and Laguage Processing 2010】Personalized
        music .pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90IEEE%20Transactions%20on%20Knowledge%20and%20Data%20Engineering%202005%E3%80%91Toward%20the%20next%20ge.pdf&amp;id=38030"
    target="_blank">
        【IEEE Transactions on Knowledge and Data Engineering 2005】Toward the next
        ge.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90INFOCOM%202011%E3%80%91Bayesian-inference%20Based%20Recommendation%20in%20Online%20Social%20Network.pdf&amp;id=38031"
    target="_blank">
        【INFOCOM 2011】Bayesian-inference Based Recommendation in Online Social
        Network.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90KDD%202009%E3%80%91Learning%20optimal%20ranking%20with%20tensor%20factorization%20for%20tag%20recomme.pdf&amp;id=38032"
    target="_blank">
        【KDD 2009】Learning optimal ranking with tensor factorization for tag recomme.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90SIGIR%202009%E3%80%91Learning%20to%20Recommend%20with%20Social%20Trust%20Ensemble.pdf&amp;id=38033"
    target="_blank">
        【SIGIR 2009】Learning to Recommend with Social Trust Ensemble.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90SIGIR%202012%E3%80%91Adaptive%20Diversification%20of%20Recommendation%20Results%20via%20Latent%20Fa.pdf&amp;id=38034"
    target="_blank">
        【SIGIR 2012】Adaptive Diversification of Recommendation Results via Latent
        Fa.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90SIGIR%202012%E3%80%91Collaborative%20Personalized%20Tweet%20Recommendation.pdf&amp;id=38035"
    target="_blank">
        【SIGIR 2012】Collaborative Personalized Tweet Recommendation.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90SIGIR%202012%E3%80%91Dual%20Role%20Model%20for%20Question%20Recommendation%20in%20Community%20Questio.pdf&amp;id=38036"
    target="_blank">
        【SIGIR 2012】Dual Role Model for Question Recommendation in Community Questio.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90SIGIR%202012%E3%80%91Exploring%20Social%20Influence%20for%20Recommendation%20-%20A%20Generative%20Mod.pdf&amp;id=38037"
    target="_blank">
        【SIGIR 2012】Exploring Social Influence for Recommendation - A Generative
        Mod.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90SIGIR%202012%E3%80%91Increasing%20Temporal%20Diversity%20with%20Purchase%20Intervals.pdf&amp;id=38038"
    target="_blank">
        【SIGIR 2012】Increasing Temporal Diversity with Purchase Intervals.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90SIGIR%202012%E3%80%91Learning%20to%20Rank%20Social%20Update%20Streams.pdf&amp;id=38039"
    target="_blank">
        【SIGIR 2012】Learning to Rank Social Update Streams.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90SIGIR%202012%E3%80%91Personalized%20Click%20Shaping%20through%20Lagrangian%20Duality%20for%20Online.pdf&amp;id=38040"
    target="_blank">
        【SIGIR 2012】Personalized Click Shaping through Lagrangian Duality for
        Online.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90SIGIR%202012%E3%80%91Predicting%20the%20Ratings%20of%20Multimedia%20Items%20for%20Making%20Personaliz.pdf&amp;id=38041"
    target="_blank">
        【SIGIR 2012】Predicting the Ratings of Multimedia Items for Making Personaliz.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90SIGIR%202012%E3%80%91TFMAP-Optimizing%20MAP%20for%20Top-N%20Context-aware%20Recommendation.pdf&amp;id=38042"
    target="_blank">
        【SIGIR 2012】TFMAP-Optimizing MAP for Top-N Context-aware Recommendation.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90SIGIR%202012%E3%80%91What%20Reviews%20are%20Satisfactory-%20Novel%20Features%20for%20Automatic%20Help.pdf&amp;id=38043"
    target="_blank">
        【SIGIR 2012】What Reviews are Satisfactory- Novel Features for Automatic
        Help.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90SIGKDD%202012%E3%80%91%20A%20Semi-Supervised%20Hybrid%20Shilling%20Attack%20Detector%20for%20Trustwor.pdf&amp;id=38044"
    target="_blank">
        【SIGKDD 2012】 A Semi-Supervised Hybrid Shilling Attack Detector for Trustwor.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90SIGKDD%202012%E3%80%91%20RecMax-%20Exploiting%20Recommender%20Systems%20for%20Fun%20and%20Profit.pdf&amp;id=38045"
    target="_blank">
        【SIGKDD 2012】 RecMax- Exploiting Recommender Systems for Fun and Profit.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90SIGKDD%202012%E3%80%91Circle-based%20Recommendation%20in%20Online%20Social%20Networks.pdf&amp;id=38046"
    target="_blank">
        【SIGKDD 2012】Circle-based Recommendation in Online Social Networks.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90SIGKDD%202012%E3%80%91Cross-domain%20Collaboration%20Recommendation.pdf&amp;id=38047"
    target="_blank">
        【SIGKDD 2012】Cross-domain Collaboration Recommendation.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90SIGKDD%202012%E3%80%91Finding%20Trending%20Local%20Topics%20in%20Search%20Queries%20for%20Personaliza.pdf&amp;id=38048"
    target="_blank">
        【SIGKDD 2012】Finding Trending Local Topics in Search Queries for Personaliza.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90SIGKDD%202012%E3%80%91GetJar%20Mobile%20Application%20Recommendations%20with%20Very%20Sparse%20Datasets.pdf&amp;id=38049"
    target="_blank">
        【SIGKDD 2012】GetJar Mobile Application Recommendations with Very Sparse
        Datasets.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90SIGKDD%202012%E3%80%91Incorporating%20Heterogenous%20Information%20for%20Personalized%20Tag%20Rec.pdf&amp;id=38050"
    target="_blank">
        【SIGKDD 2012】Incorporating Heterogenous Information for Personalized Tag
        Rec.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90SIGKDD%202012%E3%80%91Learning%20Personal%2BSocial%20Latent%20Factor%20Model%20for%20Social%20Recomme.pdf&amp;id=38051"
    target="_blank">
        【SIGKDD 2012】Learning Personal+Social Latent Factor Model for Social Recomme.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90VLDB%202012%E3%80%91Challenging%20the%20Long%20Tail%20Recommendation.pdf&amp;id=38052"
    target="_blank">
        【VLDB 2012】Challenging the Long Tail Recommendation.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90VLDB%202012%E3%80%91Supercharging%20Recommender%20Systems%20using%20Taxonomies%20for%20Learning%20U.pdf&amp;id=38053"
    target="_blank">
        【VLDB 2012】Supercharging Recommender Systems using Taxonomies for Learning
        U.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90WWW%202012%20Best%20paper%E3%80%91Build%20Your%20Own%20Music%20Recommender%20by%20Modeling%20Internet%20R.pdf&amp;id=38054"
    target="_blank">
        【WWW 2012 Best paper】Build Your Own Music Recommender by Modeling Internet
        R.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90WWW%202013%E3%80%91A%20Personalized%20Recommender%20System%20Based%20on%20User%5C%26%23039%3Bs%20Informatio.pdf&amp;id=38055"
    target="_blank">
        【WWW 2013】A Personalized Recommender System Based on User's Informatio.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90WWW%202013%E3%80%91Diversified%20Recommendation%20on%20Graphs-Pitfalls%2C%20Measures%2C%20and%20Algorithms.pdf&amp;id=38056"
    target="_blank">
        【WWW 2013】Diversified Recommendation on Graphs-Pitfalls, Measures, and
        Algorithms.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90WWW%202013%E3%80%91Do%20Social%20Explanations%20Work-Studying%20and%20Modeling%20the%20Effects%20of%20S.pdf&amp;id=38057"
    target="_blank">
        【WWW 2013】Do Social Explanations Work-Studying and Modeling the Effects
        of S.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90WWW%202013%E3%80%91Generation%20of%20Coalition%20Structures%20to%20Provide%20Proper%20Groups%5C%26%23039%3B.pdf&amp;id=38058"
    target="_blank">
        【WWW 2013】Generation of Coalition Structures to Provide Proper Groups'.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90WWW%202013%E3%80%91Learning%20to%20Recommend%20with%20Multi-Faceted%20Trust%20in%20Social%20Networks.pdf&amp;id=38059"
    target="_blank">
        【WWW 2013】Learning to Recommend with Multi-Faceted Trust in Social Networks.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90WWW%202013%E3%80%91Multi-Label%20Learning%20with%20Millions%20of%20Labels-Recommending%20Advertis.pdf&amp;id=38060"
    target="_blank">
        【WWW 2013】Multi-Label Learning with Millions of Labels-Recommending Advertis.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90WWW%202013%E3%80%91Personalized%20Recommendation%20via%20Cross-Domain%20Triadic%20Factorization.pdf&amp;id=38061"
    target="_blank">
        【WWW 2013】Personalized Recommendation via Cross-Domain Triadic Factorization.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90WWW%202013%E3%80%91Profile%20Deversity%20in%20Search%20and%20Recommendation.pdf&amp;id=38062"
    target="_blank">
        【WWW 2013】Profile Deversity in Search and Recommendation.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90WWW%202013%E3%80%91Real-Time%20Recommendation%20of%20Deverse%20Related%20Articles.pdf&amp;id=38063"
    target="_blank">
        【WWW 2013】Real-Time Recommendation of Deverse Related Articles.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90WWW%202013%E3%80%91Recommendation%20for%20Online%20Social%20Feeds%20by%20Exploiting%20User%20Response.pdf&amp;id=38064"
    target="_blank">
        【WWW 2013】Recommendation for Online Social Feeds by Exploiting User Response.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90WWW%202013%E3%80%91Recommending%20Collaborators%20Using%20Keywords.pdf&amp;id=38065"
    target="_blank">
        【WWW 2013】Recommending Collaborators Using Keywords.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90WWW%202013%E3%80%91Signal-Based%20User%20Recommendation%20on%20Twitter.pdf&amp;id=38066"
    target="_blank">
        【WWW 2013】Signal-Based User Recommendation on Twitter.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90WWW%202013%E3%80%91SoCo-%20A%20Social%20Network%20Aided%20Context-Aware%20Recommender%20System.pdf&amp;id=38067"
    target="_blank">
        【WWW 2013】SoCo- A Social Network Aided Context-Aware Recommender System.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90WWW%202013%E3%80%91Tailored%20News%20in%20the%20Palm%20of%20Your%20HAND-A%20Multi-Perspective%20Transpa.pdf&amp;id=38068"
    target="_blank">
        【WWW 2013】Tailored News in the Palm of Your HAND-A Multi-Perspective Transpa.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90WWW%202013%E3%80%91TopRec-Domain-Specific%20Recommendation%20through%20Community%20Topic%20Mini.pdf&amp;id=38069"
    target="_blank">
        【WWW 2013】TopRec-Domain-Specific Recommendation through Community Topic
        Mini.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90WWW%202013%E3%80%91User%5C%26%23039%3Bs%20Satisfaction%20in%20Recommendation%20Systems%20for%20Groups-an%20.pdf&amp;id=38070"
    target="_blank">
        【WWW 2013】User's Satisfaction in Recommendation Systems for Groups-an
        .pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90WWW%202013%E3%80%91Using%20Link%20Semantics%20to%20Recommend%20Collaborations%20in%20Academic%20Socia.pdf&amp;id=38071"
    target="_blank">
        【WWW 2013】Using Link Semantics to Recommend Collaborations in Academic
        Socia.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=%E3%80%90WWW%202013%E3%80%91Whom%20to%20Mention-Expand%20the%20Diffusion%20of%20Tweets%20by%20%40%20Recommendation.pdf&amp;id=38072"
    target="_blank">
        【WWW 2013】Whom to Mention-Expand the Diffusion of Tweets by @ Recommendation.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=Recommender%2BSystems%2BHandbook.pdf&amp;id=38073"
    target="_blank">
        Recommender+Systems+Handbook.pdf
    </a>
</p>
<p style="line-height:16px;">
    <a href="http://blog.sciencenet.cn/home.php?mod=attachment&amp;filename=tutorial.pdf&amp;id=38074"
    target="_blank">
        tutorial.pdf
    </a>
</p>

#各个领域的推荐系统

**图书**
       
* Amazon
* 豆瓣读书
* 当当网
  
**新闻**
        
* Google News
* Genieo
* Getprismatic  <http://getprismatic.com/>
  
**电影**
       
* Netflix
* Jinni
* MovieLens
* Rotten Tomatoes
* Flixster
* MTime

**音乐**

* 豆瓣电台
* Lastfm
* Pandora
* Mufin
* Lala
* EMusic
* Ping
* 虾米电台
* Jing.FM

**视频**

* Youtube
* Hulu
* Clciker

**文章**

* CiteULike
* Google Reader
* StumbleUpon

**旅游**

* Wanderfly
* TripAdvisor

**社会网络**

* Facebook
* Twitter

**综合**

* Amazon
* GetGlue
* Strands
* Hunch



#欢迎贡献资源~~待续
