# gitHomework
This is a dummy project to try Git commands
