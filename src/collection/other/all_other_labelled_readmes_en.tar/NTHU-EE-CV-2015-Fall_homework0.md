#homework0
This homework is simply used to check if all students know how to work with git and github (no credit).
At the sametime, it also helps me to know you a little bit more :)

## Brief self-introduction [max 500 words]

## Why Computer Vision? [max 500 words]

## What do you want to achieve in the course? [ max 500 words]

PS. 中文 or English are both fine.

## Due Date: Sept. 23, 2015
