# wdi-fundamentals-memorygame

Memory Game: Unit Homework for WDI Fundamentals

In order to apply JavaScript concepts covered in the [pre-work](http://fundamentals.generalassemb.ly/), all pre-work lessons will work towards building a memory game app. Your development of this game will exercise your ability to implement logic with JavaScript and so much more! Besides following the prompts, you should feel free to be creative and add to the code - make this game your own!

