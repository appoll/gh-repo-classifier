The Google Web Components are now on the Polymer Catalog.

https://elements.polymer-project.org/browse?package=google-web-components
