# homework

Inside, you will find some incomplete tree-traversal algorithms.  Along with a suite of tests.

Your Task is to FIX THEM.  Make them PASS ALL THE TESTS.

## Usage

lein spec -a

## License

Distributed under the Eclipse Public License version 1.0
