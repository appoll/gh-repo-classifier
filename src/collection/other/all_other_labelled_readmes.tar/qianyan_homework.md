###集合练习

####使用方式

1\. 使用构建工具

```bash
./gradlew idea
```

2\. 使用IntelliJ IDEA打开collection.ipr

3\. 运行CollectionsOpsTest

4\. 修改实现代码，使得测试通过

#### 练习题（测试已覆盖）
* 使用集合创建一个包含1-10十个数字的列表
* 返回其中的奇数
* 将偶数乘2，奇数不变
* 找出数字，返回字符串: "Hello, x" 或者 "Not Found"
