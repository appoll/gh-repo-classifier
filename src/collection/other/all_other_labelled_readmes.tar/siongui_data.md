<dl>
 <dt>name</dt>
  <dd><a href="http://www.tipitaka.org/">Pāḷi Tipiṭaka</a></dd>
 <dt>description</dt>
  <dd>The Pāḷi Canon</dd>
 <dt>file</dt>
  <dd>tipitaka/romn/.*</dd>
 <dt>LICENSE</dt>
  <dd>Unknown</dd>
</dl>

---

<dl>
 <dt>name</dt>
  <dd><a href="https://code.google.com/p/python-jianfan/">python-jianfan</a></dd>
 <dt>description</dt>
  <dd>A python library for translation between traditional and simplified chinese</dd>
 <dt>file</dt>
  <dd>src/jianfan-0.0.2.zip</dd>
  <dd>pylib/jianfan/__init__.py</dd>
  <dd>pylib/jianfan/charsets.py</dd>
 <dt>download</dt>
  <dd><a href="https://python-jianfan.googlecode.com/files/jianfan-0.0.2.zip">jianfan-0.0.2.zip</a></dd>
 <dt>LICENSE</dt>
  <dd><a href="http://www.gnu.org/licenses/old-licenses/gpl-2.0.html">GNU GPL v2</a></dd>
</dl>

---

<dl>
 <dt>name</dt>
  <dd><a href="http://tongwen.openfoundry.org/">新同文堂(New Tong Wen Tang)</a></dd>
 <dt>description</dt>
  <dd>中文網頁繁簡轉換(webpage translation between traditional and simplified chinese)</dd>
 <dt>file</dt>
  <dd>app/scripts/tongwen_core.js</dd>
  <dd>app/scripts/tongwen_table_pt2s.js</dd>
  <dd>app/scripts/tongwen_table_t2s.js</dd>
  <dd>app/scripts/tongwen_table_ps2t.js</dd>
  <dd>app/scripts/tongwen_table_s2t.js</dd>
 <dt>download</dt>
  <dd><a href="http://tongwen.openfoundry.org/src/web/tongwen_core.js">tongwen_core.js</a></dd>
  <dd><a href="http://tongwen.openfoundry.org/src/web/tongwen_table_s2t.js">tongwen_table_s2t.js</a></dd>
  <dd><a href="http://tongwen.openfoundry.org/src/web/tongwen_table_t2s.js">tongwen_table_t2s.js</a></dd>
  <dd><a href="http://tongwen.openfoundry.org/src/web/tongwen_table_ps2t.js">tongwen_table_ps2t.js</a></dd>
  <dd><a href="http://tongwen.openfoundry.org/src/web/tongwen_table_pt2s.js">tongwen_table_pt2s.js</a></dd>
 <dt>LICENSE</dt>
  <dd><a href="http://www.gnu.org/licenses/old-licenses/gpl-2.0.html">GNU GPL v2</a></dd>
</dl>

---

<dl>
 <dt>name</dt>
  <dd><a href="https://pypi.python.org/pypi/goslate">goslate</a></dd>
 <dt>description</dt>
  <dd>Unofficial Free Google Translation API</dd>
 <dt>file</dt>
  <dd>src/goslate-1.1.1.tar.gz</dd>
 <dt>download</dt>
  <dd><a href="https://pypi.python.org/packages/source/g/goslate/goslate-1.1.1.tar.gz#md5=cd4cb0d76fc92b280100085ade32c82f">goslate-1.1.1.tar.gz</a></dd>
 <dt>LICENSE</dt>
  <dd>License :: OSI Approved :: MIT License</dd>
</dl>

