ngacharts.sql - automatic dump of the MySQL database tables
