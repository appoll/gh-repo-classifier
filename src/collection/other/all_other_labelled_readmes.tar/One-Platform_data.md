One Data
==============
基于Spring Data : JPA与Jade的框架，将两者的优点进行结合
