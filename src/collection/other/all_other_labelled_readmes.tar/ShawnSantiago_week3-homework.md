Week3 homework
==============
