# homeworks

Step 1: Fork to your own repo

Step 2: Clone the project to your computer

Step 3: Add your answers to homework.docx

Step 4: Commit back to your forked master branch

Step 5: Pull request from your fork to chanceCyphers/homeworks
