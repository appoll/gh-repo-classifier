
## 摄影网站建设

### [网站地址](http://xyxiao.mom)

``` bash
# 安装依赖包
npm i -d

# 启动服务  localhost:8081
npm run dev

# 打包编译
npm run build
```

# 首页
### http://7xvdom.com1.z0.glb.clouddn.com/index.png
![首页](http://7xvdom.com1.z0.glb.clouddn.com/index.png)

#图片列表页
### http://7xvdom.com1.z0.glb.clouddn.com/biao.png
![图片列表页](http://7xvdom.com1.z0.glb.clouddn.com/biao.png)

#操作
### http://7xvdom.com1.z0.glb.clouddn.com/show.gif
![gif](http://7xvdom.com1.z0.glb.clouddn.com/show.gif)
