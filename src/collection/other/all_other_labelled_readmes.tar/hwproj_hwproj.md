# HwProj

Lecturer-students collaboration service with GitHub integration
