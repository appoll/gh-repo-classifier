###Homework:

0. Sforkować to repozytorium i sklonować do lokalnego repozytorium
1. Dodać plik z nazwiskiem.txt
2. Zacommitować zmiany
3. Zmienić zawartość pliku (wpisać swoje imię i nazwisko)
4. Zacommitować zmiany
5. Wypchnąć zmiany na swojego forka
