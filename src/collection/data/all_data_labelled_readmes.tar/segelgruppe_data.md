# data.segelgruppe.at

Allerlei Daten bezügliche Segeln & Wassersport am Neusiedlersee. Zum Bearbeiten von GeoJSON empfiehlt sich ein Tool wie http://geojson.io/

Have fun & schickt Pull Requests mit neuen und / oder verbesserten Daten!
