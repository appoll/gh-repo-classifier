data
====

PCD files for tutorials, examples, or PCL-related applications. More samples can be found archived at https://sourceforge.net/projects/pointclouds/files/
