Hier veröffentlichen wir Daten, die Österreich und viele Menschen in diesem Land betreffen. Wir haben diese Daten nicht selbst erhoben, sondern aus Silos wie z.B. PDFs befreit, vorstrukturiert, gesäubert und mit weiteren Daten angereichert. Damit sollen Daten leichter weiterverwendet werden können. 

Unsere Vision: Ein Best-Practice-Beispiel für offene Daten zu sein; Schritt für Schritt die Wertschöpfung und die Transparenz, die sich international durch Open Data ergeben, auch hierzulande zu realisieren. 

Weitere Informationen zum Projekt: http://okfn.at/gutedaten
