# Data for unicode-table.com

[Документация на русском](https://github.com/unicode-table/unicode-table-data/wiki/Index-(Russian))

[Documentation in English](https://github.com/unicode-table/unicode-table-data/wiki/Index-(English))

[Polska dokumentacja](https://github.com/unicode-table/unicode-table-data/wiki/Index-(Polish))
