data-ongithub
=============

This is a self-contained data repository that runs 100% on Github.
