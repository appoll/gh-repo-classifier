Daten für Frankfurt Gestalten
====

Verschiedene Datensätze, die wir nutzen. Please share. :-)

- Frankfurter Stadtteile als Polygon im GeoJson Format
- Frankfurter Straßenliste sortiert nach Stadtteilen
- Tabellarische Liste aller Straßen in Frankfurt nach OpenStreetMap
- Alle Anträge der Ortsbeiräte in Frankfurt von 2004-2014 (Stand: 06.02.14)

Dank an Openstreetmaps - © OpenStreetMap-Mitwirkende