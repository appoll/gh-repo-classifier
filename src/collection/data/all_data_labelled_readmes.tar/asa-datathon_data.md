data
====

Public data we've collected for the ASA Datathon
