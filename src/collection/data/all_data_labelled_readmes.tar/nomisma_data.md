# Nomisma Data

This is the repository for nomisma RDF/XML (id/ folder) canonical data files and the nomisma ontology version (ontology/)/

The namespace for the ids is http://nomisma.org/id/

The namespace for the ontology is http://nomisma.org/ontology#
