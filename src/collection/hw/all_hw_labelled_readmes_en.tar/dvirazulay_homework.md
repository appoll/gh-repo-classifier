This is my personal solutions for Computer Science homework.
You may view it in order to learn, compare or get ideas, but in no way use ANY of my code in your work, as this is not allowed.