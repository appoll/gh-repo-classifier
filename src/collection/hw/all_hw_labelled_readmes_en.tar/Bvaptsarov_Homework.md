Homework
========

Telerik Homework GIT

The package also contain source code for Latin to Morse and vice versa translation, in native way -- without counting punctuation and white spaces.

It's a demo GIT account for academic homework.

Yours,
Borislav Vaptsarov
Student of Telerik Academy, third year in NBU
