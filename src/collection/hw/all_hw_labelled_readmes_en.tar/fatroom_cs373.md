Unit tests for homework on Udacity course CS373: Programming a Robotic Car

Usage:
1. Edit homework$version/task.py file. Put your code between comments
2. Run python homework$version/test.py
3. Fix your code and run tests again

