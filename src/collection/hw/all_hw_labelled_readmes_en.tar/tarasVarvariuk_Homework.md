# Homework

This is the fisrt HOMEWORK of SS ITA Lv179java
Creating a program that solve an algorithm exercises
