Homework
========

My homework while I attend the Telerik Academy
