This is the accumulated homework of Josh Gachnang.
I am a junior at University of Wisconsin Madison. This repository was created
to give me a way to keep all my code in version control across multiple 
machines, not so you can cheat on homework. However, I do realize that a lot 
of this code may be helpful for other, non-UW-Madison activities, so I'm 
providing it to the world (though it is not always the best code, so be 
warned!) I also believe in openness as a way of life, so this is provided
free of charge to everyone.  All the code is provided under the New BSD 
License, except code obtained from instructors (ask them for a license).

