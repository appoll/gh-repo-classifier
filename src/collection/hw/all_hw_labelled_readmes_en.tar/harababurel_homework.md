# homework
collection of lab projects and homework for university.

![xkcd - students](https://imgs.xkcd.com/comics/students.png)

subjects:

* **sem 1**
    * **algebra**
    * **analysis**
    * **cl** - computational logic
    * **csa** - computer systems architecture
    * **fop** - fundamentals of programming
* **sem 2**
    * **dynsys**
    * **geometry**
    * **graph**
    * **oop**
* **acm** - training rounds and such
