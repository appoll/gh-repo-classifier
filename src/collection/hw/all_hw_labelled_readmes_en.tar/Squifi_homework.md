# homework
shared space for procedural programming in C

Usefull links from the tutorium:

cdecl.org -> translates c gibberish to english
