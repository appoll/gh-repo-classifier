# homework [![Gitter](https://badges.gitter.im/MagicCube/homework.svg)](https://gitter.im/MagicCube/homework?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge)

This repository is built for submitting homework.
