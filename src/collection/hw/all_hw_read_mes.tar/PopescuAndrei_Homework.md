<h1>Homework</h1>
========
<p>Documentation found in Documentation.docx </p>
<p>The apk for the application is found in the root directory (Homework.apk). You can install it on your device or you can clone the project and run it directly from there. </p>
