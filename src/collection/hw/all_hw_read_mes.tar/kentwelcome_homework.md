homework
=========

Homework when I was a student
