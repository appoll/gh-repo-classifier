sort out homework code 22:00 2013/8/2
