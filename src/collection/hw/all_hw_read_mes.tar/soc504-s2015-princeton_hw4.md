# hw4
homework 4: logistic regression

[![Build Status](https://travis-ci.org/soc504-s2015-princeton/hw4.svg?branch=master)](https://travis-ci.org/soc504-s2015-princeton/hw4)


