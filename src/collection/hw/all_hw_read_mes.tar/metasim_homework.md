homework
========

Classwork code
