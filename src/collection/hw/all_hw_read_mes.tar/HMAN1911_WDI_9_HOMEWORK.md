# WDI9 MELB homework

## Submission guide

1. Make sure you have forked this repository.
2. Make changes inside the directory with your name. Don't make changes to others' directories or files!
3. Commit your changes locally, then push them to github.
4. Make a pull request against **THIS** repository.


## Licensing
1. All content is licensed under a CC-BY-NC-SA 4.0 license. 
2. All software code is licensed under GNU GPLv3. For commercial use or alternative licensing, please contact legal@ga.co.