homework
========

NMETH 534
