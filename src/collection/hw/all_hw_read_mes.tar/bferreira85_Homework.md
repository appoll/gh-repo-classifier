# Homework
exercises from data scientist tool box course
