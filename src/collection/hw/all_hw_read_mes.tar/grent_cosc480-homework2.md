COSC 480: Software Engineering for the Cloud - Homework 2
=========================================================

See instructions posted on Moodle for completing this homework.

jsommers@colgate.edu
