homework
========

for practical machine learning
