Oh what fun.
You've found what must be my most boring collection of code.

This is all homework I've completed while taking various training courses.

I keep them around as part of my toolbox.
I doubt they will be of interest to anyone else.