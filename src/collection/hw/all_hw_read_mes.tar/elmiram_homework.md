homework
========

this is programming homework

23.12.2013 - 3rd year homework

24.09.2015 - 4th year, seminar 1

29.09.2015 - 4th year, seminar 2

08.10.2015 - 4th year, seminar 3

16.10.2015 - 4th year, seminar 4

23.10.2015 - 4th year, seminar 5

6.11.2015 - 4th year, seminar 6

6.11.2015 - 4th year, seminar 7

13.11.2015 - 4th year, seminar 8, numpy

19.11.2015 - 4th year, numpy homework

27.11.2015 - 4th year, principal component analysis

04.12.2015 - 4th year, tf-idf

11.12.2015 - 4th year, svm learning

18.12.2015 - 4th year, tfidftransformer, svc + multinomialnb