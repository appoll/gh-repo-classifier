COSC 480: Software Engineering for the Cloud --- Homework 0
===========================================================

See instructions linked to Moodle for how to use and deploy this sample application.
