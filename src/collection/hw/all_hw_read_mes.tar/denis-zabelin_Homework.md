Homework
========