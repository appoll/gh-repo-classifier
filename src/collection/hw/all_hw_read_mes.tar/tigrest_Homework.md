git howto  
http://lifehacker.com/5983680/how-the-heck-do-i-use-github
http://gitref.org/basic/#commit