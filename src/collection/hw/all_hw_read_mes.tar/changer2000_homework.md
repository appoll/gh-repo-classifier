homework
========
1
2