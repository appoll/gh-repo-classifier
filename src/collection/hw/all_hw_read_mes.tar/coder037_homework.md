### homework


Some studium related stuff is located here. Nothing valuable.

   Trying to set up Eclipse - around 2014-11-15.
   Git initiated: 2014-11-18 using an unsuitable directory structure.
   Ready with the environment tuning, starting to write code.
   Initiated the world once again - restruct of the paths 2014-11-23. 
   Json src file parsing mostly completed - 2014-11-27.
   Run.java code separated into methods, getter-setter bacchanalia introduced 2014-12-02. 
   Recursion module finalized 2014-12-14. Copyleft written and comments converte to JavaDoc style - 2012-12-12.


### Identities


Internet is a nice thing thus the
real identities probably are to be discoverable only semidirectionally,
e.g. the command

    echo -n "My Realname" | sha512sum 

should give you the result below:

0fa1557ce3cbb37c25a6dd68a1f65c59d354b24788c39abf15fc2d1440d4f45c2f77425c1fe3d4b255fcd936042ef7ea0c202edbdd1505937da13455085c47ff  -


###.plan


Master plan is described in a separate file:
	- doc/TaskDescription.txt
ConceptDiagram.png is in doc/ directory
