# Homework
My personal code
