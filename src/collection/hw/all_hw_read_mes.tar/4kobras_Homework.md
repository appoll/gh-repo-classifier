# Homework
College Stuff
This is my homework. Not much to say about it. Studying Computer Science. Homework in GER, since I study in Germany.
Feel free to use if helpful.
Always happy about people showing me my mistakes :P But first look whether they still matter. Correcting mistakes from the first week in the sixth week won't change anything.
