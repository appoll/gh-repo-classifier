Homework for Week 3
==============

1. Fork this repository into your own account.
2. Clone your new repository down to your laptop.
3. Open the monopoly.rb file in Sublime Text.
4. Run the program to see what happens so far.
5. Look inside the source code and find the questions.
6. Add your code into the program so that all of the questions are answered.
7. Commit your changes.
8. Push (sync) your changes back into Github.
