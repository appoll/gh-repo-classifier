Homework
========

CSCI 104 Homework. Survive!
