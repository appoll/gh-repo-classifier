# homework
homework

Needs android-21 and the latest android repositories that contain the support libraries.

Build and run unit-tests
./gradlew build

Run integration/ui tests
./gradle connectedAndroidTest

Install apk
./gradlew installDebug
