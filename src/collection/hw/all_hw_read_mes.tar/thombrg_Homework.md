# Homework
Live app, http://thombrcal.gweb.io

### Using JavaScript:

* Design data structure to efficiently represent a set of pages with repeated content. Example:

  0 => headerContent1, footerContent1

  1 => headerContent1, footerContent1, bodyContent1

  2 => headerContent1, footerContent2, bodyContent2

  3 => headerContent2, footerContent1, bodyContent3, advertisement1

* Design a navigation system to efficiently render pages to HTML. Example:

  render( 0 ) render( 3 ) render( 1 )

### Notes

* CSS and UI libraries are not necessary. We'll only evaluate JavaScript part of assignment.
* Please make sure that solution runs in Chrome and Firefox.
