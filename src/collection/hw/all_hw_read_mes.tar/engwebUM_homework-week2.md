# Homework - Week 2

1. Fork this repository
2. Clone it to your computer
3. Do each of the exercises in the exercise directories
4. Push your solutions to your GitHub repository
5. When you feel confident with your solution, open a pull request to
   `engwebUM/homework-week2`

This homework is composed of 3 exercises:

* [Exercise 1](exercise1)
* [Exercise 2](exercise2)
* [Exercise 3](exercise3)

In order to get everything you need to complete the exercises, please follow
this [setup](http://tutorials.jumpstartlab.com/topics/environment/environment.html) (skip the PostgreSQL part).
