COSC 480: Software Engineering for the Cloud - Homework 4
=========================================================

See instructions posted on Moodle for completing this homework.

jsommers@colgate.edu
