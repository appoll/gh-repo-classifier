HomeWork
========
This is the readme file for the homework6;The author of this homework is Alimu Mijiti;
