homeWork
========

repository for JS core homework
