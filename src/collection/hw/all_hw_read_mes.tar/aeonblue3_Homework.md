Shell Script application for managing contacts.

Created as a homework project.
