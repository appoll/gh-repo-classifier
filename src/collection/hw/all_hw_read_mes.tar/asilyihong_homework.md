homework
========

This is homework of ANSI C

