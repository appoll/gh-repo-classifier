My Homework  (Practice in 1devs class)
========

[my site : www.colegiangroup.ir](www.collegiangroup.ir)

mezah(in tamrina serfan jahate hazf nashodan az class 1devs hastesh.....)



1stylesiiiiii   ===> 		tamrinayi hastesh ke ba 1styles.css neveshteh shodeh

haminjooriii    ===> 		tamrinayi hastesh ke style.css joda vase khodeshoon daran

Store 		===>			Library of files and picture