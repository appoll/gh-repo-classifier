homework
========

homework_1
1 create new cocos 2d