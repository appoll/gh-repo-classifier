TAM-HW2
=======

Homework for week 2