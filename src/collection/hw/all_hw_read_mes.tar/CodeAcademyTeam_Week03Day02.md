# Week03 Day02 Homework

#Günün araşdırma mövzuları

1.Git və Github
- ( English ) https://thenewboston.com/videos.php?cat=80
- ( Türkçe ) https://medium.com/@emrullahluleci/git-ve-github-nas-l-kullan-l-r-7d3cc886b77e#.h94ggwg5x

2.CSS background 
- ( English ) https://css-tricks.com/almanac/properties/b/background/
- ( Türkçe ) http://fatihhayrioglu.com/hizli-css-referansi/

3.Font istifadəsi 
- ( English ) https://css-tricks.com/almanac/properties/f/font/
- ( Türkçe ) a) http://fatihhayrioglu.com/font-ozellikleri/  b)http://fatihhayrioglu.com/font-face-kullanimi/

4.Icon Fonts
- ( English ) https://www.sitepoint.com/introduction-icon-fonts-font-awesome-icomoon/
- ( Türkçe ) http://toturkmen.com/blog/yazilim/web/css/font-awesome-nedir-nasil-kullanilir.html

5.Düzgün CSS kod yazma qaydalari 
- ( English ) http://code.tutsplus.com/tutorials/5-ways-to-instantly-write-better-css--net-3003
- ( Türkçe ) http://www.aycan.net/arabirim-gelistiricisi-kimdir-css-yazarken-dikkat-edilmesi-gereken-kurallar/

#Ev Tapşırığı

1.Bu repo FORK ediləcək

2.FORK edilmiş bu repoya cavablar.txt adinda bir text dakumenti əlavə ediləcək.

3.cavablar.txt faylina aşağıdakı sualların cavabları (Azərbaycan dilində) yazılacaq.
 - Düzgün və oxunaqlı CSS kodu yazmaq üçün lazım olabiləcək 10 qayda yazın
 - Font Awesome kimi ikon fontları varmı? Varsa qisaca haqlarinda məlumat verin
 - Azərbaycan şriftlərini dəstəkləyən 10 ədəd font ailəsinin adını və istifadə qaydasını yazın
 
4.cavablar.txt əlavə edilmiş github repo linki Google Classroom a əlavə ediləcək.

Uğurlar...




