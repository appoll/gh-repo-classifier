# Week 1 - Homework
(10 total points)

1. FORK this repository into your own account.
2. CLONE your new repository onto your laptop.
3. In each file, look for "TO DO" comments and follow the instructions.
4. COMMIT and then SYNC (push) your changes back to your account.
5. VERIFY your code has been submitted by going to your GitHub.com account.

Grading: 2 points for each correct "TO DO" item.

Happy coding!

