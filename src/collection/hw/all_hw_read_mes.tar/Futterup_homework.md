# homework
Schoolrelated stuff
