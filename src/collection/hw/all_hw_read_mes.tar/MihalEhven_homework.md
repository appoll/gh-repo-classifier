homework
========

Portia made me do this.
