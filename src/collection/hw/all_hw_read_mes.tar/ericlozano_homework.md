homework
========

my homework repository

public class HelloW
{
 public static void main (String [] args)
   {
	System.out.println ("Hello World");
   }
}
