All my homework :-D
