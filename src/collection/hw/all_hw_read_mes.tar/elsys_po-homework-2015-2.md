# PO-2015

## News

0. **Резултати от поправките може да намерите [тук](https://github.com/elsys/po-homework/blob/master/july-retry.md)**
0. **Консултация преди поправката ще се проведе във вторник 12 юни 2016 от 11:00 часа!**. _Извиняваме се, видяхме, че повечето хора бяха избрали понеделник, но не бе възможно консултацията да бъде направена в този ден и час._
0. **Следващата седмица, всички ученици трябва да се явят.** Тези които са доволни от **Tryout 1** трябва да минат през нас, да бъдат отбелязани. Останалите ще бъдат изпитани на подобни задачи.
0. [**FAQ Оформяне втори срок**](https://docs.google.com/document/d/1ETePYqIaqUG5ZunoYQ8laciVo1Ghz3EktExV7SYGGLE/edit?usp=sharing)
0. [**Codito Manifesto**](https://docs.google.com/document/d/1Ub5tekkCVQxmzpmYgjHmaMqOzvXWb5T1P_fzYIMox8M/edit#)
0. **Следващия вторник, 07 юни 2016, ще има консултации от 12:00 в кабинет 31!!**
0. Следващия час (**2016-05-17/18**) ще има малко контролно на тема динамична памет!
0. Добавени са [новите](#new-homeworks) и старите домашни [по-долу](#old-homeworks)
0. Срокът на домашно 04 е удължен до тази неделя ( **2016-04-10 23:59:59** )!
0. Срокът на домашно 01 е удължен до този четвъртък ( **2016-03-17 23:59:59** )!

## Important

### Headquarters
https://docs.google.com/spreadsheets/d/1bj6Y8O1POXFm2LN03ut5ORoGL7C-1lcWnt0Ij9WPJ-s

## Lectures

### Lecture 10 - Term Preparation & Discussion
https://docs.google.com/presentation/d/13U6T42HcfuyVp1YkdHRfeEbGpUdxsevd9XCjGnFB5xs

### Lecture 9 - Dynamic Memory II
https://docs.google.com/presentation/d/1W2Ev9Ino72fujRBdHPQntxN7V4kZigW8YtTwm6WW42I

### Lecture 8 - Dynamic Memory
https://docs.google.com/presentation/d/1r-9OIEe-ILXE491j8nur2U-Hljk831VHZfUiTgUwUz4

### Lecture 7 - Exam Preparation
https://docs.google.com/presentation/d/1U1J_ItIyob_k8L_KUiAChuaCvIScqRFbd8XgWmb_F8E

### Lecture 6 - Pointers & Structures
https://docs.google.com/presentation/d/13LH7xLchER6djz3AYF9zgW6kwAcVV-39CS7H4bi4-Qg

### Lecture 5 - Pointers II
https://docs.google.com/presentation/d/1HEfJu943UwAVMqIocsbzbdva5lSa90kY57JlHmxRad0

### Lecture 4 - Pointers
https://docs.google.com/presentation/d/1vQMcsT-wW2ZgJ7JQnGmvfvV7w5HvfYacuf5CrGqXkfc

### Lecture 3 - Exercise with Structures again
https://docs.google.com/presentation/d/1BKdqi6NKZqAuD1JarhkKTMQQKlE3-0Rl-npi9gg7MLA

### Lecture 2 - Exercise with Structures
https://docs.google.com/presentation/d/1rGavr9nzfD1_KSrE7DSAH5l8C535OyKHLI_d4MqDWkY

### Lecture 1 - Structures
https://docs.google.com/presentation/d/1fuFoBx_cfjZ3YjAhNp1DGPIEGjbtLZVFs3s7okgnKKE

### New Homeworks
### A classes

0. [01 Homework](A/01/README.md)
0. [02 Homework](A/02/README.md)
0. [03 Homework](A/03/README.md)
0. [04 Homework](A/04/README.md)

### B classes

0. [01 Homework](B/01/README.md)
0. [02 Homework](B/02/README.md)
0. [03 Homework](B/03/README.md)
0. [04 Homework](B/04/README.md)

### V classes

0. [01 Homework](V/01/README.md)
0. [02 Homework](V/02/README.md)
0. [03 Homework](V/03/README.md)
0. [04 Homework](V/04/README.md)

### G classes

0. [01 Homework](G/01/README.md)
0. [02 Homework](G/02/README.md)
0. [03 Homework](G/03/README.md)
0. [04 Homework](G/04/README.md)

## Old Homeworks
### A B classes

0. [Homework 0](https://docs.google.com/presentation/d/15i3rlAeGX7YnCt7fVq6AdZf33Lgc4AOHWvTnDC-I24I/edit#slide=id.ge063510e8_0_62)
0. [Homework 1](https://docs.google.com/presentation/d/1UHWhWwYfh_dR-PtyRLMt5ErcFaGYvAONQd0QDdtNBJw/edit#slide=id.ge0dd53ff7_5_0)
0. [Homework 2](https://docs.google.com/presentation/d/1XBt84LbKHvRd92zLgaLcyC-ga0Ymlrs9H3_7NUn-1lc/edit#slide=id.gca15bdc74_0_9)
0. [Homework 3](https://docs.google.com/presentation/d/1PKipJkyZJxG-_6vHuSciKRCL-OHaZD08dPUeGGyyDis/edit#slide=id.ge4ead636d_3_0)
0. [Homework 4](https://docs.google.com/presentation/d/1XxmPMCg7fDMh8XkRo6sjJ47adUxvCwc2l1x0zk2VuvU/edit#slide=id.ge2ff8ea56_0_81)
0. [Homework 5](https://docs.google.com/presentation/d/10q2iBU8VYUDIngCjbA675dtCbU9aMyeqI7Z1Q0ij19I/edit#slide=id.ge5170674f_0_5)
0. [Homework 6](https://docs.google.com/presentation/d/1tRrXE61UccF3Ty51pkHkuN0QczQ71S7A3bkpyadLfTc/edit#slide=id.ge64dbcdf6_0_0)
0. [Homework 7](https://docs.google.com/presentation/d/1he0lQnT8k7faavvAh3EyKgCmYGMhPpzS3WpOWJUZEYM/edit#slide=id.gcd29c2a72_1_45)
0. [Homework 8](https://drive.google.com/file/d/0B83l5t-0yjU7Vl91Yy1PUFlXTkk/view?usp=sharing)
0. [Homework 9](https://docs.google.com/document/d/1B-ZN-pwSB-dur0p8-I6wCR30YU9-cazD3RDD0xIHM-8/edit?usp=sharing)
0. [Homework 10](https://docs.google.com/document/d/1zfNtzMacO3EzNS0s3qsNjvycLpoIzZhwz0AGDp1jYKI/edit?usp=sharing)


### V G classes
0. [Homework 0](https://docs.google.com/presentation/d/1Ztt6_sHYvs9JuNK0m6QUJHyzp6JfFIvFhnqNsA6blLY/edit#slide=id.ge063510e8_0_62)
0. [Homework 1](https://docs.google.com/presentation/d/1KOyuzeBV7ntvg9sK8BPb9_TOF_G3U41yDk8WuwOEQrI/edit#slide=id.ge0dd53ff7_5_0)
0. [Homework 2](https://docs.google.com/presentation/d/1sl-jsBzLDeq8aBuznykwE2DgBNy3FaxIg_yTlVnI-Ns/edit#slide=id.gca15bdc74_0_9)
0. [Homework 3](https://docs.google.com/presentation/d/1SWbUvnJkjZJqK_KDZb2O7CjHzyhScHkwgjWvy-dj18c/edit?usp=sharing)
0. [Homework 4](https://docs.google.com/presentation/d/1Y9Dmt3qMC40y9lWTGnSDuln8DtaD4jPIEW-zDM55dPs/edit#slide=id.ge64dbcdf6_0_0)
0. [Homework 5](https://docs.google.com/presentation/d/1qtS_InM-Jb2NnXoq28iCLqruC1uItbMSonSd7DRXgiE/edit#slide=id.gcd29c2a72_1_45)
0. [Homework 6](https://docs.google.com/document/d/1ECwpTZMThp4K06acrtqCWeSe0tQlt7oKUKRvOIQjMrM/edit)
0. [Homework 7](https://drive.google.com/file/d/0B83l5t-0yjU7Vl91Yy1PUFlXTkk/view?usp=sharing)
0. [Homework 8](https://docs.google.com/document/d/1B-ZN-pwSB-dur0p8-I6wCR30YU9-cazD3RDD0xIHM-8/edit?usp=sharing)
0. [Homework 9](https://docs.google.com/document/d/1zfNtzMacO3EzNS0s3qsNjvycLpoIzZhwz0AGDp1jYKI/edit?usp=sharing)
