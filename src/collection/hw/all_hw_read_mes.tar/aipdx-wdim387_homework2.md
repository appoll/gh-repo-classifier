Homework 2
==========

1. Clone this repository. See the instructions in Week 1 for details: <https://github.com/aipdx-wdim387/week1>.
2. In your copy of this repository, create a subdirectory. Name the subdirectory with your name (for example: danmuzyka).
3. Complete the [Project: Building an Address Book](http://www.codecademy.com/courses/building-an-address-book?curriculum_id=506324b3a7dffd00020bf661) project on Codecademy. When you get to the last screen (6/6), select all of the code, copy it, and save it in a file named addressbook.js.
4. Complete the [Project: Building a Cash Register](http://www.codecademy.com/courses/close-the-super-makert?curriculum_id=506324b3a7dffd00020bf661) project on Codecademy. When you get to the last screen (7/7), select all of the code, copy it, and save it in a file named cashregister.js.
5. Add both files to the subdirectory you created in your copy of this repository.
6. Commit the files and push to GitHub.
7. Send a pull request to the original copy of this repository.
8. If you get really stuck trying to submit this over Git, put the two files into a ZIP file and send me the ZIP file over e-mal: danmuzyka.ai@gmail.com.
