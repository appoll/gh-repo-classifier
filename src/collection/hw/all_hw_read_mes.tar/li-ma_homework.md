homework
========

Just for fun.
