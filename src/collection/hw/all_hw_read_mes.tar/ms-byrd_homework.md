homework
========

Cousera - Exploratory Data Analysis, Assignment 1
