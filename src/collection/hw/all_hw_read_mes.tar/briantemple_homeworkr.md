== Homeworkr

Homeworkr is a simple rails app to handle assignment submission and grading.

== Installation

* Install Homeworkr gem dependencies
bundle install

* Create the database using the command
rake db:schema:load RAILS_ENV=production

* Define an administrator user
Modify the db/seeds.rb file and change at least the email and password

* Add the administrator user to the database
rake db:seed RAILS_ENV=production

* Start the server
rails s --environment=production

* Log in and create courses and assignments
http://localhost:3000

== Contact

Project contact: Brian Temple <brian@briantemple.com>

== License

Homeworkr is released under the MIT license.  Check the LICENSE file for details.
