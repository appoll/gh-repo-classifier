Домашнее задание 1.

Отрефакторить TradesJob в соответствии с принципом Single Responsibility Principle.
Выделить отдельные классы отвечающие за:
 - скачивание файла из источника
 - разбор (парсинг) файла из формата CSV

Сборка проекта и подключение зависимых библиотек осуществляется с помощью Apache Maven.
Что это такое и как его настроить можно прочитать здесь:
 - официальная страница Getting Started на сайте Maven: https://maven.apache.org/guides/getting-started/
 - статьи на хабре: https://habrahabr.ru/post/77382/ и https://habrahabr.ru/post/77333/

Современные IDE имеют поддержку maven, для того чтобы ей воспользоваться можно открыть проект в IntelliJIdea при помощи
 File -> New -> Project from existing source...
в появившемся диалоговом окне выбрать файл pom.xml из проекта.