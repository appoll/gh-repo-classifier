Just some homework.
