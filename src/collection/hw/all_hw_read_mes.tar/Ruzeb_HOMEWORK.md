HOMEWORK
========
