Its just to put my homework
