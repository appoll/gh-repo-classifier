homework
========

probability, statistics and algorithm
