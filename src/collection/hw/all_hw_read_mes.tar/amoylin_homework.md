homework
========

homework for intel 
