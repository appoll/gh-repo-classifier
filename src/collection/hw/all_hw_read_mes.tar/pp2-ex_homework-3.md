Homework 3
==========

This is an exercise for Protein Prediction 2. Given live data from the site reddit, edit the function runVis() in vis.js and try to create a small visualization using d3js.
