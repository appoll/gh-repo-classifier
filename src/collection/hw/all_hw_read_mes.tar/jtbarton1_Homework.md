Homework
========

Homework exercises
