# homework
 
 
 
Part 2:

([\w\w+\_\w+^\,]+)\,([-\w+\.\w+^\,]+)\,([-\w+\.\w+^\,]+)\,([A-Z^\,]+)\,([\w+\.\-\w+^\,]+)

\4\t\5\t\1\t\3\t\2


institution	catalog	species	latitude	longitude
UMMZ	235317	Aaptosyax_grypus	13.93333333	105.9333333
USNM	271411.5151553	Aaptosyax_grypus	17.417	104.79166667
YPM	YPM	Abactochromis_labrosus	-11.61	34.3031
YPM	YPM	Abactochromis_labrosus	-11.6064	34.3039
YPM	YPM	Abactochromis_labrosus	-11.6131	34.3064
YPM	YPM	Abactochromis_labrosus	-12.07	34.73
MNHN	2006-1705	Abalistes_filamentosus	-22.542	166.45
AM	I.37974-001	Abalistes_filamentosus	-9.9525	129.53266
CAS	40834	Abalistes_stellaris	12.266667	100.733333
CAS	40836	Abalistes_stellaris	11.816667	100.045833
CAS	40837	Abalistes_stellaris	11.805	100.038889
CAS	40838	Abalistes_stellaris	12.216667	100.65
CAS	40840	Abalistes_stellaris	11.083333	123.333333
CAS	40847	Abalistes_stellaris	7.938333	134.531944
CAS	55556	Abalistes_stellaris	0.883333	127.683333
CAS	55557	Abalistes_stellaris	0.883333	127.683333
MNHN	1989-0635	Abalistes_stellatus	28.1	33.517
MNHN	1987-0109	Abalistes_stellatus	12.5	112.5
MNHN	1966-0146	Abalistes_stellatus	29	33.533
MNHN	a-8527	Abalistes_stellatus	11.983	79.833
MNHN	a-8528	Abalistes_stellatus	11.983	79.833
MNHN	b-1854	Abalistes_stellatus	-7.5	132.5
MNHN	0000-2412	Abalistes_stellatus	-6.167	39.167
MNHN	b-1837	Abalistes_stellatus	-10	125
MNHN	0000-2250	Abalistes_stellatus	-6.167	39.167
MNHN	b-1852	Abalistes_stellatus	22	-160
MNHN	b-1853	Abalistes_stellatus	-5.15	119.467
MNHN	1960-0072	Abalistes_stellatus	11.833	42.833
MNHN	a-8526	Abalistes_stellatus	11.983	79.833
MNHN	b-1925	Abalistes_stellatus	20	39
USNM	349664.5257230	Abalistes_stellatus	15.3	40.283
USNM	396136.5327197	Abalistes_stellatus	11.325	123.37194444
USNM	285801.5131045	Abalistes_stellatus	11.22	47.24166667
USNM	316729.5209367	Abalistes_stellatus	10.35	107.25
USNM	285830.5131075	Abalistes_stellatus	11.615	43.67166667
USNM	320711.5213854	Abalistes_stellatus	-22.20833333	43.15833333
USNM	350124.5257866	Abalistes_stellatus	-16.14055556	168.116666667
USNM	195298.5057776	Abalistes_stellatus	34	137.82777778
USNM	320613.5213486	Abalistes_stellatus	10.63333333	45.27
USNM	285829.5131074	Abalistes_stellatus	11.235	47.215
USNM	385558.5308008	Abalistes_stellatus	11.6125	123.76527778
NMV	A	Abalistes_stellatus	-15.1031	121.7411
NMV	A	Abalistes_stellatus	-20	116.08
CSIRO	C	Abalistes_stellatus	-16.6333	140.1783
KU	3485	Abalistes_stellatus	-11.461	143.777
KU	7211	Abalistes_stellatus	0	0
AM	I.15557-266	Abalistes_stellatus	-17.416	140.166
AM	I.22800-014	Abalistes_stellatus	-19.6	118.1
AM	E.2567	Abalistes_stellatus	-21.416	150.133
AM	I.18214-001	Abalistes_stellatus	-33.45	151.45
AM	I.16218-001	Abalistes_stellatus	-32.166	152.5
AM	I.21838-002	Abalistes_stellatus	-10.316	133.083
AM	I.21833-005	Abalistes_stellatus	-10.45	132.016
AM	I.12832	Abalistes_stellatus	-20.3	118.583
AM	I.17151-001	Abalistes_stellatus	-31.416	152.9
AM	E.2568	Abalistes_stellatus	-21.416	150.133
AM	E.2697	Abalistes_stellatus	-19.833	148.416
AM	I.22806-013	Abalistes_stellatus	-19.483	118.366
AM	E.2566	Abalistes_stellatus	-21.416	150.133
AM	I.30312-057	Abalistes_stellatus	-33.85	151.266
AM	I.33697-003	Abalistes_stellatus	-11.461	143.77715
AM	I.44703-004	Abalistes_stellatus	-14.69055	145.44249
AM	I.41421-001	Abalistes_stellatus	-36.9	150
AM	IB.5213	Abalistes_stellatus	-21	152
AM	IB.506	Abalistes_stellatus	-33.983	151.266
AM	I.831	Abalistes_stellatus	-17.316	123.633
AM	I.41421-002	Abalistes_stellatus	-36.9	150
AM	IA.2337	Abalistes_stellatus	-17.3	146.466
AM	I.44703-006	Abalistes_stellatus	-14.69055	145.44249
AM	IA.2720	Abalistes_stellatus	-25	152
CAS	35732	Abalistes_stellatus	-6.966667	106.833333
CAS	206442	Abalistes_stellatus	11.416667	99.716667
CAS	206443	Abalistes_stellatus	7.238889	134.496389
CAS	206444	Abalistes_stellatus	11.966667	99.941667
CAS	206445	Abalistes_stellatus	11.766667	100.6
CAS	206446	Abalistes_stellatus	12.3	100.383333
CAS	206447	Abalistes_stellatus	12.2	100.283333
CAS	206449	Abalistes_stellatus	12.165278	100.843333
CAS	206450	Abalistes_stellatus	12	100.5
CAS	206452	Abalistes_stellatus	12.116667	100.283333
CAS	206453	Abalistes_stellatus	12.1	101.183333
CAS	57487	Abalistes_stellatus	7.34	134.468333
UWFC	UW	Abbottina_rivularis	46.8202777777778	143.470555555556
UWFC	UW	Abbottina_rivularis	46.8305555555556	144.223888888889
UWFC	UW	Abbottina_rivularis	49.4338888888889	138.056111111111
UWFC	UW	Abbottina_rivularis	46.8372222222222	144.044722222222
USNM	336887.5237191	Abbottina_rivularis	40.31666667	116.62527778
NRM	21102	Abbottina_rivularis	23.3839	99.7
NRM	21104	Abbottina_rivularis	24.0747	98.0544
NRM	21105	Abbottina_rivularis	24.7639	98.1483
NRM	21109	Abbottina_rivularis	24.8003	98.0708
NRM	21350	Abbottina_rivularis	23.8883	97.6472
NRM	27067	Abbottina_rivularis	23.9667	97.8667
NRM	27074	Abbottina_rivularis	23.9833	97.85
NRM	27085	Abbottina_rivularis	23.9833	97.85
NRM	27195	Abbottina_rivularis	42.1186	129.4169
NRM	36423	Abbottina_rivularis	23.9044	97.5986
NRM	50640	Abbottina_rivularis	24.1781	110.8075
NRM	50641	Abbottina_rivularis	24.9839	109.3106
NRM	51145	Abbottina_rivularis	28.7167	109.6167

 
