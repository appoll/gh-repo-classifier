Homework
========

NYCDA homework
