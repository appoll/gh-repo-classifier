ASTR599_homework
================

**Note: this is the 2013 repository. If you're taking the 2014 class, you're looking for [this](https://github.com/uw-python/2014_Astr599_HW)**


Repository for students to submit homework assignments as pull requests.

Please [fork this repository](https://help.github.com/articles/fork-a-repo)
on Github, and push your homework submissions to a new branch.
You can then do a
[Pull Request](https://help.github.com/articles/using-pull-requests)
to submit your homework each week.

All homework will be listed on the [schedule page](http://www.astro.washington.edu/users/vanderplas/Astr599/schedule) of the course website.

For help on using git, I suggest the [git reference](http://gitref.org/).
