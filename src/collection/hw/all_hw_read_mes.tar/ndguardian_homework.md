homework
========

This is a bunch of homework for my N211 class. Feel free to use and modify this as you see fit.

The primary spectacle here is my Pong assignment "pong.html" which is exactly as the name implies:
It is pong, rewritten in JavaScript/HTML5 using the canvas.

Have fun.
