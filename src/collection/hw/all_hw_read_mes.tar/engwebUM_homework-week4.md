# Homework - Week 4

Take your solution for [last week's exercise](https://github.com/engwebUM/homework-week3),
apply the Design Principles and Patterns we discussed, and point out the Code
Smells you can find.

The main thing in this exercise, is to understand your thought process and how
well do you understand and apply these concepts.

Submit your revised code as a pull request, and your explanation of what you've
done should be on the pull request's description.

### What do I do if my code is already great?

Chances are that there will still be something you can do to improve your code,
but if you think there isn't, you can explain why applying a certain pattern to
your code would make it worse.
