Homework
========
What the title says. My git-versioned homework.

License
-------
All these works are copyright 2008 by elliott cable.

All these works are released under the [GNU General Public License v3.0][gpl],
which allows you to freely utilize, modify, and distribute all these works'
source code (subject to the terms of the aforementioned license).

[gpl]: <http://www.gnu.org/licenses/gpl.txt> "The GNU General Public License v3.0"