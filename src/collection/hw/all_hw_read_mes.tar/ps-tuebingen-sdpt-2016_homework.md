# Software Design & Programmiertechniken (Hausaufgaben)
In diesem Repository finden Sie die Hausaufgaben zu der Veranstaltung
[Software Design und Programmiertechniken (WS 2016)](http://ps.informatik.uni-tuebingen.de/teaching/ws16/sdpt/).


