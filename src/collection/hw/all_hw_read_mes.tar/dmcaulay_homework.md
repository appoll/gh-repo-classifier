homework
--------

A simple project that gives me an opportunity to mess around with flatiron, streams and browserify
