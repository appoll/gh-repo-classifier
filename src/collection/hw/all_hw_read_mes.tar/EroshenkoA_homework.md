homework
========

my first repo

./useless
will do what is written in uselessfile (default), try it
./useless pipefile
will do what is written in pipefile
