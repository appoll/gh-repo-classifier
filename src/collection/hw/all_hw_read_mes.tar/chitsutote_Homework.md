Homework
========
