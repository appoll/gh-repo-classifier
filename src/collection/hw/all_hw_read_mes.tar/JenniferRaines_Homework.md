# weblabSpring2015
Containing initial starting exercises and later class demos for Weblab's Spring 2015 class.

Week 1 had basic html markup exercises spelled out in README files.

In class demo work will be added later.
