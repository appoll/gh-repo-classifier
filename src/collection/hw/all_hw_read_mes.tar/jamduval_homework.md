# Homework Repository

### Purpose:

I will place each of my weekly homework assignments in this repository.

-----