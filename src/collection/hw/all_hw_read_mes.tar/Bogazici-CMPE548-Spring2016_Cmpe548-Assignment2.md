# Assignment 2

Complete the assignment as described in [hw2.pdf](hw2.pdf).


You can find the general workflow for completing and submitting homeworks in [CourseDescription](https://github.com/Bogazici-CMPE548-Spring2016/CourseDescription).
