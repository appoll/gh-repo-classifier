**Just University Stuff..**  
so don't care ;) or look for some programming examples.  
All examples are licensed under GPLv3.  
Please check the LICENSE file.
