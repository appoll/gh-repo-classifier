Homework
========

9/24