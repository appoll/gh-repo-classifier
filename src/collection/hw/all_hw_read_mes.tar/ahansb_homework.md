# homework
My homework from methods
