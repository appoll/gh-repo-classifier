== README
予防接種の予定を登録できるサイトです。
機能拡充を目指します。。。

* Ruby version
  ruby2.0.0

* Services 
  Webアプリです

* Deployment instructions
  git push heroku master

==要件
 
* has_many through で多対多のリレーションを使う
* sorcery (https://github.com/NoamB/sorcery) を使い認証機能を実装する
* Twitter Bootstrap を使う
* RSpec を使ったテスト
* Ruby 2.0 以上
* Rails 4
 
==われわれが直面している課題
日本の予防接種のスケジュールは非常にタイトです。 効率よく予防接種を受けることが求められます。
サイト上で予定表を活用して効率よく予防接種ができるといいなと思い作りましたが、 まだまだです
