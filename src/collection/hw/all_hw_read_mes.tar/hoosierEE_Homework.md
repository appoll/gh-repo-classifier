Homework
========

programming assignments

## Example Makefile

```
all:
  g++ main.cpp --std=c++0x

clean:
  rm -f *.out

```

## Resources
[makefiles](http://mrbook.org/tutorials/make/)
