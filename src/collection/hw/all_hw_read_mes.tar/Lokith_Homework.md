Homework
========

A web project to manage and do homework in SPA (Single Page Application)
