homework
========

This is a "homework" assignment done for Lillie Hejl
