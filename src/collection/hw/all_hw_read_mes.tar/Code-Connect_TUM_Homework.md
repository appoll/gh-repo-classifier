# TUM_Homework
UnitTests for current Homework

###Telegram News Channel
https://telegram.me/TUMPGdPUnitTests
###Telegram Chat Group
https://telegram.me/joinchat/CBbdCQtAOI9Qalx6JlYdcw

##Setup
Add JUnit4 to the Libraries of your Project*.

*Not required for BlueJ

###Eclipse
1. Select the Project
2. Click: Project > Properties
3. Click: Java Build Path > Libraries > Add Library...
4. Click: Junit > Next > Select Junit 4 (or highter) > Finish

https://youtu.be/CD5JJ5bDAfY?t=2m33s

###NetBeans
You don't need to use a TestFolder (it is just a bit cleaner).

https://www.youtube.com/watch?v=C6oQqbqPBB0

###IntelliJ
You don't need to use a TestFolder (it is just a bit cleaner).

https://www.youtube.com/watch?v=Bld3644bIAo

###BlueJ
BlueJ automatically comes with JUnit, thus you will not need to import it into your project. Simply copy the Java Unit Test File into your projects folder and restart BlueJ (fix any packages if required). The Unit Test should be availible, like your other classes. Simply right click it and hit Test All.
