## knitR Project: homework

This document was an old homework assignment from my computational chemistry class. At the time I used Fortran to generate the data and R/LaTeX via Sweave to make the figures and report.

The current document was used to test out different fonts using XeLaTeX, tikzDevice to generate figures with consistent fonts, and ggplot2 rather than base graphics for the figure.

It took a lot of trial and error to get the XeLaTeX and tikzDevice code working, so I wanted to post this to github for easy reference.
