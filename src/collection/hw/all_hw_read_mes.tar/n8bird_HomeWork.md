HomeWork
========

Spiecial purposes application for Python coding skills therapy. IGK2014
