Homework
========

Just a few assignments for university from earlier semesters
