For homework.
