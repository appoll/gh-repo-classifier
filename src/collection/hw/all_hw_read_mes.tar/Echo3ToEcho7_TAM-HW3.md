TAM-HW3
=======

Homework for week 3