<h1>Домашнее задание</h1>


AngularHW1 - Две директивы:smartButton и makeTransparent

AngularHW2 - Директива actionOnClickOutside

AngularHW3 - Распределенный блок radio buttons

AngularHW4 - Карусель

AngularHW5 - Джедаи



8  - Рейтинг
10 - Users Todo-list