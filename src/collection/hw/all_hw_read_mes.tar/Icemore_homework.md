homework
========

AU homework and labs
