Data sets and scripts for Coursera Big Data Specialization. 

https://www.coursera.org/specializations/bigdata
