# Core Data by [objc.io](http://www.objc.io)

This repository contains the sample code of our [Core Data book](https://www.objc.io/books/core-data):

- [The *Moody* sample project](Moody)
- [The Migrations sample project](Migrations)
- [A predicates playground](Predicates.playground)
- [Shared code](SharedCode)
