data-science-r
==============

R code and documentation for "Introduction to Data Science" by Jeffrey Stanton