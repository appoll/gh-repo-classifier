# github.io
"Bâki kalan bu kubbede bir hoş sadâ imiş." Bâki
