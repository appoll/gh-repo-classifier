This is the data for my personal website
========================================

This is the combination of two older blog dumps that I have from 2000 - 2009.  all of my atmos.org posts combined.

It is automatically transformed by Jekyll into a static site on Heroku whenever I push this repository to GitHub.

License
=======
The following directories and their contents are Copyright Corey Donohoe.  You may not reuse anything therein without my permission:

*   _posts/
*   images/

All other directories and files are MIT Licensed.
