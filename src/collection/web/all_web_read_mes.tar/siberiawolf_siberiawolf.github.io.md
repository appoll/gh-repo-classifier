我的网站是：[siberiawolf](http://siberiawolf.com)。

本站使用的是[BeiYuu.com](http://beiyuu.com)的源码，我做了部分修改和一些优化。
如果你也想使用Github Pages，请看[使用Github Pages建独立博客](http://siberiawolf.com/github-pages/)

# 推荐阅读
* [我为什么写博客](http://beiyuu.com/why-blog)
* [免费的编程中文书籍索引](http://siberiawolf.com/free_programming/index.html)

## 说明
[免费的编程中文书籍索引](http://siberiawolf.com/free_programming/index.html)整理自
[justjavac](https://github.com/justjavac/free-programming-books-zh_CN)，内容上照搬原处，只是用[Bootstrap](http://getbootstrap.com/)重新显示了一遍而已。
[查看源代码](https://github.com/siberiawolf/siberiawolf.github.io/tree/master/free_programming)

