
<html>
  <head>
  <meta charset="UTF-8" />
  <title>Edward Punales Resume</title>
  </head>
  <body>

    <header>
    <h1> Edward Punales Resume </h1>
    <address>
      <section id="contact"></section>
      2816 SW 33 AVE </br>
      Miami FL, 33133 </br>
      305-778-3522
    </address>
    </header>


   
    <h2> Skills</h2>
    <article>
    <p> Trustsworthy </p>
    <p> Diligent </p>
    <p> Excellent Communicator </p>

    </article>
  

  <h2> Education </h2>
    <article>
    <h3> Miami-Dade Collegedfddddd</h3>
    <p> Transfered out with a 3.9 GPA </p>
    <p> Made the Dean's list two years in a row </p>
    <h3> University of Miami </h3>
    <p> Has taken classes in Visual Design and Journalism </p>
    <p> Sussesfully wrote articles and designed flyers for school assignments</p>     
    </article>

  <h2>Work Experience</h2>
    <article>
    <h3> South Florida Report</h3>
    <p> Founded and Writes for <a href= "http://www.southfloridareport.com/">The South Florida Report</a></p>
    <h3>CSC</h3>
    <p> Worked Security at Ultra Music Festival, Marlins Park, and American Airlines Arena </p>
    <p> Was nominated for Employee of the Month </p>
    </article>
    </body>
</html>
