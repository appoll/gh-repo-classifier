##说明

此博客 fork 自 [cnfeat](http://cnfeat.com/)，感谢。

##张网补星光

我是胡帆，博客：[www.hufanexplore.com](www.hufanexplore.com)

生活是一场修行

现在研习 **应用物理学** 。

##坚信


- 可以发现跟大的世界
- 人与人之间可以共赢
- 写作是一种透彻思考复杂决定，直到自己获得清晰感的有效方式

