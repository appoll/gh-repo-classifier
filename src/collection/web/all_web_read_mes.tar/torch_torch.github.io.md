How to run the website:

```sh
jekyll serve -w
```
