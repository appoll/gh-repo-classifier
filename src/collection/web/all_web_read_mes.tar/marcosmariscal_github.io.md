# github.io
El hardware es lo que hace a una máquina rápida; el software es lo que hace que una máquina rápida se vuelva lenta
