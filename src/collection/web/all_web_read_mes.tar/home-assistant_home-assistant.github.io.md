# Home Assistant website

This is the source for the [Home-Assistant.io website](https://home-assistant.io).

## Setup

Setting up to contribute to documentation and the process for submitting pull requests is [explained here](https://home-assistant.io/developers/website/).

## Site preview

In order to make the preview available on [http://127.0.0.1:4000](http://127.0.0.1:4000), use the command as follows:

```bash
$ rake preview
```
