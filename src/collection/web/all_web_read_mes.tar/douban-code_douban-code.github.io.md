## douban-code.github.io

#### Quickstart

```
1. virtualenv venv
2. . venv/bin/activate
3. pip install pelican
4. pip install Markdown
5. make html
6. make serve
```

Go to: `http://localhost:8000`
