sheetjs.github.io
=================

[![Selenium Test Status](https://saucelabs.com/browser-matrix/sheetjs.svg)](https://saucelabs.com/u/sheetjs)

Source for the website <http://oss.sheetjs.com>

Stress tests are available at <http://oss.sheetjs.com/stress.html>

[![githalytics.com alpha](https://cruel-carlota.pagodabox.com/d2855923df866bf087036028d7e908d0 "githalytics.com")](http://githalytics.com/SheetJS/SheetJS.github.io)
