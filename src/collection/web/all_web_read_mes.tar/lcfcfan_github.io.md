# Set up first jekyll / github on own domain

Hopefully this well be a local site on github and accessed via my own domain
