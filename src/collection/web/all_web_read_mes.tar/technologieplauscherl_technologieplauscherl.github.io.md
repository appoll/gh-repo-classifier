technologieplauscherl.at
========================

Die Website für das Tech-Meetup in Linz -> [technologieplauscherl.at](http://technologieplauscherl.at)

## Talk via Pull Request

Du darfst dich gerne selbst als Speaker für das nächste Plauscherl auf der Website eintragen: Aktuelles Plauscherl nehmen, und Folgendes hinzufügen:

```
-
  name: <Dein Name>
  talk: <Dein Talk>
  img: <Bild (ohne http: nur mit //) zu deinem Facebook/Google/Twitter Foto>
```
