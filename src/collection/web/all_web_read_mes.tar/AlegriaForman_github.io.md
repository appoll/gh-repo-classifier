# github.io
# SEA-201n1_Assn2

Prompt will pop-out and asks the guest's name.

Extra feature:
Click on 'Guessing Game.'
It will ask three questions and it will prompt you whether you correctly or incorrectly answered the questions.  At the end, it will give you the total score.

by Ali Forman
201 Class - CodeFellows
Nov. 2, 2015

Bonus - Programming Jokes

Algorithm (noun) - Word used by prgrammers when they do not want to explain what they did.

Pair Programming Driver: Tim Forman, Navigator: Ali Forman

Changes made:
Put questions and answers into arrays.
Created counter in document using:
'''guess += 1;
document.getElementById('score').innerHTML = guess;'''
