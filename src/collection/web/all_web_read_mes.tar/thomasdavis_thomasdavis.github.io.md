**Contact:**

*   @neutralthoughts on twitter
*   thomasalwyndavis@gmail.com

**Projects:**

*   Javascript Library CDN - http://cdnjs.com
*   Backbone.js Tutorials - http://backbonetutorials.com
*   Technical Blog - http://thomasdavis.github.com

Love you mum!
