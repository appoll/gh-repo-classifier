# About

Personal website of [Gaston Sanchez](http://gastonsanchez.com), based on [Mark Otto's](https://github.com/mdo) [Hyde](https://github.com/poole/hyde) theme.
