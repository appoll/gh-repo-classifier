HTML WG -- Encrypted Media Extensions
===============

This is the repository for the Encrypted Media Extensions Editor's Draft.

The latest Editor's Draft is at https://w3c.github.io/encrypted-media/.
