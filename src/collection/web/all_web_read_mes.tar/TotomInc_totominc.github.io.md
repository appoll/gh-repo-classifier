#[totominc.github.io - homepage](http://totominc.github.io/)

###[Blackmarket - incremental-game](http://totominc.github.io/blackmarket)
Another simple incremental-game, about selling drugs. You start with only a gun, and you have to build a drug empire to become trillionnaire. Blackmarket was my first really big project about in HTML/CSS/JS. It has been totally re-done : scripts and interface. Blackmarket has reach its official release, take a look now!

###[Universe-Builder - link to github repo](https://github.com/TotomInc/universe-builder)
The new project I'm currently working on.

###[Idle-Quester](http://totominc.github.io/idle-quester)
Idle-Quester is a web version of the original app/game [Idle-Quest](https://play.google.com/store/apps/details?id=com.topcog.idlequest.android) for Android. This was only made in few hours, so maybe you can expect it be 'slightly' buggy.

###[inc-game-rreader](http://totominc.github.io/inc-games-rreader)
I wanted to make a fun and small project to use an API, and since /r/incremental_games is my favourite subreddit, I made an alternative website to browse it, and looks pretty nice!

###[Money-Life (old)](http://totominc.github.io/moneylife/old/)
My very first small project to learn JS, it's just an [Adventure Capitalist](http://www.kongregate.com/games/hyperhippogames/adventure-capitalist) clone.

###[Incremental-RPG](http://totominc.github.io/incremental-rpg)
My second project in JS, where I wanted to focus more on design using Bootstrap and some free themes.

###[Universe-God](http://totominc.github.io/universe-god)
One of my latest projects, and will always stay as a prototype.