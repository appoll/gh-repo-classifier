pml_2014
========

Submission of class project for Practical Machine Learning (Coursera)
