Using GitHub Jeklly Markdown to Write Blog

Visit [HomePage](http://minixalpha.github.io)

[Introduction](https://github.com/minixalpha/minixalpha.github.io/blob/source/_posts/2014-02-15-github-jekyll-markdown.md)(chinese version):
An introduction about how to create a free blog using GitHub and Jeklly. 
