# Sirupsen.com

My personal website and blog. I [blogged about it](http://sirupsen.com/the-switch-to-github-pages).

All rights reserved.
