DSSG Website
==============

This is the [website](http://dssg.github.io) for the Data Science for Social Good program. 

It's built with [Jekyll](http://jekyllrb.com), a simple blogging tool that generates static html files, 
and uses [Twitter bootstrap](http://twitter.github.com/bootstrap/) for look and feel.

The site is hosted with [Github pages](http://pages.github.com). Writing is done in [Prose.io](http://prose.io/).
