The most complete documentation currently available:

"The MSYS2 Sourceforge Project page":
https://sourceforge.net/p/msys2/wiki/Home/
