![Hack In The North](static/images/logo-with-gh.png)

##Contributing
Feel free to send a pull request that you think makes the website better. We are always open to ideas. Only static files.

##How to run the website
```bash
git clone https://github.com/HackInTheNorth/HackInTheNorth.github.io
cd HackInTheNorth.github.io
python -m SimpleHTTPServer
```

Now browse to http://localhost:8000
