# THIS GEM IS DEPRECATED #

* The `push`/`pull` functionality is now provided by our new [command line client](https://github.com/phrase/phraseapp-client).
* The In-Context-Editor can now be integrated in your ruby app with our new [phraseapp-in-context-editor-ruby gem](https://github.com/phrase/phraseapp-in-context-editor-ruby)
* For custom integrations you can use our new [phraseapp-ruby gem](https://github.com/phrase/phraseapp-ruby) that provides a library for interacting with PhraseApp APIv2 
