jsTree-directive
================

An Angular Directive for jsTree

* [Documentation](http://jstree-directive.herokuapp.com/#/basic)

Install using `bower`

```bash
$ bower i jstree-directive
```

### Tutorial 

[Building a Web Based File Browser with jsTree, Angularjs and Expressjs](http://thejackalofjavascript.com/file-browser-with-jstree-angularjs-and-expressjs)

**_PS : Do note that if you want to make your app 100% Angular, load the jsTree Javascript source using an Angular provider as a dependency to jstree.directive._**
