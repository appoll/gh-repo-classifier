[![npm version](https://badge.fury.io/js/react-gm.svg)](https://badge.fury.io/js/react-gm)

[文档and demo](http://gmfe.github.io/react-gm/)
