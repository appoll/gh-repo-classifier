django-extension-docs-zh
========================

django extensions docs, translated into Chinese

django-extensions 的中文文档.推荐使用Django项目的人在开发环境下安装这个插件,功能十分强大.

中文版文档会跟随官方文档的版本而更新,该文档现在也是被官方链接的中文版文档.

在线文档地址: https://django-extensions-zh.readthedocs.io/zh_CN/latest/

如果发现文档中的错误欢迎纠正.纠正的内容可以在当前项目下 pull request,或者留言.
