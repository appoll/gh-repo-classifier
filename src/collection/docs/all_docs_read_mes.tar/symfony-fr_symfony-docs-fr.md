Documentation de Symfony
========================

Attention, cette documentation n'est plus à jour et le dépot n'est plus maintenu.
La seule documentation officielle et à jour est celle en anglais, disponible sur symfony.com.

Merci à celles et ceux qui ont contribué à maintenir ce dépot à jour pendant plusieurs années.

Contribuer
----------

Merci de lire la page d'[informations sur les contributions](CONTRIBUTING.md).

Discuter de la documentation
----------------------------

Vous pouvez nous contacter sur IRC à l'adresse suivante: #symfony-fr-docs@irc.freenode.net
