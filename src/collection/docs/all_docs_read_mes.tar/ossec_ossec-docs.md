## OSSEC Documentation 

[![Build Status](https://travis-ci.org/ossec/ossec-docs.svg?branch=master)](https://travis-ci.org/ossec/ossec-docs)

## Build/Automation

All changes to this repo trigger travis-ci to generate the html output and push that html out to https://github.com/ossec/ossec.github.io

Full details please see the .travis.yaml file for how this works. 
