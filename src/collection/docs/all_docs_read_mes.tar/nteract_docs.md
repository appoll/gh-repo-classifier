# docs
Because we like people to be able to read things and docs enable more people to get involved and using the project.

- [FAQ](./faq.md)  
