OpenElections Documentation
===========================

This repository contains documentation for The OpenElections project, including volunteer guides, a glossary of key terms and more to come. 

Viewable at http://docs.openelections.net
