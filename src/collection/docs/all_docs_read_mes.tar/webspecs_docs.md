# Documentation

The content that generates https://specs.webplatform.org/docs/.

Note: if patching, you have to run the generator locally, it's not automatic.
