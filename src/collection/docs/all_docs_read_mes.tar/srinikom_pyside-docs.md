pyside-docs
===========
Temporary docs for PySide until website is up.

[Sep 27 2012]
