# Bison Documentation

This is the `_content/docs/` folder used on [the Bison website](http://builtwithbison.com/docs).  
Anything in the `master` branch here should reflect whats on there.

Writing documentation is tough. There are good chances that some things get left off, become outdated or are just flat-out incorrect. 

Thats where you come in. If you see something that needs fixing: please feel free to fork, edit and create a pull request.