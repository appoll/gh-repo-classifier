# docs

To run:

```
git submodule init
git submodule update
npm install
npm start
```
