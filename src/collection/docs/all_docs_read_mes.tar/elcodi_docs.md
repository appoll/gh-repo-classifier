# Elcodi Documentation

This documentation is rendered online at 
[http://elcodi.io/docs](http://elcodi.io/docs)

* [Quick Start](http://elcodi.io/docs/quick-start/)
* [The Book](http://elcodi.io/docs/book/index.html)
* [The Components](http://elcodi.io/docs/components/index.html)
* [The Cookbook](http://elcodi.io/docs/cookbook/index.html)

### Support

* You can ask your questions to the community in 
[Gitter](http://gitter.im/elcodi/elcodi) and we'll try to help you as much as
possible
* Look for some help on [Stackoverflow](http://stackoverflow.com)
* Ping us on [Twitter](http://twitter.com/elcodi_dev)
* As a last resort, look at [google](http://google.com)!