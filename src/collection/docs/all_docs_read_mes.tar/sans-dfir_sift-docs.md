# SIFT Documentation

Documentation for SANS Investigative Forensic Toolkit

This repository is used by Read the Docs to create the documenation website.

Please submit pull requests here to alter the documentation, if you have an issue with the documentation and are unable to submit a pull request, create the issue here https://github.com/sans-dfir/sift/issues
