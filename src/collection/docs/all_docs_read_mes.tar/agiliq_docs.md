This is a dump of things in the [Agiliq blog](http://agiliq.com/blog/).

Most of the things here are in the markdown format.
