ZtbCMS 文档 [![Build Status](https://travis-ci.org/ztbcms/docs.svg?branch=develop)](https://travis-ci.org/ztbcms/docs)
=======


### 环境需求

Node.js 4.x以上

### 开始构建

```shell
$ npm install gitbook-cli -g
$ gitbook install
$ gitbook serve
```
