docs
=====

CloudSlang documentation.
Avaliable at [readTheDocs](http://cloudslang-docs.readthedocs.org/)

[![Circle CI](https://circleci.com/gh/CloudSlang/docs/tree/master.svg?style=svg)](https://circleci.com/gh/CloudSlang/docs/tree/master)
