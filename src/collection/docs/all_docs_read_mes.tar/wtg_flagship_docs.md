== FLAGSHIP DOCS ==
= A 2009-2010 production of the RPI Web Tech Group (http://webtech.union.rpi.edu) =

Flagship Docs is a document management system that is pure, to the point, and easy to deploy and use in organizations of various sizes.  It features a clean, intuitive user interface, powerful search functionalities, and per-organization control and display options.
