Docs
====

to-do list:

1. 先各模块搭建在centos 6上，run起来即可 （1-2w）
 * <del>router （done by zhaodch）<del>
 * <del>cloud_controller （done by limy）<del>
 * <del>dea   (done by limy)<del>
 * <del>warden （done by limy）<del>
 * <del>health_manager （done by zhaodch）<del>
 * <del>uaa (done by zhaodch )<del>

2. 联调
 * 完成注册，push发布应用等流程

3. 开发辅助功能
 * dashboard
 * ldap账号集成
 * 新框架&语言支持

4. 文档撰写
 * 安装文档
 * 技术文档
 * 各组件之间的细节（类似http://apidocs.cloudfoundry.com 但要基于CC V2.0）并作为官方文档（http://cloudfoundry.github.com）的有效补充 

5. 待定
