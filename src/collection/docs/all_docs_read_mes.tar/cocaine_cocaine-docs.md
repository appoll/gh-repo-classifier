Documentation
================

**Cocaine** is an open-source cloud platform enabling you to build your own PaaS clouds using simple yet effective dynamic components.

Documentation in English can be found [here](https://github.com/cocaine/cocaine-docs-en/wiki).