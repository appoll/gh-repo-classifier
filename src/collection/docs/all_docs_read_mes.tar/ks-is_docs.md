# docs

[![docs](icon/docs.png)](https://github.com/ks-is/docs)
[![chat](icon/chat.png)](https://gitter.im/ksis-group/chat)
[![fb](icon/fb.png)](https://www.facebook.com/groups/kmasouth.is)
[![meetup](icon/meet.png)](https://github.com/ks-is/meetup/issues)

* [Thông tin nhóm](thong_tin_nhom.md)

* [Hoạt động nhóm](hoat_dong_nhom.md)

* Đang cập nhật ...

