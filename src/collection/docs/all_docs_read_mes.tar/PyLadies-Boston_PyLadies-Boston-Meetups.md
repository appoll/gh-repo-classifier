PYLADIES BOSTON
===============

This is a repository of code used for PyLadies Boston meetups.
We have two types of meetups right now: 
* **beginner meetups**, where we run through Learn Python the Hard Way
* **regular meetups**, where we cover more general topics that are applicable to Python programmers of all levels

This repository is organized by type of meetup, then by date. Please email boston@pyladies.com with any questions.
