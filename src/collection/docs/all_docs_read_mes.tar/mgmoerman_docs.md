[link_obs_alert_doc]: https://github.com/mgmoerman/docs/blob/master/observium-alert-checkers.md
[link_obs_syslogalert_doc]: https://github.com/mgmoerman/docs/blob/master/observium-syslog-alerting.md
[link_aclhound_doc]: https://github.com/job/aclhound/blob/master/DOCUMENTATION.md

docs
====

I'll add some documentation which i've written here

*  [observium alert checkers][link_obs_alert_doc]
*  [observium syslog alerting][link_obs_syslogalert_doc]
*  [aclhound][link_aclhound_doc]
