# docs

To run:

```
git clone --recursive https://github.com/apollostack/react-docs.git
cd react-docs
npm install
npm start
```
