The Theos Documentation (theos-ref)

For generating HTML output:
- Use ./genhtml.sh

For changing layouting:
- Change theosref.css

Please contribute to RefMarkup.pl!

For contributing:
- Please notify theiostream of your intentions. If recommended to contribute, create a fork and make a pull request.
- Regardless of whether your pull request was merged or deleted, your fork should be deleted unless recommended not to by theiostream.
- DO NOT FIX GIT'S WHITESPACE WARNINGS ELSE YOU RISK BREAKING THE LINE BREAK SYSTEM.

Licensed under the Creative Commons Attribution-ShareAlike 2.0 Generic License (http://creativecommons.org/licenses/by-sa/2.0/).

(c) 2013 Bacon Publishing, LLC
         Daniel Ferreira
         Dustin Howett
