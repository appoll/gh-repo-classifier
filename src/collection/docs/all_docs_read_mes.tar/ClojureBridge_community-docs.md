Here're some supportive materials for ClojureBridge workshop.

All contents are in gh-pages branch.


Web site is http://clojurebridge.github.io/community-docs/index.html


Check it out!