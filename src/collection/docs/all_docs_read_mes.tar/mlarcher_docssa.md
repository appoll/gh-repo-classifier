<img src="https://raw.githubusercontent.com/mlarcher/docssa/master/assets/img/title.jpg" alt="DoCSSa {dok~sa}">
===============

DoCSSa - Sass based CSS architecture and methodology

See it live at [mlarcher.github.io/docssa](http://mlarcher.github.io/docssa/)

Note: even though DoCSSa's principles can be used with any version of Sass, some parts of the provided implementation
rely on the 3.3 version (i.e. the crossmedia placeholders feature). DoCSSa is all about guidelines though, so feel free
to adapt it as needed.

## Creators

**Matthieu Larcher**

- <http://twitter.com/larchermatthieu>
- <https://github.com/mlarcher>

**Fabien Zibi**

- <http://twitter.com/_faz>
- <http://github.com/dahfazz>
