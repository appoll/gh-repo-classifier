# Sessions

<h3>TinkerEves:</h3> <br>
TinkerEve[0]: Intro - hosted on 25-08-2015</br>
TinkerEve[1]: Power Supply Design - hosted on 01-09-2015 <br />
TinkerEve[2]: 3D Printing (Slides not available) - hosted on 10-09-2015<br />
TinkerEve[3]: PCB Design - hosted on 16-09-2015<br />
TinkerEve[4]: Discussion for Projects (Slides not available) - hosted on 29-09-2015 <br />

<h3>TinkerNights:</h3> <br>
TinkerNight[1]: Basics of Embedded Programming - hosted on 06-10-2015 <br />
TinkerNight[2]: Basics of ADC and Timers - hosted on 12-10-2015<br />

<h3>Tech-Quizzes:</h3> 
Tech-Quiz[1]: Signal Processing, Analog electronics, Embedded Systems and Robotics  - hosted on 27-10-2015<br />
