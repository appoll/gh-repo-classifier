## README file for Jay's kvm-book.git repository.
[https://github.com/smilejay/kvm-book.git](https://github.com/smilejay/kvm-book.git)

git://github.com/smilejay/kvm-book.git

## Description
This repository includes the scripts and config files for my KVM book.

部分章节连载：[http://smilejay.com/kvm_theory_practice/](http://smilejay.com/kvm_theory_practice/)

正式发布和本书勘误： [http://smilejay.com/kvm-principles-and-practices/] (http://smilejay.com/kvm-principles-and-practices/)

Any questions, please contact me via smile665@gmail.com or [http://smilejay.com/](http://smilejay.com/)


Just for fun.

    thanks,

        Jay.
