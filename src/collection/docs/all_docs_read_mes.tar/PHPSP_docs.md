# Documentos 

>Documentos relacionados à comunidade

## Código de Conduta
> Recomendações gerais para o bom convívio em eventos do PHPSP
https://github.com/PHPSP/docs/blob/master/codigo-de-conduta.md
