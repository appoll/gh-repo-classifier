# Diablo 3 Web API

All documentation for any Blizzard community APIs has been moved to our
developer site: https://dev.battle.net/

You can also find information on our forums:
http://us.battle.net/en/forum/15051532/
