A public collection of Seer Interactive's Google Docs functions 

google_scraper.js: Google Scraper for Google Docs Spreadsheet.
has_google_results.js: Determine if there are any results for a given a keyword / site.
seomoz.js: Wrapper for SEOmoz API
