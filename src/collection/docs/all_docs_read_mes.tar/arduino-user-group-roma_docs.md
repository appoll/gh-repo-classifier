Documentazione e wiki dell'Arduino User Group Roma
====

Benvenuto! Qui trovi la wiki e la documentazione condivisa dai partecipanti.
Sei più che invitato ad iscriverti e contribuire.

https://groups.google.com/forum/#!forum/aug-roma



