# lesscss.org

> Official website and documentation for LESS/Less.js


### [Visit the website](http://lesscss.org)

### [Visit Less.js](https://github.com/less/less.js)


Please go to the [main branch](https://github.com/less/less-docs) for source files.

## Contributing
In lieu of a formal styleguide, take care to maintain the existing coding style. Add unit tests for any new or changed functionality. Lint and test your code using [Grunt](http://gruntjs.com).

## Release History
_(Nothing yet)_
