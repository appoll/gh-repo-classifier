Laravel 文档中文版翻译
===============


本人只是随性翻译个别章节，具体翻译源项目参见  https://github.com/RaymondChou/Laravel-cn-docs 
