logstash-docs
=============

Documentation repository for Logstash static asciidoc and generated plugin asciidoc.

# GENERATED REPOSITORY
# DO NOT EDIT
# HUGS.
