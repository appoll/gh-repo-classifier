google-docs
===========

Libraries and functions used within Google Docs