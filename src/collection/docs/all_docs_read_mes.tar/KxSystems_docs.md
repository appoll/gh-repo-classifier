# Kx documentation
Rebuild of [code.kx.com](http://code.kx.com/) using [MkDocs](http://mkdocs.org) static site generator 
