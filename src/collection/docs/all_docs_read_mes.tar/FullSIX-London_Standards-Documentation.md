# Standards-Documentation

[![Gitter](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/FullSIX-London/Standards-Documentation?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)