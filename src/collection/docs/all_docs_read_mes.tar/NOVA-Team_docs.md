[![Build Status](https://img.shields.io/travis/NOVA-Team/docs.svg?style=flat-square)](https://travis-ci.org/NOVA-Team/docs)

# NOVA Docs
Documentation for NOVA

Feel free to contribute.
