some notes on CTFs.
