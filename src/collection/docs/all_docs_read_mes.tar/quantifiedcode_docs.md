#Python code patterns

#Description

This is the documentation of [QuantifiedCode](https://www.quantifiedcode.com). Feel free to suggest changes, make improvements or add content to it.

#Licence

![Creative Commons License](https://i.creativecommons.org/l/by-nc-sa/4.0/80x15.png) This work is licensed under a [Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License](http://creativecommons.org/licenses/by-nc-sa/4.0/).
