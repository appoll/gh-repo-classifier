# Flask 简体中文文档

## 关于译者
由 Dormouse Young 发起并独立翻译，其余参与和修正伙伴参见contributors。

Initiate and translated by Dormouse Young.

## 版本

现在正在翻译的是 Flask 0.11.1 的文档。

Flask 0.11.1 docs are being translating now.

## 线上地址

[http://dormousehole.rtfd.org](http://dormousehole.rtfd.org)

## 制作本地文档

### Html 文档

主要步骤为：
* 克隆本项目
* 安装 sphinx
* 生成文档（文档生成在 _bulid 目录下)

命令示例：
```shell
git clone git@github.com:dormouse/Flask_Docs_ZhCn.git
cd Flask_Docs_ZhCn/
mkvirtualenv flaskdoc
pip install flask==0.11.1
pip install sphinx
make html
```



