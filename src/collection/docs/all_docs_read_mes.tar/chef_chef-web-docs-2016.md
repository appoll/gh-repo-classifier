**THIS REPO HAS BEEN DEPRECATED**. Please submit all issues and PRs against https://github.com/chef/chef-web-docs.

What happened? Chef refactored the chef-web-docs repo to remove the commit history so that our continuously delivered documentation builds faster. The previous history can be found in this chef-web-docs-2016 repo, but really, the https://github.com/chef/chef-web-docs repo is the one we're using to build the documentation. 

Thanks for your continued contributions to the documentation for Chef!

-- docs team
