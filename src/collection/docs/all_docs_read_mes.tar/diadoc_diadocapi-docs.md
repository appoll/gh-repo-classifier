# Diadoc SDK

[![Documentation Status](https://readthedocs.org/projects/diadoc-sdk/badge/?version=latest)](https://readthedocs.org/projects/diadoc-sdk/?badge=latest)

HTTP-API - интерфейс для интеграции с произвольными учетными системами. Вариант подходит для работы с различными учетными системами, написанными на языке C# под платформу .NET и запускающиеся на машинах с ОС Microsoft Windows, или на Java/C++, запускающиеся на машинах под управлением ОС Linux

Документация доступна по следующей ссылке [readthedocs](http://api-docs.diadoc.ru/).