## License

Public domain under [Creative Commons 0](http://creativecommons.org/publicdomain/zero/1.0/). 
No rights reserved.

[CC0 FAQ](http://wiki.creativecommons.org/CC0_FAQ).

## Use at your own risk

Papertrail does not warrant that these are suitable for any purpose.
These do not replace an attorney. Any use of these contracts is at your
own risk and should be under the guidance of your own legal advisor.

## Use

Find for occurrences of `[`, which represent a placeholder. Globally
replace each of the placeholders with the appropriate value for your
situation.
