n64docs
============================
If you're looking for docs on the N64... congrats, you're at the right place. Sadly,
nobody cared to clean this pile of junk up, so if you want something you'll have to
wade through all the cruft.

Ideally, this will all wind up in a more organized form on the website, but "ain't
nobody got time for that".
