A savoir : plusieurs versions du script Alertes leboncoin sont disponibles :
---------------------------------

* [Alertes leboncoin - géré par **mlb**](https://github.com/maximelebreton/alertes-leboncoin)  :  
  *mise à jour semi-automatique du code, email responsive, paramètres utilisateurs, affichage d'une mini carte, mails individuels ou groupés*  

* [Alertes leboncoin - géré par **jief666**](https://github.com/jief666/alertes-leboncoin) :  
  *description à venir...*  

* [Alertes leboncoin - géré par **jfallot**](https://github.com/jfallot/alertes-leboncoin) :  
  *Basée sur la version 2.x, cette version supporte les dernières évolutions du site le BonCoin et plusieurs améliorations dans les emails de résultats de recherche*  


Alertes leboncoin
====================

Script d'alertes email leboncoin.fr via Google Docs

Créé par Just docs it : http://justdocsit.blogspot.fr/2012/07/creer-une-alerte-sur-le-bon-coin.html  
Version 2.x : http://justdocsit.blogspot.com/2012/11/alerte-leboncoin-v2.html  

[Mise à jour 06/2016]  
**4.0** - Nouveau fork par mlb : https://github.com/maximelebreton/alertes-leboncoin

Pour suivre les évolutions abonnez vous à la page google plus d'alerte lbc : https://plus.google.com/u/0/b/116856005769817085204/116856005769817085204/posts


Modifications apportées par la version 2.0 :
- support de la date 
- support des images
- style css de l'email

