This is the source for the SublimeLinter 3 documentation at http://sublimelinter.readthedocs.org.
