# craftml-docs
Craftml Docs


# Deployment

# Deploy to gh-pages

    $ wintersmith build

    $ git add build

    $ git commit -m 'build' 

    $ git subtree push --prefix build origin gh-pages

    