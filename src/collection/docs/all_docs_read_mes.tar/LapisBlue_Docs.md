# LapisBlue Docs
#### ~ [docs.lapis.blue](http://docs.lapis.blue)
[![travis badge](https://travis-ci.org/LapisBlue/Docs.svg)](https://travis-ci.org/LapisBlue/Docs)

These are our automatically hosted and generated documentation.
You can edit any markdown files on this master branch and Travis will automatically
build the documentation and Github will automatically host it! w00t!

All markdown is hosted in docs/.