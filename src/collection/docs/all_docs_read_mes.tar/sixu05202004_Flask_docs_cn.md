Flask_docs_cn
=============

flask 0.10 docs 中文版

pattern 文件夹的翻译来自 https://github.com/dormouse/Flask_Docs_ZhCn
部分翻译整合于 https://github.com/yinian1992/flask-docs-cn

