docs
====

Documentation for Pinoccio Scout's field guide and API
