GRIFO Portfolio
==================

Text Editor — <a href="http://www.sublimetext.com" target="_blank">Sublime</a>

Language — <a href="http://coffeescript.org" target="_blank">CoffeeScript</a> 

Framework — <a href="http://backbonejs.org" target="_blank">Backbone.js</a> 

Grid System — <a href="http://isotope.metafizzy.co/" target="_blank">jQuery Isotope plugin</a>

Background Canvas Animation — <a href="http://paperjs.org" target="_blank">Paper.js</a> 

CMS — <a href="https://docs.google.com/spreadsheet/pub?key=0AuMegPFV2btJdGFIMWE1V0VvOUFuUlVpWXp3UXlwQ1E&output=html" target="_blank">Google Docs spreadsheet</a> 



***Work in progress***


Full documentation coming soon.