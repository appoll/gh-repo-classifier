# The following docs are sunset. 

### [megamsys/docs](https://github.com/megamsys/docs) repository 

Refer [docs.megam.io](docs.megam.ioi)

# Author

Humans <humans@megam.io>

# License

Creative Commons
