This repository was created automatically using https://github.com/lazka/pgi-docgen

It contains a static website which can be viewed at http://lazka.github.io/pgi-docs/

It also works offline: http://github.com/lazka/pgi-docs/archive/gh-pages.zip
