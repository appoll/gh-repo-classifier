toolchain-site
==============

This repo is for Perl toolchain docs, specs, guidelines, etc.

A lot of this information is scattered across blogs, sites, repos,
modules, etc.  Some of it is ephemeral.  This repo is intended to
pull it together or provide authoritiative pointers.

Initially, we'll dump docs here.  Down the line, we should use
github pages to create a site to serve it up.

