plupload_docs
=============

plupload 的中文文档及演示demo

教程：<http://www.cnblogs.com/2050/p/3913184.html>
