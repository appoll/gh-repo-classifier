TACTIC Docs
===========

TACTIC Documentation

This repository contains the docs for TACTIC.  The source uses ASCIIDoc (http://www.methods.co.nz/asciidoc/).  This was converted from the orignal Docbook format.  This repository is still alpha as we migrate the build scripts and incorporate output formats into the community site and to TACTIC itself.

Scripts to build the documentation are located in the "bin" folder.  ASCIDOC is required to build the outputs.

The TACTIC source code can be found at https://github.com/Southpaw-TACTIC/TACTIC


