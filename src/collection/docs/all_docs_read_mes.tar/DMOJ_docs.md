# DMOJ Documentation
Documentation for the [DMOJ judge](https://github.com/DMOJ/judge) system.

Access at [https://dmoj.readthedocs.org](https://dmoj.readthedocs.org)
