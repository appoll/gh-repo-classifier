This repository contains source files for the [Zanata docs]
(http://zanata.org/docs).
