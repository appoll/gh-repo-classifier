# docs - Documentos del Flisol Venezuela

Acá encontrarás los documentos (legales, etc.) relacionados con la organización de los distintos Flisol en Venezuela. Puedes tomarlos como base para realizar su propios documentos y contribuir a mejorar los existentes. El repositorio será organizado en branchs por años en caso de que se aplique, cualquier sugerencia es bienvenida.
