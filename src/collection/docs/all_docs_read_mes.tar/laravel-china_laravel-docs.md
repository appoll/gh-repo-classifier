此文档由 [Laravel China 社区](https://laravel-china.org/) 翻译整理，翻译权由 [Laravel China 社区](https://laravel-china.org/) 享有，转载必须保留出处 https://laravel-china.org/docs 。
