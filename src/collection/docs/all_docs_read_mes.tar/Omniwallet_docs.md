docs
====

See [the business plan](https://github.com/Omniwallet/docs/blob/master/BusinessPlan.md).
