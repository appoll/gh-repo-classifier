docs
====

This is where I keep various docs and howtos that I mostly write for myself so I don't forget how to do stuff.

Writing documentation is after all one of the aspects of system administration.

