Documentation for the Cloud Orchestrator
