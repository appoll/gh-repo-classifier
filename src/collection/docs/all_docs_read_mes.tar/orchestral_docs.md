Orchestra Platform Documentation
==============

[![Join the chat at https://gitter.im/orchestral/platform](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/orchestral/platform?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

This repository contains the documentation of the Orchestra Platform. If you want to build an application using Orchestra Platform on Laravel, visit [the main repository](https://github.com/orchestral/platform).
