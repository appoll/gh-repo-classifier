enb-bem-docs
============

[![NPM version](https://img.shields.io/npm/v/enb-bem-docs.svg?style=flat)](http://npmjs.org/package/enb-bem-docs) [![Build Status](https://img.shields.io/travis/enb/enb-bem-docs/master.svg?style=flat)](https://travis-ci.org/enb/enb-bem-docs) [![Dependency Status](https://img.shields.io/david/enb/enb-bem-docs.svg?style=flat)](https://david-dm.org/enb/enb-bem-docs)

Установка:
----------

```
$ npm install --save-dev enb-bem-docs
```

Для работы модуля требуется зависимость от пакетов `enb-magic-factory` версии `0.3.x`  или выше, а также `enb` версии `0.13.0` или выше.

Лицензия
--------

© 2014 YANDEX LLC. Код лицензирован [Mozilla Public License 2.0](LICENSE.txt).
