ElkarBackup
======

[ElkarBackup](http://elkarbackup.org) is a free open-source backup solution based in [RSnapshot](http://www.rsnapshot.org)

Documentation is build with [GitBook](https://www.gitbook.io) project. So you can get it in HTML, PDF or Ebook format.

version v1.2.0-pre-alpha3

[![Build Status](https://www.gitbook.io/button/status/book/elkarnet/elkarbackup)](https://www.gitbook.io/book/elkarnet/elkarbackup/activity)
