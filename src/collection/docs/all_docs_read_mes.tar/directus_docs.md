<p align="center">
<img src="https://s3.amazonaws.com/f.cl.ly/items/3Q2830043H1Y1c1F1K2D/directus-logo-stacked.png" alt="Directus Logo"/>
</p>

Directus Documentation & User-Guide
====================
This is the complete documentation of the Directus framework. Available with a history of changes from version 6.0 on. For those interested in helping build, correct, or clarify the Directus documentation – please submit pull-requests to this repo.


**[Web Formatted Version](https://getdirectus.com/docs)** – _The web version of this repository_
