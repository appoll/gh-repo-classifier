docstore: Simple document storage
===

docstore is a simple way to serve Markdown files without any
server-side processing, and without requiring you (as the author) to
recompile every time you change an article. It consists of a very
simple JS script that makes an ajax request to your server, runs a
Markdown processor on what it finds, and then displays the results.
Clone the repository and add articles in the text/ directory to get started.
