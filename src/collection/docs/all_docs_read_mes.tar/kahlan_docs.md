## Kahlan Documentation

The documentation is managed by [couscous](http://couscous.io)

## Getting started

```
composer global require couscous/couscous
```

## Documentation Preview

```
couscous preview
```

## Documentation Deploy

```
couscous deploy
```
