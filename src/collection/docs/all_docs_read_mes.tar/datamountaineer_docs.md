# Documentation for Datamountaineer and the Stream Reactor architecture

[Docs](http://streamreactor.readthedocs.io/en/latest/)

clone docs,stream-reactor and kafka-connect-tools

Then run init.sh to copy the rst's to source/

The index.rst points to connector.rst, tools.rst and socket-streamer.rst.

remove the cloned repos at the end. Can't get RTD working with submodules.
