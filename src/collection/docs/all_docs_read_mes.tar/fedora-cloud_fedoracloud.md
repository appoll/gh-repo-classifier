This is the git repo for Fedora Cloud docs. It is written in reStructured Text format using sphinx.

These docs are live at https://fedoracloud.readthedocs.io
