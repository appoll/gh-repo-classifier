# Zephir Documentation

## Welcome

This is the repository for the [Zephir](https://zephir-lang.com) documentation.

You are welcome to fork this repository and add, correct, enhance the
documentation yourselves.

The documentation language is [reStructuredText](http://www.sphinx-doc.org/en/stable/rest.html)

You need to install the [Zephir Lexer for Pygments](https://github.com/phalcon/zephir-lexer)
if you want to generate the documentation.
