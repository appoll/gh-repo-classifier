# docs
:notebook: Documentation for graph.cool

## Development

master | dev
--- | ---
[![CircleCI](https://circleci.com/gh/graphcool/docs/tree/master.svg?style=svg)](https://circleci.com/gh/graphcool/docs/tree/master) | [![CircleCI](https://circleci.com/gh/graphcool/docs/tree/dev.svg?style=svg)](https://circleci.com/gh/graphcool/docs/tree/dev)

```sh
npm install
npm start
```
