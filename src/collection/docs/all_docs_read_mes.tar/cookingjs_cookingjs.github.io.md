# cooking.github.io
> cooking docs

## Development
```shell
$ make dev
```

## Deploy
```shell
$ make deploy
```
