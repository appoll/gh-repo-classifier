# artificial-intelligence
SEU Aritificial Intelligence Assignments & Docs
