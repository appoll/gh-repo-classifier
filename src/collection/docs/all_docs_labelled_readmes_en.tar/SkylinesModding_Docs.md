# Skylines Modding Documentation

For more information on how to contribute, check [How to Contribute to the Docs](http://docs.skylinesmodding.com/en/latest/contributing.html) page.

#### Current Build Status
[![Build Status](https://travis-ci.org/SkylinesModding/Docs.svg)](https://travis-ci.org/SkylinesModding/Docs)

Check these [links](http://docs.skylinesmodding.com/en/latest/index.html#links) for more information to get around in the Cities:Skylines community. Also join us at by signing up at the [forum](http://www.skylinesmodding.com/)!
