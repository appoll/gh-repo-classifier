<h1>These Docs Are No Longer Updated</h1>

<p class="lead">These docs were originally created for DMS 1.  We are now at DMS 2 and these docs are no longer active.  To get the most up-to-date documentation, please click the links below.</p>

<ul>
	<li><a href="http://pagelines.com/quick-start">Quick Start Guide</a></li>
	<li><a href="http://pagelines.com/docs/DMS">Installation Docs</a></li>
	<li><a href="http://answers.pagelines.com">Answers (Customization) Portal</a></li>
	<li><a href="http://forum.pagelines.com">Technical Support Forum</a></li>
</ul>
