# Statamic 2 Documentation

This repo holds the content for the Statamic v2 docs site.
[http://docs.statamic.com](http://docs.statamic.com)

Any commits made to this repo's `master` branch will be reflected on the site.
