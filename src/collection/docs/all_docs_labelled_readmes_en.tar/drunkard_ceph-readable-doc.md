Used to hold docs of mine, both translated or wrote by me.

PDF 版本已死，不再维护了。已编译的 HTML 版本位于 output/ 目录下，与官方文
档同步。

文档源码位于 https://github.com/drunkard/ceph-Chinese-doc ，结构与官方文
档完全一样。

希望对您有用，有问题可以联系： gongfan193@gmail.com 或者 zhangshaowen@btte.net


English
-------

PDF version of documents are deprecated, and not maintained anymore.

Updated readable docs are located under output/, they are synced with
official Ceph documents.

Source code of these docs are published at:
https://github.com/drunkard/ceph-Chinese-doc , and it's organized the same
as official document structure.

Enjoy it :-)
