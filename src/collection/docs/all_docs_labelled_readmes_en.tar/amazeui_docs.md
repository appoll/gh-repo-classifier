Amaze UI Docs
====

Amaze UI 文档存档。最新版文档请通过[官网查看](http://amazeui.org)。

- [v1.x](http://amazeui.github.io/docs/1.x/)
- [v2.3](http://amazeui.github.io/docs/2.3/)
- [v2.5](http://amazeui.github.io/docs/2.5/)


### [Docs in English](http://amazeui.github.io/docs/en/)
