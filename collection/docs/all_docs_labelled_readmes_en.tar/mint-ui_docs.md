# docs
> documentation for mint-ui.

## Development
```shell
make dev
```

## Deploy
```shell
make deploy
```


## License
MIT
