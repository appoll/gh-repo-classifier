Universal Dependencies online documentation
===========================================

The Universal Dependencies manual is online [here](http://universaldependencies.org/).
