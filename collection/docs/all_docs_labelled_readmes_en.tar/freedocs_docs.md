# docs

* [使用nginx反向代理telegram网页客户端(单域名)](https://github.com/freedocs/docs/blob/master/%E4%BD%BF%E7%94%A8nginx%E5%8F%8D%E5%90%91%E4%BB%A3%E7%90%86telegram%E7%BD%91%E9%A1%B5%E5%AE%A2%E6%88%B7%E7%AB%AF(%E5%8D%95%E5%9F%9F%E5%90%8D).md)
* [安装nghttp2 https代理](https://github.com/freedocs/docs/blob/master/%E5%AE%89%E8%A3%85nghttp2%20https%E4%BB%A3%E7%90%86.md)
* [快速搭建nghttp2 https代理](https://github.com/freedocs/docs/blob/master/%E5%BF%AB%E9%80%9F%E6%90%AD%E5%BB%BAnghttp2%20https%E4%BB%A3%E7%90%86.md)
* [使用 sniproxy + dnsmasq + nginx 访问互联网](https://github.com/freedocs/docs/blob/master/%E4%BD%BF%E7%94%A8%20sniproxy%20%2B%20dnsmasq%20%2B%20nginx%20%E8%AE%BF%E9%97%AE%E4%BA%92%E8%81%94%E7%BD%91.md)
* [使用nginx及butterfly搭建网页终端](https://github.com/freedocs/docs/blob/master/%E4%BD%BF%E7%94%A8nginx%E5%8F%8Abutterfly%E6%90%AD%E5%BB%BA%E7%BD%91%E9%A1%B5%E7%BB%88%E7%AB%AF.md)
* [通过haproxy为http,ss监听同一端口](https://github.com/freedocs/docs/blob/master/%E9%80%9A%E8%BF%87haproxy%E4%B8%BAhttp%2Css%E7%9B%91%E5%90%AC%E5%90%8C%E4%B8%80%E7%AB%AF%E5%8F%A3.md)
* [为 openwrt 和 ddwrt (r6300v2， ac68u) 编译可执行文件](https://github.com/freedocs/docs/blob/master/%E4%B8%BA%20openwrt%20%E5%92%8C%20ddwrt%20(r6300v2%EF%BC%8C%20ac68u)%20%E7%BC%96%E8%AF%91%E5%8F%AF%E6%89%A7%E8%A1%8C%E6%96%87%E4%BB%B6.md)
* [搭建谷歌和维基百科反向代理](https://github.com/freedocs/docs/blob/master/%E6%90%AD%E5%BB%BA%E8%B0%B7%E6%AD%8C%E5%92%8C%E7%BB%B4%E5%9F%BA%E7%99%BE%E7%A7%91%E5%8F%8D%E5%90%91%E4%BB%A3%E7%90%86.md)
* [缩小kvm磁盘分区](https://github.com/freedocs/docs/blob/master/%E7%BC%A9%E5%B0%8Fkvm%E7%A3%81%E7%9B%98%E5%88%86%E5%8C%BA.md)
