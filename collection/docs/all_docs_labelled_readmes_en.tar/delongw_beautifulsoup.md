Beautiful Soup4
================

This is the Beautiful Soup4 document in Chinese.

这是Beautiful Soup 4 的中文文档.

官方网站: http://www.crummy.com/software/BeautifulSoup/

原版文档: http://www.crummy.com/software/BeautifulSoup/bs4/doc/

You didn't write that awful page. You're just trying to get some data out of it. Beautiful Soup is here to help. Since 2004, it's been saving programmers hours or days of work on quick-turnaround screen scraping projects. ---- official website

Beautiful Soup升级到4.x版本后中文文档没有继续更新,为了方便大家阅读,将文档翻译出中文版本,如有纰漏还望指正.