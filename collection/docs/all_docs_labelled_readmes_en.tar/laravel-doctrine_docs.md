# Laravel Doctrine Documentation

<img src="https://cloud.githubusercontent.com/assets/7728097/12727173/f9da39da-c91b-11e5-9f90-801bf9afd367.jpg">

## Contribution Guidelines

If you are submitting documentation for the **current stable release**, submit it to the corresponding branch. For example, documentation for Laravel Doctrine 1.0 would be submitted to the `1.0` branch. Documentation intended for the next release of Laravel Doctrine should be submitted to the `master` branch.
