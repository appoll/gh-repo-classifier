# [Selenium documentation rewrite](https://seleniumhq.github.io/docs/) [![Build status](https://travis-ci.org/SeleniumHQ/docs.svg)](https://travis-ci.org/SeleniumHQ/docs)

We’re rewriting the Selenium documentation from scratch!
You can see the current progress of [our draft](//seleniumhq.github.io/docs),
and help us out by sending a patch.

Once this documentation reaches
a state of relative stability and completeness,
it will replace [the existing Selenium documentation](http://docs.seleniumhq.org/docs/),
which is severely lagging
behind the real state that Selenium is in.

We accept patches and pull requests on GitHub.
When opening a pull request,
please indicate that you have signed the
[Contributor License Agreement](//spreadsheets.google.com/spreadsheet/viewform?hl=en_US&formkey=dFFjXzBzM1VwekFlOWFWMjFFRjJMRFE6MQ#gid=0)
which is necessary to contribute to the Selenium project.
