# Localized [AVA](https://ava.li) docs

- [Español](es_ES/readme.md) *(by [@AlbertoFuente](https://github.com/AlbertoFuente))*
- [Français](fr_FR/readme.md) *(by [@forresst](https://github.com/forresst))*
- [Italiano](it_IT/readme.md) *(by [@dej611](https://github.com/dej611))*
- [日本語](ja_JP/readme.md) *(by [@makotot](https://github.com/makotot))*
- [Português](pt_BR/readme.md) *(by [@charbelrami](https://github.com/charbelrami))*
- [Русский](ru_RU/readme.md) *(by [@sohje](https://github.com/sohje))*
- [简体中文](zh_CN/readme.md) *(by [@zhaozhiming](https://github.com/zhaozhiming))*
- [한국어](ko_KR/readme.md) *(by [@preco21](https://github.com/preco21))*


## Contribute

We're happy to accept localizations for the AVA docs if you can commit to keeping it up to date. You'll be added to this repo and free to do any changes to your localization.
