# Vinli Platform Documentation

This repository is the collection of documentation that describes how to interact with the Vinli Platform and devices.  The compiled documentation is hosted at http://docs.vin.li.

If you have any questions that aren't covered, head over to our discussion repo https://github.com/vinli/discuss.

## Contributing

If you would like to help make this documentation better by fixing a type or adding some additional description around a subject, please do.  Fork and submit a pull request and we'll pull it in as soon as we can.