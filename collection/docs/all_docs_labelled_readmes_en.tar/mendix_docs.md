# Mendix Documentation

This repository contains the Mendix documentation, which is served on [https://docs.mendix.com](https://docs.mendix.com).

Build status:
  * master [![Build Status](https://secure.travis-ci.org/mendix/docs.png?branch=master)](https://travis-ci.org/mendix/docs)
  * development [![Build Status](https://secure.travis-ci.org/mendix/docs.png?branch=development)](https://travis-ci.org/mendix/docs)

Want to contribute? Take a look at our [contribution guide](https://docs.mendix.com/community/Contribute+to+the+Mendix+Documentation).
