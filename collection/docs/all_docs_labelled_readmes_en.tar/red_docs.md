# Red Programming Language Documentation

*This is a work in progress, only a few pieces are available as reference documentation.*

For more information about Red language, please visit http://red-lang.org


[![Join the chat at https://gitter.im/red/docs](https://badges.gitter.im/red/docs.svg)](https://gitter.im/red/docs?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)