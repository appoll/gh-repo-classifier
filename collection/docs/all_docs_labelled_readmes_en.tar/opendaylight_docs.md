This project is providing manuals and documentation for OpenDaylight

For the documentation see:
http://docs.opendaylight.org/

For information on how to contribute to and/or build the documentation see:
http://docs.opendaylight.org/en/latest/documentation.html
