Urbit docs
==========

These are the urbit docs as they appear on [urbit.org](urbit.org/docs).  

If you'd like to serve the contents from your Urbit just copy `docs/` and `docs.md` into `web/` inside your urbit. 


Contributing
============

PRs are more than welcome: both corrections and suggestions.  

We're almost always available on `:talk`, but you can also email [`urbit@urbit.org`](mailto:urbit@urbit.org) or post to [`urbit-dev`](https://groups.google.com/forum/#!forum/urbit-dev) if you have questions.
