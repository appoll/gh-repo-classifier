==============================
Mozilla Services Documentation
==============================

This repository hosts the source documentation for the "docs" site at:

  https://docs.services.mozilla.com


To build it you will need to install python and virtualenv, then do the
following::

    $ make build

This should produce a "build/html" directory containing the generated HTML
documentation.
