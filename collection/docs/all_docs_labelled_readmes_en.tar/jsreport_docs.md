#jsreport docs

This repository contains documentation you can find on [http://jsreport.net/learn](http://jsreport.net/learn). The purpose to have it here is to make contributions easier. 

> Help and improve jsreport documentation by sending pull request to this repository