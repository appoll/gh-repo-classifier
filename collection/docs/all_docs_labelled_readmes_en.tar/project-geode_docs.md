# Project Geode End-User Documentation

The content in this repository is obsolete. The current documentation sources have been donated to the Apache Geode project and are available at https://git-wip-us.apache.org/repos/asf?p=incubator-geode.git;a=tree;f=geode-docs;h=3100e1db4d545263d7efd4fdfcf37b9dd4b0ef42;hb=HEAD.  For more information, please contact the development community at http://geode.apache.org/community/.


## Copyright

Copyright © 2015 Pivotal Software, Inc. All rights reserved.

Pivotal Software, Inc. believes the information in this publication
is accurate as of its publication date. The information is subject
to change without notice. THE INFORMATION IN THIS PUBLICATION IS 
PROVIDED "AS IS." PIVOTAL SOFTWARE, INC. ("Pivotal") MAKES NO 
REPRESENTATIONS OR WARRANTIES OF ANY KIND WITH RESPECT TO THE 
INFORMATION IN THIS PUBLICATION, AND SPECIFICALLY DISCLAIMS IMPLIED 
WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.

Use, copying, and distribution of any Pivotal software described in
this publication requires an applicable software license.

All trademarks used herein are the property of Pivotal or their 
respective owners.
