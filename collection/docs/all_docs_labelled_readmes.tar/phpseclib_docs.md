phpseclib documentation makes use of the following:

* http://960.gs/
* http://code.google.com/p/google-code-prettify/
* http://jquery.com/
* http://bassistance.de/jquery-plugins/jquery-plugin-treeview/
* http://jqueryui.com/