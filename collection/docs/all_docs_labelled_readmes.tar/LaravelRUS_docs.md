Laravel 5
====

Перевод документации Laravel - [http://laravel.su/docs](http://laravel.su/docs)

## Соглашения о формате

В начале каждого файла должна быть конструкция вида 

	git a49894e56c3ac8b837ba7d8687d94f6010cb1808

	---

где `a49894e56c3ac8b837ba7d8687d94f6010cb1808` - полный номер коммита в официальной англоязычной документации, последнего актуального на момент редактирования для данного файла. 

## Инструкция по переводу

[http://laravel.su/articles/rus-documentation-contribution-guide](http://laravel.su/articles/rus-documentation-contribution-guide)
