# jmpress.js docs

Documentation for jmpress.js

## BUILDING THE DOCS

1. Run `npm install` to install any development dependencies.
1. Run `npm start` to build the docs.

## CONTRIBUTING

Good news! We accept pull requests and are looking for more contributors! ;)
Take a look at the
[contribute section](http://jmpressjs.github.com/docs/contribute.html)
of the docs for more information on how you can contribute. Thanks!

## LICENSE

Copyright 2012 Kyle Robinson Young & Tobias Koppers. Released under a
[MIT license](http://www.opensource.org/licenses/mit-license.php).
