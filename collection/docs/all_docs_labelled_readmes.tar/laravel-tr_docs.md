# Laravel Dökümantasyonu

## Destek ve Düzenlemeler Hakkında

Eğer **şuanki stabil sürüm** hakkında bir düzenleme gönderecekseniz, bunu ait olduğu branşa gönderin. Örneğin, eğer Laravel 5.3 için bir düzenleme gönderiyorsanız, bunu `5.3` branşına gönderin. Laravel'in bir dahaki sürümü için yapılacak dökümantasyon düzenlemeleri `master` branşına gönderilmelidir.

## Sabit Tanımlamalar
{tip} => {tavsiye}
