# docs

Hi there! This repo serves as a central place for Node.js documentation
coordination, but not documentation itself. The documentation for node can be
found at <http://nodejs.org/en/docs/>. The source material is found in the
[node core repo][].

## Current Documentation WG Members

* [**@a0viedo**](https://github.com/a0viedo)
* [**@ashleygwilliams**](https://github.com/ashleygwilliams)
* [**@bengl**](https://github.com/bengl)
* [**@benjamingr**](https://github.com/benjamingr)
* [**@chrisdickinson**](https://github.com/chrisdickinson)
* [**@danielkhan**](https://github.com/danielkhan)
* [**@danjenkins**](https://github.com/danjenkins)
* [**@DavidTPate**](https://github.com/DavidTPate)
* [**@distracteddev**](https://github.com/distracteddev)
* [**@drewfish**](https://github.com/drewfish)
* [**@eljefedelrodeodeljefe**](https://github.com/eljefedelrodeodeljefe)
* [**@estliberitas**](https://github.com/estliberitas)
* [**@evanlucas**](https://github.com/evanlucas)
* [**@jasisk**](https://github.com/jasisk)
* [**@kahwee**](https://github.com/kahwee)
* [**@kelthenoble**](https://github.com/kelthenoble)
* [**@kosamari**](https://github.com/kosamari)
* [**@Qard**](https://github.com/Qard)
* [**@rdodev**](https://github.com/rdodev)
* [**@rodmachen**](https://github.com/rodmachen)
* [**@romankl**](https://github.com/romankl)
* [**@rubo-21**](https://github.com/rubo-21)
* [**@ryansobol**](https://github.com/ryansobol)
* [**@snostorm**](https://github.com/snostorm)
* [**@stevemao**](https://github.com/stevemao)
* [**@techjeffharris**](https://github.com/techjeffharris)
* [**@TheAlphaNerd**](https://github.com/TheAlphaNerd)
* [**@thefourtheye**](https://github.com/thefourtheye)
* [**@tomgco**](https://github.com/tomgco)

[node core repo]: https://github.com/nodejs/node
