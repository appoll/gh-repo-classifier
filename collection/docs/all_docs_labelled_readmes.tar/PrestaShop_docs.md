# docs

[![Gitter](https://badges.gitter.im/PrestaShop/docs.svg)](https://gitter.im/PrestaShop/docs?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)