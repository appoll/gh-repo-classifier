MODX Evolution Docs
=========

Документация по MODX Evolution

Разработка мануала сообща через pull-requests + issues.

Автоматический билд после вливания в мастер на сайт.
