# Les données des Décodeurs

Mise à disposition des données utilisées par [les Décodeurs](http://www.lemonde.fr/les-decodeurs/)

L'interface de recherche et d'exploration des données est ici : http://decodeurs.github.io/data/