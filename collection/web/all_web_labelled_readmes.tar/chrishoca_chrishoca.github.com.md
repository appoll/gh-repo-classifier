# chrishoca.github.com
http://chrishoca.github.io/

http://www.chrisstephensonyalnizdegildir.com

Merhaba, bizler Chris Hoca'nın öğrencileri ve akademide beraber çalışmış arkadaşları olarak kendisine destek olma umuduyla böyle bir proje başlattık.

İsteyenlerin destek amaçlı imza atabileceği, farklı mecralardaki haberlerin derlendiği, sosyal medya yansımalarının yer aldığı bir web sitesi yapıyoruz.

Elbette kodları açık, katkı vermek serbest. Bu yazılanları okumuş olmanız bile bizim için değerli. Teşekkürler...
