# Tower Website

## Instructions

To launch the sass compiler, use: (from this repo's directory)

```
sass --watch --scss sass/index.scss:public/css/index.css
```

- https://github.com/ccampbell/rainbow