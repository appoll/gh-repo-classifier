# BIRL *(Bambam's "It's show time" Recursive Language)*

Sai de casa codei pra caralho!®

BIRL é a primeira linguagem totalmente mutante do mundo! Ela é baseada em C e compilada por uma ferramenta mal-feita num servidor frango.

Tanto a linguagem quanto o site são código aberto! Queremos fazer o ambiente de programação mais treze possível! Segura a gente!

**AGORA COM TIPOS DE DADOS MONSTROS, PORRA!**

## Sintaxe
A sintaxe pode ser encontrada direto no site! Puta rolê escrever aqui também!  
Website: https://birl-language.github.io/  
Servidor: https://github.com/birl-language/birl-server  

##TO-DO
- [ ] Melhorar o tutorial para quem nunca programou
- [ ] Aumentar a sintaxe pra ficar o mais longe possível dessa linguagem de quem sobe em árvore (C).

  
##Colaboradores  
  
- **RCzera (@akafts)**
- **Padilha Monster (@lcfpadilha)**
- E toda a comunidade codebuilder do Brasil

*Inspirado pela linguagem ArnoldC: https://github.com/lhartikk/ArnoldC/wiki/ArnoldC*. **BIRL!**

*Versão atual:* 1.3
