个人前端博客
----------

## [点此访问 www.hacke2.cn](http://www.hacke2.cn)

本博客是基于[hpstr jekyll]("https://github.com/hacke2/hpstr-jekyll-theme)而搭建的个人博客，在原有强大的功能上，做了如下修改：

* 将google cdn换成 baidu cdn 原因你懂的
* 去掉分享到twitter、facebook等国外社区，加入百度分享
* 加入百度站长助手，方便您的统计
* disqus评论
* Read More功能，不想像以前一样文章全显示出来

如果您想快速搭建和我一样属于自己的博客系统，请参阅：

[30秒创建Github Page](http://www.hacke2.cn/create-github-page/)

目前待优化事项：

* 合并资源（JS,CSS）



