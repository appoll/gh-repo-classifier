## 博客更新指南

1. clone 仓库到本地
2. 在_posts目录下新建文章，如``2016-3-8-tmall-test.md``，可以参考其他文章。

```
---
layout: post
title: 标题
categories: [分类]
tags: [标签]
fullview: true
---

# 正文
```

## 反馈

1. 有问题联系maisui99@gmail.com
2. 内部专用
