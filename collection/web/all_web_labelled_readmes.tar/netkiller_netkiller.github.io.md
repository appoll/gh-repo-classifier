Netkiller 系列免费电子书
======

[![Join the chat at https://gitter.im/netkiller/netkiller.github.com](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/netkiller/netkiller.github.com?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)
《Netkiller 系列 手札》是一套免费系列电子书，netkiller 是nickname 从1999 开使用至今，“手札” 是札记，手册的含义。

2003年之前我还是以文章形式在BBS上发表各类技术文章，后来发现文章不够系统，便尝试写长篇技术文章加上章节目录等等。随着内容增加，不断修订，开始发布第一版，第二版......

IT知识变化非常快，而且具有时效性，这样发布非常混乱，经常有读者发现第一版例子已经过时，但他不知道我已经发布第二版。

我便有一种想法，始终维护一个文档，不断更新，使他保持较新的版本不过时。

第一部电子书是《PostgreSQL 实用实例参考》开始我使用 Microsoft Office Word 慢慢随着文档尺寸增加 Word 开始表现出力不从心。

我看到PostgreSQL 中文手册使用SGML编写文档，便开始学习Docbook SGML。使用Docbook写的第一部电子书是《Netkiller Postfix Integrated Solution》这是Netkiller 系列手札的原型。

至于“手札”一词的来历，是因为我爱好摄影，经常去一个台湾摄影网站，名字就叫“摄影家手札”。

Homepage
------
    <http://netkiller.github.com/>
    <http://netkiller.sourceforge.net/>

Author
------
    Neo Chan(陈景峰) <netkiller@msn.com>
    QQ：13721218, 官方QQ群：128659835
    Email: netkiller@msn.com

How to Mirror
------
    git clone https://github.com/netkiller/netkiller.github.com.git

Tip
------
    请不要pull request，因为这篇文档是Docbook生成的。如想参与贡献请联系我，我会你给docbook xml源码地址。




[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/netkiller/netkiller.github.com/trend.png)](https://bitdeli.com/free "Bitdeli Badge")