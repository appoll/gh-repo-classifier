# This is the data for my blog

It is automatically transformed by [Jekyll](http://github.com/mojombo/jekyll)
into a static site whenever I push this repository to GitHub.

# License

The following directories and their contents are Copyright Chris Cummins. You
may not reuse anything therein without my permission:

* _posts/
* images/

All other directories and files are
[MIT Licensed](http://opensource.org/licenses/MIT).
