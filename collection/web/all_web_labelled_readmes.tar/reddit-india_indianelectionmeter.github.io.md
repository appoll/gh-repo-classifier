## Indian Election Meter

Live at [indianelectionmeter.in](http://indianelectionmeter.in/).

Website dedicated to track promises made in Indian Elections, 
as suggested [here](https://www.reddit.com/r/india/comments/3sv4zi/we_need_a_website_for_tracking_the_promises_made/).

-------------

### Contributing

We need programmers, designers and content writers. See the [contributing guide](CONTRIBUTING.md) for details.

### FAQ

Q: What technologies are using?

A: Frontend - react. Backend - meteor.

Q: I saw indiantracker.in, why are we not using it? 

A: We can't because the person who made it using his own framework. He does not have the appropriate documentation for it and so it might be a problem at a later stage. 
