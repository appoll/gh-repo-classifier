## .NET Core main website
This site contains information about the .NET Core project, as well as guides, 
links to community and other things. 

Feel free to submit issues if you run into problems or you have suggestions on 
how to improve it!
