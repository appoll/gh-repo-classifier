# limetext.github.io

> Organization pages


## Install Locally

```bash
git clone git@github.com:limetext/limetext.github.io.git
cd limetext.github.io
bundle install
jekyll serve
```


## Contribute

Suggestions/improvements [welcome](//github.com/limetext/limetext.github.io/issues)!
