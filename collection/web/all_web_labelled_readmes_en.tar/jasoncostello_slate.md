Slate
=====
Slate is responsive theme for GitHub Pages. [Fork it](https://github.com/jsncostello/slate/fork_select) and use it on your own site or generate one automatically using [GitHub Pages](http://pages.github.com).

Slate in use:
![Slate](https://cloud.githubusercontent.com/assets/416727/17308540/72c4b6ce-57ef-11e6-9f68-12f6327edfde.png)

Slate is available under the MIT license.
