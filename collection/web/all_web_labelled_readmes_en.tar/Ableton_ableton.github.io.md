# ableton.github.io

## Installation

Make sure you have Ruby installed.

1. Install bundler: `gem install bundler`
2. Install the bundle: `bundle install`
3. Run Jekyll: `jekyll serve --watch`
4. View the site at `http://127.0.0.1:4000/`

Changes merged to master are automatically deployed via Github Pages.
