# Made With Angular

A showcase of web apps built with Angular

## Submit a site

1. Fork this repository
2. Add a 1280x711 thumbnail JPG image to projects/[yourprojectnamehere]/thumb.jpg
3. Add an entry to projects/projects.json with these properties:

    ```
    {
      "name": "My App",
      "thumb": "/projects/my-app/thumb.jpg",
      "desc": "One or two sentences describing the app",
      "url": "http://myapp.com",
      "submitter": "lpolepeddi",
      "submissionDate": "2015-06-24"
    }
    ```
4. Send a pull request