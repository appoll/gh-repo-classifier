#BDes (Hons) Interaction Design, Belfast School of Art.

##To Do List

+ Add content to Year 3 Placement modules
+ Copyright footer details
+ Why Belfast section needs content and slideshow
+ Setup info@ixdbelfast.org email address
+ Finish first blog post
+ Student showcase - work needed
+ Staff details on contact page


