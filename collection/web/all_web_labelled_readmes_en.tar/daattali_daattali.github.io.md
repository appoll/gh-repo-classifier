# daattali.github.io

> *Copyright 2016 [Dean Attali](http://deanattali.com). Licensed under the MIT license.*

Dean Attali's website [http://deanattali.com](http://deanattali.com)

The theme for this website has been open-sourced as [Beautiful Jekyll](http://deanattali.com/beautiful-jekyll/).

Please do not fork this repo, as it contains some configuration values that are very specific to my site. If you want to have a similar site then use my theme [Beautiful Jekyll](https://github.com/daattali/beautiful-jekyll).
