thephpleague.com
----------------

This is the source for [thephpleague.com]. It is automatically compiled by
[Jekyll] every time a pull request is merged.

 [thephpleague.com]: http://thephpleague.com
 [Jekyll]: https://github.com/jekyll/jekyll


Contributing
============

 1. If you notice something missing, please [open an issue on GitHub][issue].

 2. If you'd like to fix it yourself, simply [edit the file on GitHub][edit] and
    open a pull request. The site will be recompiled as soon as your pull
    request is merged.

 3. If you'd like to test things out locally, you'll need to install Jekyll and
    a markdown engine:

    ```bash
    gem install bundler
    bundle install
    ```

    Then compile!

    ```bash
    bundle exec jekyll serve
    ```

    ... and open `http://localhost:4000` in your browser to check it out!

 [issue]: https://github.com/thephpleague/thephpleague.github.io/issues
 [edit]:  https://github.com/blog/905-edit-like-an-ace
