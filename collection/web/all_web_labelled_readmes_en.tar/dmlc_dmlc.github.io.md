How to use:

First put the markdown format post in `_posts/` in format
  `year-month-day-title.markdown`, and then commit

Preview in local:

```
$ gem install jekyll
$ jekyll s
```

then open http://localhost:4000/
