# Dirty COW

Hello

To add a new FAQ entry please send a PR for index.html.

If you wish to learn more, or share what you currently know of the vulnerability head on to the wiki (open to everyone): https://github.com/dirtycow/dirtycow.github.io/wiki

If you already know all you need to know, participate in the [challenges](https://github.com/dirtycow/dirtycow.github.io/projects) and win fame, glory and a t-shirt.

All code, images and documentation in this page and the website is in the public domain ([CC0](https://creativecommons.org/publicdomain/zero/1.0/)).
