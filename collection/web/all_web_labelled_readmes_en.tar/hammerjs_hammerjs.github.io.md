hammerjs.github.io
==================

To release a new version of Hammer.js just run `make release`.
