# Font Awesome

Currently, the `bower_components/font-awesome/fonts` is copied over to `/`.


bundle exec jekyll serve -I
