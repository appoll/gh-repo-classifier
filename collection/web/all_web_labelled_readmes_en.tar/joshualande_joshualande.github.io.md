This is the personal website of Joshua Lande, hosted by [GitHub Pages](http://pages.github.com). You can find it at [joshualande.com](http://joshualande.com).
