todogroup.github.io
===================

This is the site for todogroup.org ... you probably want index.md

## Building the site

This site is managed using Jekyll and GitHub Pages, making it dead simple to update and deploy. You'll need Ruby and Bundler installed to get going. You should always use a pull request workflow to update the site. Any changes made to master (including merging a pull request) will automatically rebuild and publish the site.

1. Clone the repository locally
2. Run `bundle` to install dependencies
3. Run `bundle exec jekyll serve` to build and run a local http server
