data-analysis
=============

A data analysis site by flask and mongoengine
<img src="https://dl.dropboxusercontent.com/u/95512723/images/6.png" border="0" />
<img src="https://dl.dropboxusercontent.com/u/95512723/images/7.png" border="0" />
<img src="https://dl.dropboxusercontent.com/u/95512723/images/8.png" border="0" />
<img src="https://dl.dropboxusercontent.com/u/95512723/images/9.png" border="0" />
<img src="https://dl.dropboxusercontent.com/u/95512723/images/10.png" border="0" />
<img src="https://dl.dropboxusercontent.com/u/95512723/images/11.png" border="0" />
<img src="https://dl.dropboxusercontent.com/u/95512723/images/12.png" border="0" />


####USEAGE

```
$pip install -r requirements.txt
$cd /path/to/data-analysis
$npm install
$mongorestore -d fetch_data --directoryperdb dump/fetch_data
$python run.py
```
