![](https://img.shields.io/badge/build-passing-brightgreen.svg) [![Join the chat at https://gitter.im/illacceptanything/illacceptanything](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/illacceptanything/illacceptanything?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge) [![CircleCI branch](https://img.shields.io/circleci/project/BrightFlair/PHP.Gt/master.svg)](https://www.youtube.com/embed/jI-kpVh6e1U?autoplay=1) [![Scrutinizer](https://img.shields.io/scrutinizer/g/filp/whoops.svg)](https://www.youtube.com/embed/jI-kpVh6e1U?autoplay=1) [![SensioLabs Insight](https://img.shields.io/sensiolabs/i/45afb680-d4e6-4e66-93ea-bcfa79eb8a87.svg)](https://www.youtube.com/embed/jI-kpVh6e1U?autoplay=1) [![Github Releases](https://img.shields.io/github/downloads/atom/atom/latest/total.svg)](https://www.youtube.com/embed/jI-kpVh6e1U?autoplay=1) [![CDNJS](https://img.shields.io/cdnjs/v/jquery.svg)](https://www.youtube.com/embed/jI-kpVh6e1U?autoplay=1) [![npm (scoped)](https://img.shields.io/npm/v/@cycle/core.svg)](https://www.youtube.com/embed/jI-kpVh6e1U?autoplay=1) [![Gem](https://img.shields.io/gem/v/formatador.svg)](https://www.youtube.com/embed/jI-kpVh6e1U?autoplay=1) [![GitHub release](https://img.shields.io/github/release/qubyte/rubidium.svg)](https://www.youtube.com/embed/jI-kpVh6e1U?autoplay=1) [![homebrew](https://img.shields.io/homebrew/v/cake.svg)](https://www.youtube.com/embed/jI-kpVh6e1U?autoplay=1) [![build](https://img.shields.io/badge/surveillance-NSA-brightgreen.svg)](https://www.youtube.com/embed/jI-kpVh6e1U?autoplay=1)  [![WordPress rating](https://img.shields.io/wordpress/plugin/r/akismet.svg)](https://www.youtube.com/embed/jI-kpVh6e1U?autoplay=1) [![Docker Automated buil](https://img.shields.io/docker/automated/jrottenberg/ffmpeg.svg)](https://www.youtube.com/embed/jI-kpVh6e1U?autoplay=1) [![AUR](https://img.shields.io/aur/votes/yaourt.svg)](https://www.youtube.com/embed/jI-kpVh6e1U?autoplay=1) [![Puppet Forge](https://img.shields.io/puppetforge/mc/camptocamp.svg)](https://www.youtube.com/embed/jI-kpVh6e1U?autoplay=1) [![Libscore](https://img.shields.io/libscore/s/jQuery.svg)](https://www.youtube.com/embed/jI-kpVh6e1U?autoplay=1) [![PyPI](https://img.shields.io/pypi/status/Django.svg)](https://www.youtube.com/embed/jI-kpVh6e1U?autoplay=1) [![PyPI](https://img.shields.io/pypi/pyversions/Django.svg)](https://www.youtube.com/embed/jI-kpVh6e1U?autoplay=1) [![Beerpay](https://img.shields.io/beerpay/hashdog/scrapfy-chrome-extension.svg)](https://www.youtube.com/embed/jI-kpVh6e1U?autoplay=1) [![PyPI](https://img.shields.io/pypi/implementation/Django.svg)](https://www.youtube.com/embed/jI-kpVh6e1U?autoplay=1) [![CocoaPods](https://img.shields.io/cocoapods/p/AFNetworking.svg)](https://www.youtube.com/embed/jI-kpVh6e1U?autoplay=1) [![Puppet Forge](https://img.shields.io/puppetforge/mc/camptocamp.svg)](https://www.youtube.com/embed/jI-kpVh6e1U?autoplay=1) [![Codacy grade](https://img.shields.io/codacy/grade/e27821fb6289410b8f58338c7e0bc686.svg)](https://www.youtube.com/embed/jI-kpVh6e1U?autoplay=1) [![Hex.pm](https://img.shields.io/hexpm/v/plug.svg)](https://www.youtube.com/embed/jI-kpVh6e1U?autoplay=1) [![build](https://img.shields.io/badge/passing-build-green.svg)](https://www.youtube.com/embed/jI-kpVh6e1U?autoplay=1) [![David](https://img.shields.io/david/dev/strongloop/express.svg)](https://www.youtube.com/embed/jI-kpVh6e1U?autoplay=1) [![Chrome Web Store](https://img.shields.io/chrome-web-store/price/nimelepbpejjlbmoobocpfnjhihnpked.svg)](https://www.youtube.com/embed/jI-kpVh6e1U?autoplay=1) [![Maintenance](https://img.shields.io/maintenance/yes/2016.svg)](https://www.youtube.com/embed/jI-kpVh6e1U?autoplay=1) [![CocoaPods](https://img.shields.io/cocoapods/aw/AFNetworking.svg)](https://www.youtube.com/embed/jI-kpVh6e1U?autoplay=1) [![bitHound](https://img.shields.io/bithound/code/github/rexxars/sse-channel.svg)](https://www.youtube.com/embed/jI-kpVh6e1U?autoplay=1) [![Issue Stats](https://img.shields.io/issuestats/p/github/strongloop/express.svg)](https://www.youtube.com/embed/jI-kpVh6e1U?autoplay=1) [![Ansible Role](https://img.shields.io/ansible/role/3078.svg)](https://www.youtube.com/embed/jI-kpVh6e1U?autoplay=1) [![CPAN](https://img.shields.io/cpan/v/Config-Augeas.svg)](https://www.youtube.com/embed/jI-kpVh6e1U?autoplay=1)

## WARNING - [Large repository](https://i.imgur.com/rzSgLP3.png); [may trigger antivirus software](https://github.com/illacceptanything/illacceptanything/blob/75109b706351420c31999915d4d54b0b4ab12df7/data/text/EICAR.COM.TXT)!

    ██╗    ██╗    ██╗██╗██╗     ██╗
    ██║    ██║    ██║██║██║     ██║
    ██║    ██║ █╗ ██║██║██║     ██║
    ██║    ██║███╗██║██║██║     ██║
    ██║    ╚███╔███╔╝██║███████╗███████╗
    
    ╚█████╗ ╚██████╗ ██████╗███████╗██████╗ ████████╗
    ██╔══██╗██╔════╝██╔════╝██╔════╝██╔══██╗╚══██╔══╝
    ███████║██║     ██║     █████╗  ██████╔╝   ██║
    ██╔══██║██║     ██║     ██╔══╝  ██╔═══╝    ██║
    ██║  ██║╚██████╗╚██████╗███████╗██║        ██║
    
    ╚█████╗╝███╗═══██╗██╗══╝██╗████████╗██╗  ██╗██╗███╗   ██╗ ██████╗
    ██╔══██╗████╗  ██║╚██╗ ██╔╝╚══██╔══╝██║  ██║██║████╗  ██║██╔════╝
    ███████║██╔██╗ ██║ ╚████╔╝    ██║   ███████║██║██╔██╗ ██║██║  ███╗
    ██╔══██║██║╚██╗██║  ╚██╔╝     ██║   ██╔══██║██║██║╚██╗██║██║   ██║
    ██║  ██║██║ ╚████║   ██║      ██║   ██║  ██║██║██║ ╚████║╚██████╔╝
    ╚═╝  ╚═╝╚═╝  ╚═══╝   ╚═╝      ╚═╝   ╚═╝  ╚═╝╚═╝╚═╝  ╚═══╝ ╚═════╝

# illacceptanything

> The project where [literally](https://xkcd.com/725/)* anything goes

I want to make a really cool project, but I don't know what to make. So I'll just accept
every Pull Request submitted and see what happens.

## Rules

 * No porn.
 * Nothing illegal.
 * Can't violate GitHub terms of service.
 * Don't mess with the LICENSE file - we kind of need that intact!
 * Don't be a [dick](https://github.com/illacceptanything/illacceptanything/blob/master/dickbutt.dickbutt), or any other copulatory organ. This includes:
    - [Trying](https://github.com/illacceptanything/illacceptanything/pull/463) [to](https://github.com/illacceptanything/illacceptanything/pull/498) [delete](https://github.com/illacceptanything/illacceptanything/pull/545) [everything](https://github.com/illacceptanything/illacceptanything/pull/308) [in](https://github.com/illacceptanything/illacceptanything/pull/259) [the](https://github.com/illacceptanything/illacceptanything/pull/131) [repository](https://github.com/illacceptanything/illacceptanything/pull/396).
    - [Uploading](https://github.com/illacceptanything/illacceptanything/pull/128) [malicious](https://github.com/illacceptanything/illacceptanything/pull/330) [code](https://github.com/illacceptanything/illacceptanything/pull/766)
    - [Uploading](https://github.com/illacceptanything/illacceptanything/pull/423) [fork](https://github.com/illacceptanything/illacceptanything/pull/404) [bombs](https://github.com/illacceptanything/illacceptanything/pull/492)
    - s/anything/nothing/: [#292](https://github.com/illacceptanything/illacceptanything/pull/292) [#340](https://github.com/illacceptanything/illacceptanything/pull/340)
    - Removing items from this list
 * Also, please refrain from uploading extremely large files or filenames with reserved characters, since those can make cloning the repository impossible for other contributors.
 * Please try to sort files into `data/`, `code/`, etc. where applicable. A neater repository is more maintainable!

## Contributing

1. Fork it (https://github.com/illacceptanything/illacceptanything/fork)
2. Create your feature branch (`git clone https://github.com/illacceptanything/illacceptanything`)
3. Commit your changes (`rm -rf illacceptanything'`)
4. Push to the branch (`git clone https://github.com/illacceptanything/illacceptanything`)
5. Create a new Pull Request (`rm -rf illacceptanything`)

## Contributors

![](http://ak-hdl.buzzfed.com/static/2014-05/enhanced/webdr03/20/11/anigif_enhanced-buzz-26110-1400598155-7.gif)

## Scumbag Steve
If your name is steve, list yourself here.

---

 🇨🇱 ![Chile Parrot](http://countryparrots.com/parrots/chile-parrot.gif) 🇨🇱

## [CLICK ME!](https://andrewsun.com/etc/special/m.html)
![](https://i.imgur.com/ehUtz.gif)

Leader of the FREE world (aka lord RMS)
![](http://cdn.makeagif.com/media/4-08-2015/tAagTa.gif)
<br>
![](http://i.imgur.com/F2zh7G4.gif)

```
   _____                  __  .__    .__                 ._.
  /  _  \   ____ ___.__._/  |_|  |__ |__| ____    ____   | |
 /  /_\  \ /    <   |  |\   __\  |  \|  |/    \  / ___\  | |
/    |    \   |  \___  | |  | |   Y  \  |   |  \/ /_/  >  \|
\____|__  /___|  / ____| |__| |___|  /__|___|  /\___  /   __
        \/     \/\/                \/        \//_____/    \/
```

[Darude](http://www.reddit.com/r/Music/comments/31v7n0/i_am_darude_ama/) is totally allowed tho. Darude is the real mvp.
![darude-sandstorm](https://github.com/illacceptanything/illacceptanything/blob/master/web/images/darude-sandstorm.gif.mp4.mov.wmv.png.jpeg)

![](https://38.media.tumblr.com/tumblr_mchf7fdrhd1r7swjzo1_250.gif)

```
 __                 
/  \        _______________ 
|  |       /               \
@  @       | It looks      |
|| ||      | like you      |
|| ||   <--| are accepting |
|\_/|      | anything.     |
\___/      \_______________/
```

媽我在這～～～ 
Repo so big, takes forever to download

I'm in love with this repo. - Dhruv KB ;)

Really good for someone who want to increase contribution count. :D

![](http://i.imgur.com/3HFuDe4.gif)

```
/ they said i could PR anything so I PRd \
\ a penguin                              /
 ----------------------------------------
   \
    \
        .--.
       |o_o |
       |:_/ |
      //   \ \
     (|     | )
    /'\_   _/`\
    \___)=(___/

```
## Der Ulf war hier

## Holy Religion of the Internet (besides porn)
![](http://placekitten.com.s3.amazonaws.com/homepage-samples/408/287.jpg)

## Best meme on the interwebz ⬇
![](http://weknowmemes.com/wp-content/uploads/2012/01/if-you-touch-my-virginity-ill-stab-you.jpg)
<br>
![](http://www.ceolato.com/html/_images/python_powered.png) ![](http://media.giphy.com/media/2gFM7CtCNfzP2/giphy.gif)
<br>
![](https://media.giphy.com/media/wPrqe5846Z9GU/giphy.gif)
![](http://i.imgur.com/7Gr5Bar.gif)

<br>
![](https://31.media.tumblr.com/tumblr_m403dltfk91qmb7u4o2_500.gif)
<br>
![](https://38.media.tumblr.com/075ba126e507d5643cb2dee8ab18c6a7/tumblr_inline_mykjwj3Ej61rc3of7.gif)
<br>
![](http://img2.wikia.nocookie.net/__cb20121028051340/tfsrox/images/c/c4/Tumblr_m403dltfk91qmb7u4o1_250.gif)
<br>
![](https://media.giphy.com/media/12ri8ebjE91pQY/giphy.gif)
<br>
![](https://31.media.tumblr.com/tumblr_m5ldirNQ3b1qjenx9.gif)
<br>
![](http://i.imgur.com/hEOaIS5.png)
<br>
![](media/lemur.jpg)
<br>
![](http://www.hollywoodhomestead.com/wp-content/uploads/2013/08/misc-all-the-things-l-1-1024x768.jpg)
<br>
![](https://media.makeameme.org/created/such-hacking-many.jpg)
<br>
![](http://images.8tracks.com/cover/i/009/503/018/photo-2314.jpg?rect=0,0,900,900&q=98&fm=jpg&fit=max)
<br>
![](http://i0.kym-cdn.com/photos/images/original/000/976/339/ded.png)
