data
====

A place to aggregate and link to open source energy data
