# Test With Spring Course

If you are struggling to write good automated tests for Spring web applications, you are not alone! [I have launched a video course](https://www.testwithspring.com/?utm_source=github&utm_medium=social&utm_content=spring-data-jpa&utm_campaign=test-with-spring-course-presales) that describes how you can write automated tests which embrace change and help you to save your time (and nerves).

# Spring Data JPA Tutorial

This repository contains the example applications of my [Spring Data JPA tutorial](http://www.petrikainulainen.net/spring-data-jpa-tutorial/). The READMEs of the examples provide more information about the application in question.
