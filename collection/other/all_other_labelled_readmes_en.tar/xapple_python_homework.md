# python_homework
A repository to contain exercices and homework for the Python EBC 2016 course
