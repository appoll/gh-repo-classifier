# Courseplay for Farming Simulator 2013

### We've moved
We've moved to a **[new repository][CP Github]**. Please visit go there for any updates. We will not answer anymore to any issues posted here.

Our **[homepage][CP Website Link]** is still where it used to be .

----
### Wir sind umgezogen
Wir sind auf ein **[neues Repository][CP Github]** umgezogen. Wir werden hier keine Supportanfragen mehr beantworten.

Unsere **[Homepage][CP Website Link]** ist immer doch da wo sie sein sollte.

[CP Github]: https://github.com/Courseplay/courseplay
[CP Website Link]: http://courseplay.github.com/courseplay/
