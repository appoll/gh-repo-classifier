# what's this
this repo is move to https://github.com/beego/beedoc