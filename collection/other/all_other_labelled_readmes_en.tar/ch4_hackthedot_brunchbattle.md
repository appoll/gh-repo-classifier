### Hack the dot - Bruchbattle


 - Description : The idea behind BrunchBattle.Live is the epic battle of breakfast vs lunch called "The Great Brunch War" and the different variations of food that they each bring. The program will randomize different items from both meals and give the users a combination of choices from both categories. This will be done when the user hits the battle button on the page and the page will calculate the outcome of the battle, thus creating a delicious mashup plate for them to eat. 

 
 ### Team members
 - Jonathan Kim
 - Arian Flores.
 - Edward
 - Christian
 - Harvey
 - Halah

#### Food items
#####Breakfast:

- Eggs: Sunnyside | scrambled
- Omelletes: Bacon | Chicken | Steak | Vegetarian
- Cereal
- Milk
- Orange Juice
- Coffee
- Danish
- Bagels
- Bacon
- Tea
- Biscuit
- Breakfast burrito
- Pancakes
- Waffles
- Hashbrown
- Sausage
- Corned Beef Hash
- Mimosas
- Bloody Mary


##### Lunch: 
- Burger: Buffalo | Cheese | BLT | Bacon | Chicken | Hamburger
- Grilled Cheese Sandwich
- Chicken Tenders
- Chicken Wings: Buffalo | Lemon Pepper | Original
- Philly Steak
- Tacos
- Burrito
- Pizza: Cheese | Pepperoni | Supreme | Vegetarian
- Lasagna
- Spaghetti


