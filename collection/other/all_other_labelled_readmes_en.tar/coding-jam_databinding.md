# Android Two Way Data Binding example

More info on [Two way data binding medium post](https://medium.com/@fabioCollini/android-data-binding-f9f9d3afc761)
