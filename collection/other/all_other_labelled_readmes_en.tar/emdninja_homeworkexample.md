homeworkexample
===============
