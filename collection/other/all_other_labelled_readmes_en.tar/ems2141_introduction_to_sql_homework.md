introduction_to_sql_homework
============================

This repository is here so students can fork it and add their sql scripts. The repo is intentionally empty.
