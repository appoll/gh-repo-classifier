# Linux on IBM z Systems HOW-TOs

This GitHub project hosts a collection of instructions and tutorials to help you get your favorite software up and running on Linux on IBM z Systems (yes, _mainframes_). Click the [Wiki](https://github.com/linux-on-ibm-z/docs/wiki) link to see the full list of articles.

To learn more about running Linux on IBM z Systems, join our [developerWorks community](https://www.ibm.com/developerworks/community/groups/community/lozopensource).
