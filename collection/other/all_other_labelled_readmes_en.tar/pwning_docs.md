This is some documentation put together to help folks out when they first
start out with a CTF. 

*Please* submit your pull requests/comments/whatever. This is open to anyone
from the CTF community to work on.
