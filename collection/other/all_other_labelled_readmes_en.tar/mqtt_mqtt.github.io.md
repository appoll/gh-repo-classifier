mqtt.github.io
=================

This will be the new home of the MQTT community website, [mqtt.org](http://mqtt.org)

The previous version was hosted on Wordpress, with Dokuwiki bolted on the side - this made it difficult to maintain or to collaborate with the community. It is hoped that by moving to Github we can promote greater collaboration in the future.

The wiki is already partially moved here (see https://github.com/mqtt/mqtt.github.io/wiki and **please contribute**). A Github Pages version of the main site will be here eventually!

Content on the wiki is subject to the [CC-BY-4.0 International license](https://creativecommons.org/licenses/by/4.0/) (see LICENSE)
