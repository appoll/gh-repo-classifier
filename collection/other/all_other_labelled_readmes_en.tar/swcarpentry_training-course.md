This is an archive of old blog posts for the Software Carpentry instructor training course.
It is no longer being updated.
