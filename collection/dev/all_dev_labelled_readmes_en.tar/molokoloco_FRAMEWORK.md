Framework and sample code by molokoloco 2011

Scroll Wall (jQuery Mobile & Masonry)

  * Demo : http://www.b2bweb.fr/wall/
  * Infos : http://www.b2bweb.fr/molokoloco/scroll-wall-jquery-mobile-masonry/
  * Main Script : https://github.com/molokoloco/FRAMEWORK/blob/master/wall/js/jquery.wall.js
  * GIT Sources : https://github.com/molokoloco/FRAMEWORK/tree/master/wall

jQuery Presentation SlidR V1.2

  * Demo : http://www.b2bweb.fr/bonus/jx/
  * Infos : http://www.b2bweb.fr/molokoloco/html5-3d-effect-caroussel-presentation/
  * Main Script : https://github.com/molokoloco/FRAMEWORK/blob/master/jx/js/index.js
  * GIT Sources : https://github.com/molokoloco/FRAMEWORK/blob/master/jx/


 Workable / Testable jQuery Default Plugin Boilerplate
  * Doc : http://docs.jquery.com/Plugins/Authoring
  * Live edit : http://jsfiddle.net/molokoloco/DzYdE/
  * GIT Sources : https://github.com/molokoloco/FRAMEWORK/blob/master/jquery.plugins/jquery.tooltips.js
  * Comments or suggests : http://www.b2bweb.fr/molokoloco/jquery-default-plugin/
