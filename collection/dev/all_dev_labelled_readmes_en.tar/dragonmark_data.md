# dragonmark.data

A Clojure library designed to help with PostgreSQL and Redis

## Usage

[![Clojars Project](http://clojars.org/dragonmark/data/latest-version.svg)](http://clojars.org/dragonmark/data)

## License

Copyright © 2015 David Pollak

Distributed under the Eclipse Public License either version 1.0 or (at
your option) any later version.
