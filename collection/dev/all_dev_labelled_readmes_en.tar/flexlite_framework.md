framework
=========

This is an open source UI framework for flash games,
under the MIT License.


使用之前请务必先查看Wiki，检出说明及编译条件：
http://wiki.flexlite.org/index.php?doc-view-61

教程索引：
http://wiki.flexlite.org/index.php?doc-view-52
