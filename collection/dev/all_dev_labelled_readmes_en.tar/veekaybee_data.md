Big Data and Small Data n'Stuff
====

This repo includes a bunch of (mostly Python and Pig) scripts I use to maul data into shape. Enjoy!
