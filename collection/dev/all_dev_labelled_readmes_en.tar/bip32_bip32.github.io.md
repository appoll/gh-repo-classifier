JavaScript Client-Side BIP0032 generator

http://github.com/sarchar/brainwallet.github.com/tree/bip32

- Web Worker hashes 50,000 rounds to protect passphrases
