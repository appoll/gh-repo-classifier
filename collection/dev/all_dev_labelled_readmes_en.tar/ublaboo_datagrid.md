[![Build Status](https://travis-ci.org/ublaboo/datagrid.svg?branch=master)](https://travis-ci.org/ublaboo/datagrid)
[![Latest Stable Version](https://poser.pugx.org/ublaboo/datagrid/v/stable)](https://packagist.org/packages/ublaboo/datagrid)
[![License](https://poser.pugx.org/ublaboo/datagrid/license)](https://packagist.org/packages/ublaboo/datagrid)
[![Total Downloads](https://poser.pugx.org/ublaboo/datagrid/downloads)](https://packagist.org/packages/ublaboo/datagrid)
[![Gitter](https://img.shields.io/gitter/room/nwjs/nw.js.svg)](https://gitter.im/ublaboo/help)

# DataGrid
DataGrid for Nette Framework: filtering, sorting, pagination, tree view, table view, translator, etc

Please see the documentation [here](http://ublaboo.org/datagrid/)
