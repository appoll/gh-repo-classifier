CarbonWallet.com
================

JavaScript Based Online Bitcoin Wallet

http://CarbonWallet.com

Features:

- Deterministic wallet addresses.
- Anonymous.
- Runs in the browser
- Keys created in memory.

### Chrome packaged app

Here's how you can run Carbon Wallet as a Chrome packaged app
without having to go through the Chrome Web store:

- Clone the code
- Go to "Menu > Tools > Extensions" in Chrome
- Make sure "Developer mode" is checked at the top
- Click "Load unpacked extension"
- Navigate to the carbonwallet.github.io directory and click OK
- Carbon Wallet will now appear as an option in your App list in Chrome



### Executables

Build carbonwallet on windows, mac and linux

- npm install grunt-node-webkit-builder --save-dev
- npm install grunt-contrib-compress --save-dev
- npm install -g grunt-cli
- grunt

### Licence

http://opensource.org/licenses/CDDL-1.0
