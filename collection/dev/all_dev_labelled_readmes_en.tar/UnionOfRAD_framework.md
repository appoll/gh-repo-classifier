# li₃ standard distribution

The li₃ standard distribution is an application system that includes the
overarching directory layout, an example starting application, and a copy of the
[li₃ framework](https://github.com/UnionOfRAD/lithium).

## Installation

To install the distribution follow the steps outlined in
[Installation](http://li3.me/docs/manual/installation). For a quickstart read
[The Quintessential Blog Tutorial](http://li3.me/docs/manual/quickstart) to
create your first project.
