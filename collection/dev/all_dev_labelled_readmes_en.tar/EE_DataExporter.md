EEDataExporter
-------------
[![Build Status](https://api.travis-ci.org/EE/DataExporter.png?branch=master)](http://travis-ci.org/EE/DataExporter)

Easy export data to CSV, XML, JSON, Excel, HTML file or into memory.

[Read the Documentation and see examples](https://github.com/EE/DataExporter/blob/master/Resources/doc/index.md)


License
-------
License can be found [here](https://github.com/EE/DataExporter/blob/master/Resources/meta/LICENSE).