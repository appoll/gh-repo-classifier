Nextras Datagrid
================

Easy to use datagrid with powerfull API.

### Installation

Use composer:

```bash
$ composer require nextras/datagrid
```

### Docs & sources

- [Documentation](http://nextras.org/datagrid/docs)
- [Demo](http://nextras.org/datagrid)
