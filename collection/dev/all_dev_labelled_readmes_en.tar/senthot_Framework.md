## Senthot Framework
Senthot is a free PHP Framework, opensource, as a framework development PHP oriented simple object, easy and fast for developing Web application and also simplify the developing entreprise application.

### Principle Architecture and Design
Architecture Senthot Framework developed following the principle simple design and practical, resulting core system smaller, but has an ability agile, and with the simplify expected to easily on monitor the security, both in all injection or SSX, because security must be keep still persued.

### Official Documentation
Documentation for the entire framework can be found on the [Senthot website](http://www.senthot.com/doc/).

### License
The Senthot framework is open-sourced software licensed under the [Apache License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0)
