# RazorFlow Framework

## Setup

```
git clone git://github.com/razorflow/framework.git
cd framework
npm install
grunt build
```

## Start Example Server

```
cd framework/examples/
php -S 0.0.0.0:8080 index.php
```

and visit http://localhost:8080/ for latest examples and http://localhost:8080/dev/ to load latest development code.

