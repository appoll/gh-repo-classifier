DataMining
==========
[![Build Status](https://travis-ci.org/jimenbian/DataMining.svg?branch=master)](https://travis-ci.org/jimenbian/DataMining)
#My data mining code！Written by python.

More algorithms are being committing, thank you for your attention.  
The dataset used in the algorithms are in the file named "DataSet".


#Contact Me

Email:garvinli@garvinli.com  
Personal website:www.garvinli.com  
Blog:http://blog.csdn.net/buptgshengod

