item4.github.io
===============

item4's tech blog


Run Dev Server
--------------

this blog use [Lektor](https://www.getlektor.com).
See its guideline to install.

```console
$ lektor server -f webpack
```

Contributing
------------

Use issue and Pull Request.

**Do not make pr to master branch.**
