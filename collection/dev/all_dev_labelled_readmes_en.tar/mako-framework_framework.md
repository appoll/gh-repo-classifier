# Mako Framework

[![Build Status](http://img.shields.io/travis/mako-framework/framework/master.svg?style=flat)](https://travis-ci.org/mako-framework/framework)

This is the Mako Framework core. You'll find the documentation at [makoframework.com](http://makoframework.com/).