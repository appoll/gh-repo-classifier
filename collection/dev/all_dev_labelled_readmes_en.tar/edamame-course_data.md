edamame-data
============

Data used in the EDAMAME course
