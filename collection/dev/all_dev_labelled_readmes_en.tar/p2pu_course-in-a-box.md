# Everything you need to create an online course in a box


## How do I get started?

Head on over to [howto.p2pu.org](http://howto.p2pu.org). Everything you need to know is over there and once you are done we'll be waiting for you here!
 
---

This course was created using the [Jekyll Course template from P2PU](http://github.com/p2pu/jekyll-course-template).
