# dataplay2
Please refer to my blog(Chinese) for a simple introduction http://my.oschina.net/taogang/blog/630632

Add docker build @ https://github.com/gangtao/dataplay2/tree/master/docker in case you have trouble to run it
install docker
cd dataplay2/docker
docker build -t dataplay:test .
