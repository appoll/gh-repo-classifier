Example of Spring Data JPA application (Hibernate used as implementation of JPA).

You can read tutorial for this app by following link: http://fruzenshtein.com/spring-mvc-hibernate-maven-crud/
