dataflow [![Build Status](https://travis-ci.org/meemoo/dataflow.png?branch=master)](https://travis-ci.org/meemoo/dataflow)
========

a common HTML5 graph editor for various data flow projects

current state: http://meemoo.org/dataflow/

in practice: https://github.com/forresto/dataflow-webaudio (synthy noises in webkit)

planning and discussion: https://github.com/meemoo/dataflow/issues
