Conzole
=======

by Pierluigi Pesenti

Conzole is a debug panel built in javascript that wraps javascript native console object methods and functionality in a panel displayed inside the page.
Include it once and see it the same every time you open up the page, in every browser, on mobile etc.

It also adds some unique functions as the &ldquo;watching&rdquo; list. It let you watch variables as many browsers debug console does. But setting up the watches via javascript is much easier, can be conditional and you don't have to do it every time you launch the browser.

Please refer to: http://oaxoa.github.io/Conzole/
