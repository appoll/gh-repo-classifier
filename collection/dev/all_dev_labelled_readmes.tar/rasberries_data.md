RaspStore data
===
Node.js JSON API for the RaspStore app.
This repository is the source code of the api.


status
===
This standard is currently under development.




