#RecyclerView优秀文集
>收集RecyclerView优秀文章，持续更新欢迎提交pr，推荐star。
##入门篇
[还在用ListView?](http://www.jianshu.com/p/a92955be0a3e)  
[RecyclerView使用介绍](http://www.jianshu.com/p/12ec590f6c76)  
[深入浅出RecyclerView](http://kymjs.com/code/2016/07/10/01)  
[RecyclerView 和 ListView 使用对比分析](http://www.jianshu.com/p/f592f3715ae2)
##原理分析
[RecyclerView剖析](http://blog.csdn.net/qq_23012315/article/details/50807224)  
[RecyclerView源码分析](http://mouxuejie.com/blog/2016-03-06/recyclerview-analysis/)  
[读源码-用设计模式解析RecyclerView](http://www.jianshu.com/p/c82cebc4e798)  
[Android ListView 与 RecyclerView 对比浅析--缓存机制](https://mp.weixin.qq.com/s?__biz=MzA3NTYzODYzMg==&mid=2653578065&idx=2&sn=25e64a8bb7b5934cf0ce2e49549a80d6&chksm=84b3b156b3c43840061c28869671da915a25cf3be54891f040a3532e1bb17f9d32e244b79e3f&scene=0&key=&ascene=7&uin=&devicetype=android-23&version=26031b31&nettype=WIFI)
##扩展篇
[RecyclerView再封装](http://www.jianshu.com/p/a5dd9c0735f2)  
[封装那些事-RecyclerView封装实践](http://www.jianshu.com/p/a6f158d1a9c9)  
[RecyclerView学习(一)----初步认知](http://blog.csdn.net/tyk0910/article/details/51329749)  
[RecyclerView学习(二)----高仿网易新闻栏目动画效果](http://blog.csdn.net/tyk0910/article/details/51460808)  
[RecyclerView学习(三)----高仿知乎的侧滑删除](http://blog.csdn.net/tyk0910/article/details/51669205)  
[RecyclerView无法添加onItemClickListener最佳的高效解决方案](http://blog.csdn.net/liaoinstan/article/details/51200600)  
[ItemTouchHelper 使用RecyclerView打造可拖拽的GridView](http://blog.csdn.net/liaoinstan/article/details/51200618)  
[RecyclerView 实现快速滑动](http://blog.csdn.net/u014099894/article/details/51855129)  
[RecyclerView 顶部悬浮实现](http://www.jianshu.com/p/c596f2e6f587)  
[Android 自定义RecyclerView 实现真正的Gallery效果](http://blog.csdn.net/lmj623565791/article/details/38173061/)  
##[BRVAH](https://github.com/CymChad/BaseRecyclerViewAdapterHelper)  
[BRVAH优化篇](http://www.jianshu.com/p/411ab861034f)  
[BRVAH动画篇](http://www.jianshu.com/p/fa3f97c19263)  
[BRVAH多布局（上）](http://www.jianshu.com/p/9d75c22f0964)  
[BRVAH多布局（下）](http://www.jianshu.com/p/cf29d4e45536)  
[BRVAH分组篇](http://www.jianshu.com/p/87a49f732724)  


[查看更多BRVAH分享圈链接](https://github.com/CymChad/BRVAHST)
