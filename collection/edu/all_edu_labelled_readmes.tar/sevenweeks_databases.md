# Seven Database in Seven Weeks

Here is the code for each chapter of the seven languages book with attempted bug fixes.

The book to follow along is [Seven Databases in Seven Weeks](http://pragprog.com/book/rwdata/seven-databases-in-seven-weeks) available [here](http://pragprog.com/book/rwdata/seven-databases-in-seven-weeks).

* [PostgreSQL](databases/tree/master/chap2-postgresql)
* [Riak](databases/tree/master/chap3-riak)
* [HBase](databases/tree/master/chap4-hbase)
* [MongoDB](databases/tree/master/chap5-mongo)
* [CouchDB](databases/tree/master/chap6-couch)
* [Neo4j](databases/tree/master/chap7-neo4j)
* [Redis](databases/tree/master/chap8-redis)

The book code is also available from the [publisher's website](http://pragprog.com/titles/rwdata/source_code), though this github repo likely more up to date.
