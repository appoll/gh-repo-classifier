# datascience
It consists of examples, assignments discussed in data science/analytics course at algorithmica.

It also helps us to do build solutions to assignment problems collaboratively. You can push solutions to solutions branch
created inside assignments section.
