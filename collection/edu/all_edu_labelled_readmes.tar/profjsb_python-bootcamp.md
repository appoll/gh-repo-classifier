python-bootcamp
===============

[![Join the chat at https://gitter.im/profjsb/python-bootcamp](https://badges.gitter.im/profjsb/python-bootcamp.svg)](https://gitter.im/profjsb/python-bootcamp?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

Bootcamp docs and lectures