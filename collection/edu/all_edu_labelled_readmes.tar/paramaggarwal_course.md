# course-cms

## A CMS for managing college courses.

----

This is a project made by first year students at IIIT Allahabad in 2008 as part of their CSL Project.

----

This is a PHP/JS/CSS based CMS. It has these features:
  
* jQuery animations
* Logins for students/faculty/admin
* Voting system
* Report uploading system
* Admin page to edit notices
* Forum with theme integration

----

The team members were:

* Anvay Srivastava
* Chetan Agrawal
* Divij Vaidya
* Param Aggarwal
* Pranjal Kumar Singh
