# Urban Data Science

In this repo I have compiled a cycle of course materials, IPython notebooks, and tutorials 
towards an urban data science course based on Python.

Some of these course materials and their sequencing have been adapted from materials I previously 
taught in [CP255: Urban Informatics and Visualization](http://geoffboeing.com/2015/08/urban-informatics-visualization-berkeley/) at UC Berkeley.

These materials are licensed under the terms of the MIT license.