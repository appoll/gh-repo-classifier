datasci_course_materials
========================

Public repository for course materials for the Data Science at Scale specialization offered by Coursera and the University of Washington.

