## Information
#### codes, notes, reports in Kyutech's courses

***

* .md:
used [Markdown Preview Enhanced](https://github.com/shd101wyy/markdown-preview-enhanced "One of the 'BEST' markdown preview extensions for Atom editor!")

* .tex
used [TexLive](http://tug.org/texlive/ "nightmare?")

***

* .r
used r-base on [Ubuntu 16.04 LTS](https://wiki.ubuntu.com/XenialXerus/ReleaseNotes?_ga=1.109344453.1372159096.1477987520)

* .py
used python3.5 usually
