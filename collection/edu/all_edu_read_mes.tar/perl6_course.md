Shared repository for freely available Perl 6 course material
