Курсова робота з системного програмування
ТЗ:
    -Парсити аудіофайли з форматом метаданих id3.2.4 
    
https://drive.google.com/file/d/0B5VBc5N3P17KVS1kTDktNUZzTjA/edit?usp=sharing
