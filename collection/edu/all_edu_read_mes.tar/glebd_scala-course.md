scala-course
============

Coursera Scala course assignments