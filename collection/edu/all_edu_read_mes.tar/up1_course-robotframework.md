# course-robotframework
Workshop and Example of Robot Framework course


