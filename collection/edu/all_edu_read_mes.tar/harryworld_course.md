# Four Project Curriculum

## 1st Pass:

Introducing GitHub, programming fundamentals

1. Setting up the GitHub repository
2. Setting up GitHub Pages
3. Using Bootstrap 3
4. Command Line
5. CoffeeScript vs JavaScript
6. Variable
7. Chrome & Sublime
8. Arrays
9. Hashes
10. Conditionals
11. Loops
12. Functions
===
13. jQuery - DOM
14. jQuery - AJAX

## 2nd Pass:

We will start doing a project with all the fundamentals learned. The project will be doing a 2048 game in your web app.
