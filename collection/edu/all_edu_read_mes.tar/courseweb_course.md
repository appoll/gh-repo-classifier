# course

##Github 项目使用须知!!!
* 开发IDE一般都集成Github的功能，如果没有可以用命令行或者git gui等图形化管理工具
* 可以直接git clone 到本地，然后直接提交到这个仓库

##Git 常用命令
* git clone git@github.com:courseweb/course.git    #克隆仓库到本地
* 或者 git clone https://github.com/courseweb/course.git #上面那个是ssh方式,这个是https
* git add * 	
* git commit -m "xxx"
* git push -u origin master 	#上面三条用来向远程仓库提交代码
* git pull xxx.git #获取远程仓库的更新
* 记住先git pull再push!记住先git pull再push!记住先git pull再push!

##杂项
* 网址首页 http://115.28.173.183/ 服务器不定更新，目前以github为准
* 登录修改密码、查看修改个人信息测试页面 http://115.28.173.183/index.php/index/test/sparrow
* 发布查看老师交流心得测试页面 http://115.28.173.183/index.php/index/test/swallow
* 开发语言 php 5.6
