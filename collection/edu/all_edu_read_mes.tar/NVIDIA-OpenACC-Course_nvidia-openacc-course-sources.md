NVIDIA OpenACC Course Sources and Labs
======================================
This repository contains sources used in the [NVIDIA OpenACC
Course](https://developer.nvidia.com/openacc-course). The `lectures`
subdirectory contains sources used in the presentation slides. The `labs`
directory contains sources used in the homework labs.

License
-------
Unless otherwise noted, the source files contained within this repository are
Copyright NVIDIA CORPORATION and licensed under the 3-clause BSD license.
Please see the LICENSE file for more information.
