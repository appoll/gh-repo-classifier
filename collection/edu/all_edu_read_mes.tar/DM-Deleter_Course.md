# Course
Programming for Absolute Beginners
It has been a long time since Basic
