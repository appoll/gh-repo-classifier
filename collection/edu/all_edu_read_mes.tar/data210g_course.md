Examples for the class
