6.824: Distributed Systems in MIT
=====
http://pdos.csail.mit.edu/6.824/

Spring 2013

Tues/Thurs, 1-2:30, 32-144