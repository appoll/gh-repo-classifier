# course
some course homework script
