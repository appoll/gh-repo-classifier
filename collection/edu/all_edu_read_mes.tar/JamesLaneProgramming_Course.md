# Course
This repository will contain the content for the NSI games course.
