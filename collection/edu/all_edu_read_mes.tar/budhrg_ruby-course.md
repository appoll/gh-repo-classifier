ruby-course
===========

Ruby fundamental Course conducted in Vertis.
