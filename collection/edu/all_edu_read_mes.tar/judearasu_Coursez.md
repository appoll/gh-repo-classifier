# Problem updates

##NatJS
 * Scope Change
 * Event Delegation
 * http://dor.georgia.gov/sites/dor.georgia.gov/files/related_files/document/TSD/Form/TSD_Employees_Withholding_Allowance_Certificate_G4_1.pdf

