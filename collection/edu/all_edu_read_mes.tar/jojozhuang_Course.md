# Course
Source codes of some projects for Master Degree of Computer Science.

Here are the interesting ones:  
1. Travel Note(Course/CSC471/Project/): An iOS App for travel management, built with swift. [More Details](http://jojozhuang.github.io/portfolio/2016/01/30/Travel-Note/ "Travel Note")  
2. Restaurant(Course/CSC472/FinalProject/): An Android App for searching restaurants, built with java. [More Details](http://jojozhuang.github.io/portfolio/2016/01/27/Restaurant/ "Restaurant")  
3. My Web Server(Course/CSC435/MyWebServer/): A web server built with Java sockets, capable of handling general HTTP requests.[More Details](http://jojozhuang.github.io/portfolio/2016/01/10/My-Web-Server/ "My Web Server")  
