# Course
This is a Repo for my activities in a course.
