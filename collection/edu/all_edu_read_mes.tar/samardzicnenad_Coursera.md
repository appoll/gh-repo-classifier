Coursera
========

Courses that I took on www.coursera.org

Java course - Algorithms, Part I

Python course - An Introduction to Interactive Programming in Python
