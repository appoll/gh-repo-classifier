I do not maintain this project anymore.

A python script to download <a href='http://coursera.org/'>coursera</a> lecture assets. Read more about it <a href='http://abhirama.wordpress.com/2012/05/02/script-to-download-coursera-videos/' target='blank'>here</a>.