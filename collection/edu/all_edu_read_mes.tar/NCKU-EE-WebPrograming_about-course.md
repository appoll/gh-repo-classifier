﻿關於
=====
[![Gitter](https://badges.gitter.im/Join Chat.svg)](https://gitter.im/NCKU-EE-WebPrograming/about-course?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

本 github repo 是用來在[成大電機網際網路程式設計課程][1]中的 github 教學中使用

## 授課教授
- [張天豪副教授](http://office.ee.ncku.edu.tw/nckueechinese/professor/T710-darby/T0000000c.htm)

## 講師
- [Hychen](http://hychen.wuweig.org/about-me/) :: 示範用

## 助教
- [Wonder](http://merry.ee.ncku.edu.tw/~wonder/about-me/)
- [Mouther](http://mouther.github.io/about-me/)

## 修課學生

請修課的同學依照下列格式，利用[Pull Request][2]把你的自介連結加在下面

```
- [姓名(ID)](http://example.com) :: 簡介
```

### 2014

- [林廷毓(yoni2266)](http://yoni2266.github.io/about-me/) :: 簡介
- [鄭宇軒(ssfc8104)](http://ls2jsc.github.io/about-me/) :: 簡介
- [楊靜妃(jingfei)](http://jingfei.github.io/about-me/) :: 簡介
- [陳學誼(pocky)](http://pockychen.github.io/about-me/) :: 簡介
- [李政憲(Moksas)](http://moksas.github.io/about-me/)::簡介
- [鄭基漢(han)](http://hanago.github.io/about-me/) :: 簡介
- [吳怡倫(ashescat)] (http://ashescat.github.io/about-me/) :: 簡介
- [丁家麒(intheblackworld)](http://intheblackworld.github.io/about-me/) :: 簡介
- [蔡宗翰(hank)](http://hank2014.github.io/about-me/) :: hello!everybody!
- [謝政穎(pix0127)](http://pix0127.github.io/about-me/) :: 簡介
- [吳享龍(dragom6511)](http://dragom6511.github.io/about-me/) :: 簡介
- [魏禛(cwei)](http://cwei83.github.io/about-me/) :: 簡介
- [楊璿衛(hsuanweiyang)](http://hsuanweiyang.github.io/about-me/) :: 簡介
- [詹欣達(dada8397)](http://dada8397.github.io/about-me/) :: 簡介
- [楊耘臺(mroops0111)](http://mroops0111.github.io/about-me/) :: 簡介
- [李育丞(ycl)]( http://atumama.github.io/about-me/)::示範用 
- [陳彥蓉(Amomo)](http://amomo.github.io/about-me/) :: 簡介
- [洪梓軒(SimplePower)](https://simplepower.github.io/about-me) :: 簡介
- [劉書瑋(yukei456)](http://yukei456.github.io/about-me/) :: 簡介
- [嚴宇(beau)](http://e24016611.github.io/about-me) ::簡介
- [蔡森至(senchih)](http://senchih.github.io/about-me/) :: 大家在簡介欄位打「簡介」兩個字的用意是什麼
- [鄭宇傑(lightning10)](http://lightning10.github.io/about-me/) :: 簡介
- [羅文懋(mow1018)](http://mow1018.github.io/about-me/) ::簡介
- [邱鼎翔(ShiauJhe)](http://shiaujhe.github.io/about-me/) ::新.新
- [張家綸(FlyinRush)](http://flyinrush.github.io/about-me/) ::簡介
- [張峻瑋(wei)](http://weihi.github.io/about-me/) ::簡介
- [陳志源(kouynzvf)](http://kouynzvf.github.io/about-me/) :: 簡介
- [賴志維(ab3896423)](http://ab3896423.github.io/about-me/)::))
- [陳貞霓(CSChenVB)](http://cschenvb.github.io/about-me/) :: 簡介
- [方沛涵(almightybobo)](http://almightybobo.github.io/about-me/) ::BOBO
- [呂明翰(HankLyu)](http://HankLyu.github.io/about-me/) ::HaHa
- [鍾旭成(c28341994)](https://c28341994.github.io/about-me) :: 簡介
- [黃啟軒(chihsuan)](http://chihsuan.github.io/about-me/) :: 簡介
- [孫培峰(befong000)](http://befong000.github.io/about-me/) :: 簡介
- [Henry Su(henrysutw)](http://henrysutw.github.io/about-me/) :: 簡介

[1]: http://zoro.ee.ncku.edu.tw/wp2014/
[2]: https://help.github.com/articles/using-pull-requests
