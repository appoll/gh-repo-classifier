# CS 186 Fall 2016

Course repository for [CS 186, Fall 2016](http://cs186berkeley.net). All
homeworks and projects will be released here. Please use this repository to
get the starter code for the projects. If you have any questions, see hw0 or
post on [Piazza](https://piazza.com/class/is0phopc27275j).

All course announcements will be on the course website and on Piazza.
