# course
== Course Management System ==

Detail...
1. Database: db_course.sql
2. Default Page: index.php
3. Web server: apache

Initial config...
in Folder controller/connect.php for set up connect to database.
$dbi['server'] = "localhost";
$dbi['name'] = //Database name
$dbi['user'] = //username
$dbi['password'] = //password


Username&Password for test
Student - username: stu1 , Password: stu1
Instructor - username: ins1 , Password: ins1