# courses

- [Pluralsight](./pluralsight)
- [Free Code Camp](./freecodecamp)
- [Udacity](./udacity)
- [TalentBuddy](./talentbuddy)
