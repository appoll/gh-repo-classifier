# course
社課資訊
https://elantris.github.io/course/

## 大開源計劃 - 社課

| Date | Title| Description |
|---|---|---|
| 20161011 | 初探 Node.js 與網頁前端工具 | 交通大學網路福利社 |
| 20161012 | 初探 Node.js 與網頁前端工具 | 中央大學網路開源社 |
| 20161018 | 網頁前端框架與 JavaScript 套件 | 交通大學網路福利社 |
| 20161019 | 網頁前端框架與 JavaScript 套件 | 中央大學網路開源社 |

## 開源社 - 104-2 社課

| Date | Title| Description |
|---|---|---|
| 20160311 | NTUOSC JavaScript | https://hackmd.io/s/N1ERJm5Ux |
| 20160603 | NTUOSC Build System | https://hackmd.io/s/EJgZvEyfCx |
