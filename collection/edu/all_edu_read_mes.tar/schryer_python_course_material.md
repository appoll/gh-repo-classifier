# Welcome to Scientific Programming with Python

Please refer to the
[course website](http://schryer.github.io/python_course_material) for
details about the live version of this course being given at the
University of Tartu.  The first lesson is on September 2nd, 2014 and
will continue for 16 weeks.
