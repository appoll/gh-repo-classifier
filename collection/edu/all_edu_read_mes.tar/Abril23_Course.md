We learn how to use 'git commit'
