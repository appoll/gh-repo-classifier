This web application is for web selection & registration with Python(Flask)
