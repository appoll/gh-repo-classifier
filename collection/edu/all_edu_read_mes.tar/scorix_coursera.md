#Coursera Assignments

##What's this
This is my coursera assignments. Some code is **WRONG**. I'm still learning.

##Resources
* [Machine Learning](https://class.coursera.org/ml-003) (by __Andrew Ng__)
* [The Hardware/Software Interface](https://class.coursera.org/hwswinterface-001) (by __Luis Ceze, Gaetano Borriello__)
* [An Introduction to Interactive Programming in Python](https://class.coursera.org/interactivepython-002) (by __Joe Warren, John Greiner, Stephen Wong, Scott Rixner__)
* [Functional Programming Principles in Scala](https://class.coursera.org/progfun-002) (by __Martin Odersky__)
