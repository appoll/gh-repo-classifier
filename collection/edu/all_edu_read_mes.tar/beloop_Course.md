Course Component
================

[![Build Status](https://travis-ci.org/beloop/Course.png?branch=master)](http://travis-ci.org/beloop/Course)
[![Latest Stable Version](https://poser.pugx.org/beloop/course/v/stable)](https://packagist.org/packages/beloop/course)

This package is part of [Beloop](http://github.com/beloop/components) project, a
suite of Learning Management System Components and Bundles built on top of Symfony and under
[MIT](http://opensource.org/licenses/MIT) license.

> Warning. This package is Read-Only. This means that we'll not attend any Pull 
> Request received here. Please, use the main beloop/components package for Issues,
> Questions and Pull Requests.
