# course

untuk installasi pertama 

create database course
import course.sql

bikin virual host atau jalankan perintah ini menggunakan composer

php artisan serve

klo server udah jalan default nya di alamat http://localhost:8000/

login sebagai admin 

username admin@example.com  password password
username manager@example.com password password
username employee@example.com password password 

