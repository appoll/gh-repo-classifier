![We Can Code IT](wcci_logo.png)

## Latest Updates

[Post-grad resources](week13)

## Summer 2016 Full-Time Cohort

Welcome! I can't wait to get started with our boot camp.

This repository will be updated as we progress through the 12 weeks. For now, you should probably check out the [Prework](week0/prework.md). You may also want to take a look at the [Syllabus](week0/syllabus.md). The [Expectations](week0/expectations.md) that were developed collaboratively at orientation are also online - if you have any feedback about them or would like to change something, you can contact me, or create a pull request!

I'm `@james` on the [WeCanCodeItBootcamp](https://wecancodeitbootcamp.slack.com) Slack team, or you can email me at <mailto:james@wecancodeit.org>.
