# Coursera Video Downloader script

This script helps in downloading the videos present in coursera, just by providing few details like

 - Email Id
 - Password
 - CourseId
 - Local path where the videos should be downloaded