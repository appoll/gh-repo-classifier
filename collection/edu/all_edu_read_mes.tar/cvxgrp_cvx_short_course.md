# cvx_short_course
Materials for a short course on convex optimization.
