Coursera
========

"Introduction to Interactive Programming in Python" Course from RICE University - coursera.org
