My courses
================================

Here you can find tips and solutions for some of the courses I enrolled.

* Doing
	* Python - http://www.codecademy.com/en/tracks/python [Codecademy]
	* Corpus Linguistics: Method, Analysis, Interpretation [FutureLearn]
	* A hands-on introduction to statistics with R [DataCamp]

* Completed
	* Pensamiento Algorítmico [Coursera]
	* Data Science - Specialization [Coursera]
		* The Data Scientist's Toolbox 
		* R Programming 
	* Initiation a la programmation (en Java) [Coursera]
	* Developing Innovative Ideas for New Companies: The First Step in Entrepreneurship. (Entrepreneurship: Launching an Innovative Business - Specialization) [Coursera]
	* Questionnaire Design for Social Surveys [Coursera]
	* Programming for Everybody (Python) [Coursera]
	* An Introduction to Interactive Programming in Python (Fundamentals of Computing - Specialization) [Coursera] 


* Dropped
	* Approaches to Machine Translation Rule-based, Statistical and Hybrid [Universitat Politècnica de Catalunya, BarcelonaTech]







### Follow me on
<!-- Please don't remove this: Grab your social icons from https://github.com/carlsednaoui/gitsocial -->

<!-- display the social media buttons in your README -->

[![alt text][1.1]][1]
[![alt text][2.1]][2]
[![alt text][3.1]][3]
[![alt text][4.1]][4]



<!-- links to social media icons -->
<!-- no need to change these -->

<!-- icons with padding -->

[1.1]: http://i.imgur.com/tXSoThF.png (twitter icon with padding)
[2.1]: http://i.imgur.com/P3YfQoD.png (facebook icon with padding)
[3.1]: http://i.imgur.com/yCsTjba.png (google plus icon with padding)
[4.1]: http://i.imgur.com/0o48UoR.png (github icon with padding)


<!-- links to your social media accounts -->
<!-- update these accordingly -->

[1]: https://twitter.com/#!/hernanimax
[2]: https://www.facebook.com/hernani.costa.161
[3]: https://plus.google.com/+HernaniCosta
[4]: https://github.com/hpcosta