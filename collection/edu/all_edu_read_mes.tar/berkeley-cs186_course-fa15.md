# course
Official public repository for CS 186 assignments.

For details about how submitting assignments in CS 186 works, look at [`hw0`](https://github.com/berkeley-cs186/course/blob/master/hw0/README.md).
