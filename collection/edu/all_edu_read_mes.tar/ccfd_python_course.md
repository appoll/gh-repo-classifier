Bunch of materials required for the Python course.
