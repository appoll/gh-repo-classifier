# Intro Programming with Ruby

Course work for introduction to programming with ruby
