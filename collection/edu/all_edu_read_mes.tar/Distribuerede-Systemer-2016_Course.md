# Distributerede systemer

Dette repository indeholder filer, der er relevante for selve faget.

### Forventninger til faget

1. Vi vil gerne lære netværksprogrammering.
2. Vi vil gerne blive bedre til at programmere.
3. Vi vil gerne lære mere om IT-sikkerhed.
4. Vi vil gerne arbejde med mange forskellige sprog.
5. Vi vil gerne være mere selvkørende.
6. Vi vil gerne lære mere om hardware.
7. Vi vil gerne forstå samspillet mellem enhed og netværk.
8. Vi vil gerne forstå hvordan netværket fungerer.
9. Vi vil gerne have nogle sjove forelæsninger.
10. Vi vil gerne kigge på nogle rigtige distribuerede systemer.
11. Vi vil gerne forstå den kode, som andre har udviklet.
12. Vi vil gerne få udviklet vores programmeringskompetencer.
13. Vi vil gerne få mere erfaring med app-udvikling.
14. Vi vil gerne lære mere om at samarbejde via GitHub.
15. Vi vil gerne lære noget, der kan bruges efterfølgende.
