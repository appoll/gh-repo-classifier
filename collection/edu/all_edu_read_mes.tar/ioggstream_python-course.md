#python-course


Python exercises and materials for various courses.

## basic python

An introductory course for people knowing other languages.

 - lessons: 2
 - duration: 2 hours

## python for system administrator

 A course for system administrators (Linux, Windows, Mac)


## TODO

* intermediate python
* python for performance testing 





