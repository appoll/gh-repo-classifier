## A machine learning course based on Jupyter Notebooks

http://openml.github.io/course
