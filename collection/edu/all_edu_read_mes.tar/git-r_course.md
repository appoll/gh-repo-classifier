course
======

repo created for the statitistics course
