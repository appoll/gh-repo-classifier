# course

This is the main repository for a graduate course in hierarchical Bayesian modeling taught in Spring 2016, designed to be used with the course [notes](https://github.com/hmods/notes) and Gelman and Hill's textbook on multilevel modeling. 
We will push slides, assignments, and solutions as the semester progresses. 
