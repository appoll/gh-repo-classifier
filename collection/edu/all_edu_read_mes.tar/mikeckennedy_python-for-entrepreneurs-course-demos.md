# Course: Python for Entrepreneurs - Build your online business or product with Python

![](https://github.com/mikeckennedy/python-for-entrepreneurs-course-demos/raw/master/readme_resources/python-for-entrepreneurs.png)

The Python for Entrepreneurs online course is now [available for preorder](https://training.talkpython.fm/courses/explore_entrepreneurs/python-for-entrepreneurs-build-and-launch-your-online-business) with immediate early access. 

See all the course details and intro video [on the course page](https://training.talkpython.fm/courses/explore_entrepreneurs/python-for-entrepreneurs-build-and-launch-your-online-business).
	

