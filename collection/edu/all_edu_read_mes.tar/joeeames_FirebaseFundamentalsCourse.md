###Firebase Fundamentals Course Repository

This course is out of date. It is built against Firebase v2. Firebase v3 is now released. There are some changes especially regarding authentication, although all of the data access API's are essentially unchanged, so most of the course is still up to date.
