# SEOshop Tech Course

Welcome to the SEOshop Tech Course.
Please follow the instructions in /Setup before continuing your journey to become an awesome dev.

