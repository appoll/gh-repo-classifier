#重构基础知识培训


    重构基础知识培训
    │  
    ├── 常用工具
    │   
    ├── 切图技巧
    │
    ├── CSS基础
    │
    ├── SASS基础
    │
    ├── YO的使用
    │
    └── 学习资源

## 常用工具
* 编辑工具 Zen Coding or emmet
* 查询工具 Dash
* 查询网站 

## 切图技巧
* 分析psd设计稿
* 切图注意事项
* 保存图片大小
* 图片存放服务器(web font 字体存放位置)

## CSS基础
* png图片在ie6下显示
* 布局
* 选择器的级别

## SASS基础


## YO的使用


## 学习资源

####前端重构大牛微博

* 大漠 http://www.w3cplus.com/
* 瑶姐 http://www.doyoe.com/

#### 视频网站

* 慕课网 http://www.imooc.com/