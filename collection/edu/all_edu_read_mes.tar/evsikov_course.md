Local javascript course code repository for homework
