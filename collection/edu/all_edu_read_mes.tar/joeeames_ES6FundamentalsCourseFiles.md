JavaScript Fundamentals for ES6 course files
==========================

This course is currently up to date

### Commands to start
```
$ cd starter_with_traceur
$ npm install
$ bower install
$ grunt
```
