Repository to store courses for PyCharm Educational Edition

for general Pycharm / courses discussion, see:

 * Reddit: http://www.reddit.com/r/Python/comments/2kt3pb/pycharm_educational_edition_is_here_to_teach_you/
 * Youtrack: https://youtrack.jetbrains.com/issue/EDU-274 (Course localization)
 * Getting started: https://www.jetbrains.com/pycharm-educational/quickstart/getting_started_educators.html
