# Курс по Python по работе с VK API 

## Как запустить скрипт

**Кликните по картинке**, чтобы перейти на видео https://www.youtube.com/watch?v=5ME-N2iOJe4 

[![IMAGE ALT TEXT HERE](http://img.youtube.com/vi/5ME-N2iOJe4/0.jpg)](http://www.youtube.com/watch?v=5ME-N2iOJe4)

1. Скачать https://www.continuum.io/downloads Python 3.5 для вашей операционной системы
2. Дождаться установки
3. Отредактировать ярлык у Jupiter Notebook (сменить рабочу папку) 
![alt](https://api.monosnap.com/rpc/file/download?id=SeeK3e88SV73rjGozcRbGIu5EQdqtQ)
4. Запустить Jupiter Notebook
5. Скачать файл скрипта и переместить в рабочую папку
6. Запустить скрипт
![alt](https://api.monosnap.com/rpc/file/download?id=m2n56TkMUoMpqG71JGTqjdK8wmqwu5)
7. Следовать инструкции в скрипте

## Как построен курс
Курс построен таким образом, что каждый новый урок знакомит вас с основными вещами языка программирования, паралелльно решая весьма практическую задачу, связанную с работой с ВКонтакте.
