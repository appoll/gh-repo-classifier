Course
------
Course is light PHP static website to create online course or doc. Content is written in **Markdown** and **HTML**.

Course use [Twig](https://github.com/twigphp/Twig) and [Parsedown](https://github.com/erusev/parsedown).  
Design is based on [Eluna](http://eluna.emudevs.com/) and structure on [daux.io](http://daux.io/)

Course is under WTFPL-2.0 license, read [LICENSE](LICENSE) file
