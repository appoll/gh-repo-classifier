# COURSE
Héritage, abstract class &amp; meh
