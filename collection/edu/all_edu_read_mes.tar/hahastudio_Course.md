Course
======

A Course Management System by Django
