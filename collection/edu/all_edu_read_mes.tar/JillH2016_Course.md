# Course
Of Course


name = 'John Smith';
console.log(name + " enters the system");
var result = buyThing(name);
console.log("sale success " + result);
