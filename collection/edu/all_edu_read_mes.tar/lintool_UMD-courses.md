University of Maryland Course Homepages
---------------------------------------

+ [My big data course](http://lintool.github.com/UMD-courses/bigdata-2015-Spring/), version 5.0 (Spring 2015)
+ [My big data course](http://lintool.github.com/UMD-courses/bigdata-2013-Spring/), version 4.0 (Spring 2013)
+ [My big data course](http://lintool.github.com/UMD-courses/bigdata-2010-Spring/), version 3.0 (Spring 2010)
+ [My big data course](http://lintool.github.com/UMD-courses/bigdata-2008-Fall/), version 2.0 (Fall 2008)
+ [My big data course](http://lintool.github.com/UMD-courses/bigdata-2008-Spring/), version 1.0 (Spring 2008)
+ INFM 603: Information Technology and Organizational Context [(Fall, 2014)](http://lintool.github.io/UMD-courses/INFM603-2014f/) [(Spring, 2014)](http://lintool.github.io/UMD-courses/INFM603-2014s/) [(Fall, 2013)](http://lintool.github.io/UMD-courses/INFM603-2013f/) [(Fall, 2012)](http://lintool.github.io/UMD-courses/INFM603-2012f/) 
+ CMSC 723: Computational Linguistics I [(Fall 2009)](http://lintool.github.io/UMD-courses/CMSC723-2009-Fall/)
+ LBSC 888: Doctoral Seminar [(Fall 2009)](http://lintool.github.io/UMD-courses/LBSC888-2009-Fall/)
+ LBSC 690: Information Technology [(Fall 2008)](http://lintool.github.io/UMD-courses/LBSC690-2008-Fall/) [(Fall 2007)](http://lintool.github.io/UMD-courses/LBSC690-2007-Fall/) [(Spring 2007)](http://lintool.github.io/UMD-courses/LBSC690-2007-Spring/)
+ INFM 700: Information Architecture [(Spring 2008)](http://lintool.github.io/UMD-courses/INFM700-2008-Spring/)
+ LBSC 796/INFM 718R: Information Retrieval Systems [(Spring 2006)](http://lintool.github.io/UMD-courses/LBSC796-INFM718R-2006-Spring/)
+ LBSC 690: Information Technology [(Gallery of Final Projects)](http://lintool.github.io/UMD-courses/LBSC690-Final-Project-Gallery/)