# EPFL Machine Learning Course CS-433
Machine Learning Course, Fall 2016 (a.k.a. PCML)

Repository for all lecture notes, labs and projects - resources, code templates and solutions.

The course website and syllabus is available here: [http://mlo.epfl.ch/page-136795.html]

Contact us if you have any questions: [epfmlcourse@gmail.com](mailto:epfmlcourse@gmail.com), or feel free to create issues and pull requests using the menu above.
