CoursesPortlet is a JSR-286 portlet that displays individual content from an SIS and/or LMS.

For more information, please visit [the CoursesPortlet wiki home](https://wiki.jasig.org/display/PLT/Courses+Portlet).
