# CSCI-4830-006 HCI Big Data (Hackathons)


## Learning Challenges

Each week, students are given a take-home challenge to learn about certain
important concepts, skills, or tools about big data and HCI.

## In-class Hackathons

At the end of the week, students meet in class to participate in a hackathon in
which they apply what they've just learned to an important problem.
