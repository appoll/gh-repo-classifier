# Quick Coding with Brackets

This is the demo project to go along with Quick Coding with Brackets course. It is a cheat sheet for keyboard shortcuts and the how to use the editor on both a Mac and a PC.

[Brackets Cheat Sheet](http://lisacatalano.github.io/brackets_course/).

Each commit in the course been tagged so you can follow along.

The full free 2.5 hour course can be found at [css-snippets.com](http://css-snippets.com/brackets-course), or you can watch directly on [YouTube](https://www.youtube.com/playlist?list=PL_VA_vL3FHcZxaB36NcOtQIWqz7bXKWLo).

