# course
Run <b>"course/run.cmd"</b> to start the server.<br />
Then open browser type: <b>localhost:3000</b>
