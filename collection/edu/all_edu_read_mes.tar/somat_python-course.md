Python Course at AirPutih

This is public repository for storing the practical python course.

http://www.airputih.or.id

