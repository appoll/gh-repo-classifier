# Org
Utility to help with note taking in class.
