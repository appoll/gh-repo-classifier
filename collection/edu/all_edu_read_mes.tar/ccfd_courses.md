# Repository for CCFD courses materials created under CC license

The materials are stores in the markdown (.md) or Rmarkdown (.Rmd) format. This format can be easly transformed to both pdf documents and html pages

## Proposing changes

If you want to change anything in the existitng material, please edit in GitHub the selected file, and propose the change as a Pull Request.

## Auto generated site

All the instructions are auto-rendered with rmarkdown package and are avaliable for viewing here:

http://ccfd.github.io/courses/


