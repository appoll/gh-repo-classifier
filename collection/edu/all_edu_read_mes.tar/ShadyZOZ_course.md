code done in courses, feel free to git.

---

#### Directory

- course
    - [cryptography](https://github.com/ShadyZOZ/course/tree/master/cryptography)
        - [caesar](https://github.com/ShadyZOZ/course/tree/master/cryptography/caesar)
            - [MFC](https://github.com/ShadyZOZ/course/tree/master/cryptography/caesar/mfc/caesar)
            - [PHP](https://github.com/ShadyZOZ/course/tree/master/cryptography/caesar/php)
            - [Python](https://github.com/ShadyZOZ/course/tree/master/cryptography/caesar/python)
        - [DES](https://github.com/ShadyZOZ/course/tree/master/cryptography/des)
        - [permutation](https://github.com/ShadyZOZ/course/tree/master/cryptography/permutation)
        - [RSA](https://github.com/ShadyZOZ/course/tree/master/cryptography/rsa)
    - [socket](https://github.com/ShadyZOZ/course/tree/master/socket)
