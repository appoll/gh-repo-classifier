# coursera
Items related to Coursera course work
