# INFO340B

## Resources

### Core tools
- [Install core Golang tools](guides/golang.md)
- [Install SQLite](guides/sqlite.md)

### Editors and IDEs
- [Atom](guides/atom.md)
- [COMING SOON - Sublime]()
- [COMING SOON - IntelliJ IDEA Ultimate]()

### OS specific settings
- [Managing path and environment variables in OS X (without needing to learn VIM)](guides/mac_env.md)
- [Managing path and environment variables in Windows](http://www.computerhope.com/issues/ch000549.htm)
- [COMING SOON - Installing Git Bash for Windows]()



