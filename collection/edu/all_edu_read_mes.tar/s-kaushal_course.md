course
======

Work being done duuring my data science course
