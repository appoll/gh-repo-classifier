# Coursewares of Database Principles 2012

This repo contains all the coursewares of database principles class in 2012. Every team (in github you are organizations actually) please fork this repo from @ToyhouseChina otherwise we can not guarantee the integrity of your repo.

Also, please always put your topic slides at the right place otherwise I will delete the file or even will not merge for you.

Last, please make your sildes in the repo from the very beginning. Then you can have the history and we can witness your progress.

More, see the wiki https://github.com/ToyhouseChina/Courseware/wiki

# *Notes:*

1. Only **pdf** format silde are accepted, please convert your slides to pdf after your presentations.
2. Please use **markdown** to write your README.md and README is always required in each directory.

##Power by [Toyhouse](http://toyhouse.cc/)

The online course is here [http://tsinghuatoyhouse.appspot.com](http://tsinghuatoyhouse.appspot.com) based on [google course builder](https://code.google.com/p/course-builder/).