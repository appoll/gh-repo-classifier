data
====

The repository for the CMU Data Pipeline course (http://data.cmubi.org)
