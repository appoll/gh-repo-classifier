Python for Data Science
====================

Code for the tutorial at: http://blog.kaggle.com/?p=2870

To run this code, you will a files called train.csv and test.csv in a \data folder. I recommend anyone interested in running this code pull down data from Kaggle's "Predicting a biological response" competition.