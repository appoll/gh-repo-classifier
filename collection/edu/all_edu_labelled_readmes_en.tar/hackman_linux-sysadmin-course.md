linux-sysadmin-course
=====================

Linux System Administration 101

This repo includes additional materials and presentations for the course.

It also includes all homeworks.


Grades:
* Two tests, each with 50 questions
* One question one point
* Each homework is one more point. The points from the homeworks allow you to have some degree of errors on the tests

* Bonuses - up to 10 points 

Bonuses are gained from the forums and extraordanary good homeworks.

* 6 = 91-100 points
* 5 = 81-90 points
* 4 = 71-80 points
* 3 = 61-70 points
* 2 =  0-60 points
  
