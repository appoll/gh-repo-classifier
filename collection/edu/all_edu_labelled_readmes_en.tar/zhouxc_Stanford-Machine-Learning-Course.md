These are some programming exercise of Stanford Machine Learning Online Course.
The algorithms were coded in python or matlab including:
1.Anomaly Detection and Recommender Systems
2.Decision Trees&Boosting 
3.HMM
4.K-Means Clustering and PCA
5.Linear Regression
6.Logistic Regression (matlab/octave)
7.Multi-class classification and neural networks
8.Neural network learning
9.Regularized linear regression and bias-variance
10.Support Vector Machiness
