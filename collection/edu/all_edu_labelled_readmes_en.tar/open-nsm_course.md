# course
Materials for the NSM video course.
1. Vagrantfiles used in course
2. Notes
3. Exercises
4. Other documentation
