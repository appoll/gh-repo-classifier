### NYU Data Storytelling

This is the official github repo for [ITPG-GT 2517 001 Data Science Storytelling](http://hmason.github.io/datastorytelling/), a seven-week exploration of narrative data analysis.

All student work should be submitted via pull request to this repo.

