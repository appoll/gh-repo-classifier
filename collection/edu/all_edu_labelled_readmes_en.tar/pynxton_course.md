Python course
===============

See notebooks in `nbviewer <http://nbviewer.ipython.org/github/pynxton/course/tree/master/>`_

Booked room for the course on **Thursday 4-5 pm** mostly in the Meadow room (EBI south building)


========== ============ ====================================================================================
 date         where         
========== ============ ====================================================================================
 16 Oct     Meadow        `1.basics <http://nbviewer.ipython.org/github/pynxton/course/tree/master/>`_
 23 Oct     Meadow        `1.basics <http://nbviewer.ipython.org/github/pynxton/course/tree/master/>`_
 30 Oct     Meadow        `2.programming <http://nbviewer.ipython.org/github/pynxton/course/tree/master/>`_
 6  Nov     Meadow        `2.programming <http://nbviewer.ipython.org/github/pynxton/course/tree/master/>`_  
 13 Nov     Ickleton      `3.Matplotlib <http://nbviewer.ipython.org/github/pynxton/course/blob/master/3.%20Matplotlib.ipynb>`_
 20 Nov     Ickleton      `4.Object Oriented in Python <http://nbviewer.ipython.org/github/pynxton/course/blob/master/4.%20Class%20and%20objects.ipynb>`_
 27 Nov     Meadow        `5.numpy/scipy/pandas overview`
 4 Dec      Ickleton      `6.Packaging <https://github.com/cokelaer/python_notes/blob/master/source/packaging.rst>`_
========== ============ ====================================================================================

