Data-Scientist-MOOC
===================

Coursera class in data science using R
