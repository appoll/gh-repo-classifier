# Coursera: HTML, CSS and Javascript for Web Developers
## Example Source Code
This repository contains all of the example source code used in the Coursera.org course called
[HTML, CSS and Javascript for Web Developers](https://www.coursera.org/learn/html-css-javascript-for-web-developers).

[Enroll now! It's free!](https://www.coursera.org/learn/html-css-javascript-for-web-developers)


## Frequently Asked Questions
Please check our FAQ to see if a question you want to ask on the forums has been answered already. Here is the link to the FAQ:

[Frequently Asked Questions](FAQ.md)
