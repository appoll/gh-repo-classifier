 Welcome to the Hadoop world，There is the most authoritative course!
  - Season One: Enterprise SQL-on-Hadoop Solution 

# Enterprise_Hadoop_Solutions

- Mac os X：brew install git

- command: git clone git@github.com:itweet/course.git

- 微博：http://weibo.com/sparkjvm

- 百度云: http://pan.baidu.com/s/1dDnpT6p rg03

- Video：http://www.tudou.com/home/sparkjvm/

- Blog：http://www.itweet.cn/



# course
```
D:\ENTERPRISE_HADOOP_SOLUTIONS
├─0、Hadoop企业级应用实战之Centos安装&&Hadoop存储规划
├─1、Hadoop企业级应用实战之Apache-Hadoop介绍
├─2、Hadoop企业级应用实战之Hadoop前世今生
├─3、Hadoop企业级应用实战之动物园管理员zookeeper
├─4、Hadoop企业级应用实战之Hadoop集群构建思考_CDH集群构建
├─5、Hadoop企业级实战之集群资源分配和进阶使用&&HDP集群构建(new)
├─6、Hadoop企业级应用实战之SQL-on-Hadoop
│  ├─Drill
│  ├─Hbase-phoenix
│  ├─Hive
│  │  └─tez
│  ├─Impala
│  ├─presto
│  ├─sparksql
│  └─Tez
└─大数据十周年纪念日
```
