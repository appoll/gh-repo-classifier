STAT545-UBC.github.io
=====================

Main repository for STAT 545 @ University of British Columbia, a course in data wrangling, exploration, and analysis with R.

The `master` branch of this repository underpins this webpage: <http://stat545-ubc.github.io>.
