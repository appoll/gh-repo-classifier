Here you will find all the source material for my Haskell course,
known as "CIS 194" (its course number when I taught it at U Penn).
Note that the course was taught several more times at Penn by other
instructors after I left; this repo does not contain any of their
materials.

There are no solutions here.  My solutions are in another
castle^H^H^H^H^H^H private repo, to which I'm happy to give access on
request.

All the material here is licensed under a
[Creative Commons Attribution 4.0 International License](http://creativecommons.org/licenses/by/4.0/).
