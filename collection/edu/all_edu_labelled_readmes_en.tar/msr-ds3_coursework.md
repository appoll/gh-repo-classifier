# MSR NYC Data Science Summer School 2016

This is the shared repository for Microsoft Research NYC's 2016 Data Science Summer School (DS3).

* [Week 1](week1/): Git(hub), command line, exploratory data analysis in R
* [Week 2](week2/): Intro to statistics and machine learning
* [Week 3](week3/): More modeling
* [Week 4](week4/): Classification, Python, APIs
