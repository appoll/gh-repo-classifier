#Data Science in Python

###DataGotham 2013 tutorial

## Installation instructions for Scientific Python [here](http://nbviewer.ipython.org/urls/raw.github.com/hernamesbarbara/Scientific_Python_Setup/master/Setting_Up_Your_Python_Environment.ipynb)


## To run

    $ cd notebooks
    $ ipython notebook --pylab inline
