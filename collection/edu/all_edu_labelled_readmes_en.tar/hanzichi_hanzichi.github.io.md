**【Notice: 请在 chrome 下看 demo，不保证其他浏览器的兼容性】**
# 2016

- [超级马里奥 (Canvas)](http://hanzichi.github.io/2016/superMario/) [wait for a while for loading...]
- [BigRender](http://hanzichi.github.io/2016/bigrender/)
- [Integer to Roman & Roman to Integer](http://hanzichi.github.io/2016/integer-roman-conversion/)
- [image to base64](http://hanzichi.github.io/2016/image2base64/)
- [数独在线求解](http://hanzichi.github.io/2016/sudoku-killer/)
- [a simple canvas game](http://hanzichi.github.io/2016/a-simple-canvas-game/)


# 2015

- [base64 encode & decode](http://hanzichi.github.io/2015/base64-encode-decode/)
- [颜色调配 (hsl)](http://hanzichi.github.io/2015/color-to-show/hsl.html)
- [颜色调配 (rgba)](http://hanzichi.github.io/2015/color-to-show/rgba.html)
- [CSS3 标签云](http://hanzichi.github.io/2015/css3-cloudtag/)
- [CSS3 正方体](http://hanzichi.github.io/2015/css3-cube/)
- [CSS3 图片轮播](http://hanzichi.github.io/2015/css3-picture-carousel/demo2.html)
- [CSS3 打字机游戏](http://hanzichi.github.io/2015/css3-typewriter-game/)
- [drag & drop](http://hanzichi.github.io/2015/drag-and-drop/)
- [图片延迟加载](http://hanzichi.github.io/2015/picture-lazyload/)
- [博客园简介 (reveal demo)](http://hanzichi.github.io/2015/reveal/cnblogs.html)
- [百度搜索下拉联想](http://hanzichi.github.io/2015/search-pull-down/index.h5.html)
- [To My Lover on Feb.14 2015 (Canvas)](http://hanzichi.github.io/2015/love-on-20150214/)
- [魔方 (Canvas)](http://hanzichi.github.io/2015/magic-cube/)
- [粒子特效 (Canvas)](http://hanzichi.github.io/2015/particle-system/)
- [打字机游戏 (Canvas)](http://hanzichi.github.io/2015/canvas-typewriter-game/)
- [子弹追踪 (Canvas)](http://hanzichi.github.io/2015/bullet-trace/)
- [是男人就走30步 (Canvas)](http://hanzichi.github.io/2015/go-30-steps-if-you-are-a-man/)
- [3D 标签云 (JS 实现)](http://hanzichi.github.io/2015/js-cloudtag/)
- [文字粒子特效 (Canvas)](http://hanzichi.github.io/2015/particle-text/)
- [Show Love (Canvas)](http://hanzichi.github.io/2015/show-love/)
- [文字 cube 化效果 (Canvas)](http://hanzichi.github.io/2015/particle-cube/)


# 2014

- [FlowerPower (Canvas)](http://hanzichi.github.io/2014/FlowerPower/)
- [花丛文字效果 (Canvas)](http://hanzichi.github.io/2014/flower-text/)


# 2013

- [碰撞的矩形 (Canvas)](http://hanzichi.github.io/2013/a-running-rectangle/)
- [一个简单的画板 (Canvas)](http://hanzichi.github.io/2013/a-simple-drawing-board/)
- [A tree (Canvas)](http://hanzichi.github.io/2013/a-simple-tree/)
- [贪食蛇游戏 (Canvas 实现)](http://hanzichi.github.io/2013/snake-canvas/)
- [贪食蛇游戏 (Dom 实现)](http://hanzichi.github.io/2013/snake-dom/)
- [双圈戏黑夜 (Canvas)](http://hanzichi.github.io/2013/two-running-circles/)