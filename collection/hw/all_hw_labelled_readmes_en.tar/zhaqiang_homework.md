Backup codes that wrote at university
