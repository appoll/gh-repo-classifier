mysql-marinate
==============

Homework for the MySQL Marinate class

The master list for MySQL Marinate Season 1, Jan-Apr 2013, is at:
http://www.meetup.com/Virtual-Tech-Self-Study/messages/boards/thread/27694982

The master list has links to the discussion threads for each chapter.

If you have a private question, please contact the group organizer for the meetup group as posted above.
