

`Machine` is a singleton that syncs the value
of chocoroles, gansitos, pinguinos that exists on a certain time.

`Stage` is the main class where the three threads are defined.

javac *.java

