# quantecon_nyu_2016_homework

Homework for the NYU spring semester computational economics course.  This
repo is only for homework submissions.  The assignments are available from
the [course homepage](https://github.com/jstac/quantecon_nyu_2016).
