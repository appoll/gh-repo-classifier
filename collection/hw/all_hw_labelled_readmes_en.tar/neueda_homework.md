# Neueda Homework

* [For Java developers](mindmap)
* [For web developers](testevents)
* [For test automators](puzzlers)
* [For NoSQL developers](database)
* [For DevOps specialists](devops)
