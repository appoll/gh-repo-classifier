##Homework

[Homework 6](https://github.com/NGSAnalysisOnBeocatClass/homework/blob/master/homework_6.md)

Write a Perl script to reverse complement a wrapped FASTA file.
