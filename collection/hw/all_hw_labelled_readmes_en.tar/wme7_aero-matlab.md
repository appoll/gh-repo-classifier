Aero-matlab repository

This GIT repo is just a version control for most of my matlab files
If you find something usefull in it, feel free to grab it ^^.
cheers

Contact us at:
Diaz's Software Mill
http://manuel.diaz-soft.com/
manuel@diaz-soft.com (sales, distribution requests, administration)
support@diaz-soft.com (bugs, problems, questions)
800/555-1212 (M-F, 9 AM-4 PM PST)
