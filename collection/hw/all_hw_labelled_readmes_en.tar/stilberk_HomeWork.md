# Multidimensional Arrays, Sets, Dictionaries

My C# Advanced HomeWorks 
<br></br>
This is my home work for the course C# Advanced in Software University https://softuni.bg
<p>Link to the tasks <a href="https://softuni.bg/downloads/svn/csharp-advanced/Sept-2015/2.%20Advanced-CSharp-MultidimensionalArrays-Sets-Dictionaries-Homework.docx">here</a></p>