CS171 2015 Homework Assignments
===

Homework assignments for Harvard's [CS171](http://www.cs171.org/2015/index.html) 2015. To receive homework updates on your local machine run:

```
git pull homework master
```

For details on how to submit your work, take a look at [Section 1](https://github.com/CS171/2015-cs171-homework/tree/master/section1).

---
**Name**:

**Email**:
