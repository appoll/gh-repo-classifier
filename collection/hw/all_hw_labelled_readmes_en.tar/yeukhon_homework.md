homework
========

Seriously: I don't care if people are copying my homework because who isn't these days. If copying my code helps you udnerstand and further your career, that's great!
