My homework for:
APD: Parallel and Distributed Algorithms
EGC: Computer Graphics
LFA: Automata and Formal Languages

1APD - OpenMP
2APD - Java
3APD - MPI

EGC - C++ using Microsoft Visual Studio 2008
