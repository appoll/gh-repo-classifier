The makeFilePath function and ggLionearity.R, ggNormality.R, 
and the ggHomoscedastic.R scripts are found in the folder
DiahnosticPLots.