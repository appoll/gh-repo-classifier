BEWD\_NYC\_5_Homework
===================

1. Fork this repo to your Github account
   ![image](fork-image.png)
   
2. Clone the forked repo from your Github account
   `git clone {the https clone url}`
   ![image](clone-image.png)
   
3. Create a folder named after you inside the "BEWD\_NYC\_5_Homework" folder
4. Touch a file inside your folder named `hi_five` 
5. Stage, commit and push your changes to your cloned repo.
  ``` git push origin master``` to push your changes
6. Return to [the original homework repo](https://github.com/ga-students/BEWD_NYC_5_Homework)
7. Make a "Pull Request" from your forked repo to the original homework repo
   ![image](pull-request-image.png)
   
   ![image](compare-across-forks.png)
8. Pat yourself on the back
