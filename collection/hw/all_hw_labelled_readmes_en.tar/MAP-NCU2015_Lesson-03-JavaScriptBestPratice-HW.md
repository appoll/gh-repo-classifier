# The slides

[Follow this link](https://docs.google.com/presentation/d/1ofgD63SENpiihJ_MIYyZVW2TM11Mo-qwcstDbZytqIo/edit?usp=sharing)
