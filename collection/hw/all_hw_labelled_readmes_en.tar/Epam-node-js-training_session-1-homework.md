session-1-homework
==================

Write a simple file server

* Should serve static content from the app folder
* Handle subdirectories correctly
* Use correct MIME type

!CHANGE NAME IN PACKAGE.JS TO YOURS!
