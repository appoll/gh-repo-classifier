## Homework
A web project based on thinkphp framework.The teacher can publish homework,collect homework and so on.The student can check homework,upload homework and so on.

## Introduction

* teacher
	* login/logout
	* choose courses
	* publish homework
	* collect homework attachment
	* comment
	* messages
* student
	* login/logout
	* check course
	* check homework
	* upload homework attachment
	* messages
	* view points