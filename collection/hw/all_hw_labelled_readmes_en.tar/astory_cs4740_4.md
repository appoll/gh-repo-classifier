Question Answering System
========

This project is homework for Cornell's CS 4740 class. Its source is open,
but you might not want to copy it until the end of the semester, in May 2011.

Baseline
---------

The baseline system extracts random answers and
submits them to the online scorer. It can be run
with zero.py like so.
$ ./zero.py [netid]
