# cnn-for-captcha


This is a project that use convolutional neural networks to recognize captcha from cmfcc website.

The whole architecture is based on the paper [CAPTCHA Recognition with Active Deep Learning](https://www.researchgate.net/publication/301620459_CAPTCHA_Recognition_with_Active_Deep_Learning) and this toturial [zhihu](https://zhuanlan.zhihu.com/p/21344595)

