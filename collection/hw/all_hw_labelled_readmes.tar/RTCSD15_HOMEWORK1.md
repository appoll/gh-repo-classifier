# HOMEWORK1
第一次编程作业
#操作步骤#
 - 用自己的账号登陆Github
 - fork按钮拷贝https://github.com/RTCSD15/HOMEWORK1 到你的账户下
 - 用自己的学号建立子目录如U2012xxxxx
 - 在自己的子目录下添加自己的第一次作业代码文件。
 - 用pull request提交作业
