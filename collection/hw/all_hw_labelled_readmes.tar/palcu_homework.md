homework
========

Temele mele și cod de la laboratoare sau teste. Sunt student la Facultatea de Matematica si Informatica din București. Dacă le prezinți la o materie sau îți folosesc, aștept să primesc o bere.
