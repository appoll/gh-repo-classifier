# 2. Homework

## Deadline 31.03

## Requirements

1. Start from your web application idea and your first homework
2. Add important functionalities to your application:
* everything you insert/add through submitting form gets saved to database (use phpMyAdmin in greeny to setup your table)
* show user database insertions (for example you have a page with table showing contents)
* enable deleting/archiving for inserted items ("x" button and for example mark column deleted to NOW())
* add [Bootstrap](http://getbootstrap.com) design to your app
