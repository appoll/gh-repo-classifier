# 2015-dataviscourse-homework
Homework material for 2015 Data visualization course. 
