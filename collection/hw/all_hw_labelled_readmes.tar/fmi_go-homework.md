go-homework
===========

Homework assignments for the Go course in FMI 
