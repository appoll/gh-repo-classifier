Coursera exercices
==================