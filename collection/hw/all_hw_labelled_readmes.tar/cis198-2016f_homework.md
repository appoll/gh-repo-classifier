# CIS 198 Homework - Fall 2016

This repo stores the homework assignments for CIS 198.

We are using Classroom for GitHub. That means each student can create a private
GitHub repository to do their work in. Except for hw0 (which has almost no
submitable content), these links are public for anyone to use! If you're a Penn
student enrolled in the class, this is also how you submit assignments: just
push to your repository by the due date.

Pull requests or issues are welcome and highly appreciated!
