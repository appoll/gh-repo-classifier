ntu-homework
============
qcl's homeworks

qcl 將會陸續整理過去的作業彙整至此。

#2013 Fall (102-1)

* Big Data System 巨量資料系統 *進行中*
* Machine Learning 機器學習 *進行中*

#2013 Spring (101-2)

* Parallel Programming 平行程式設計 *準備中*
* Digital Humanities 數位人文導論 *準備中*
* **Music Signal Analysis and Retrieval 音樂訊號分析與檢索**

#2012 Fall (101-1)

* **Complexity 康普雷射體**
* Multimedia Analysis and Indexing 多媒體資訊分析與檢索 *準備中*
* Natural Language Processing 自然語言處理 *準備中*
* **I-ching 《易經》**

#2012 Spring (100-2)

* **Economics 經濟學原理（下）**
* **Financial Computing 財務演算法**
* Information Retrieval and Extraction 資料檢索與擷取 *準備中*
* Surveying and Geomatics 測量及空間資訊導論 *準備中*

#2011 Fall (100-1)

* Design Patterns 軟體設計模式 *準備中*
* Game Programming 遊戲設計 *準備中*
* Mobile Phone Programming 手機程式設計 *準備中*
* Web Retrieval and Mining 網路資訊檢索與探勘 *準備中*
* Database 資料庫系統 *準備中*

#2011 Spring (99-2)

* **Compiler 編譯程式設計**
* Advanced Computer Programming 高等程式設計
* **Computer Network 計算機網路**

#2010 Fall (99-1)

* Operating System 作業系統

#2010 Spring (98-2)

* Object-Oriented Software Design 物件導向程式設計
* Design Patterns and Software Development 設計模式與軟體開發
* Systems Programming 系統程式

#2009 Fall (98-1)

* Introduction to Computer Programming 計算機程式設計
* Engineering Graphics 工程圖學
* Computer Organization and Assembly Languages 計算機組織與組合語言

#2009 Spring (97-2)

* Computer Programming 計算機程式

#2008 Fall (97-1)

