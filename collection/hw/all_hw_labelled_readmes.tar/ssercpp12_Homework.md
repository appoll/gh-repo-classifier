Homework
========

Homework result for 12 sser cpp