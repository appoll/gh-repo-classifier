# My Coursera courses

- Cloud Computing - Concepts 1
- Learn to Program: Crafting Quality Code
- POSA: Pattern-oriented Software Architecture
- Stanford Algorithms 1

