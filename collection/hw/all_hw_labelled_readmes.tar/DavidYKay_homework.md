Collection of assignments
