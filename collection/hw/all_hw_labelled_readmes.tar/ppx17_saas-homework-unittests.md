saas-homework-unittests
=======================
This repository contains unittests to quickly check if you implemented the assignments correctly.

For this to work you must place the testcases and the testsuite next to your code files. 
The code files should be named part1.rb, part2.rb etc.

To run the tests you simply execute ts_homework.rb in the Terminal view.