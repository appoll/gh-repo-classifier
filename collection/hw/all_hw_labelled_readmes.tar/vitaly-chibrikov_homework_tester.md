# homework_tester
Automated tests of homework exercises
