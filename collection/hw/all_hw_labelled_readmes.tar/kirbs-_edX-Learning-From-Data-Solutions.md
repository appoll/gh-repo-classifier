edX: Learning From Data Solutions
================================
Working implementations for each week's assignment in a variety of programming languages. Solutions are posted each week shortly after the due date. Please report any issues through the issue tracker.

Want To Contribute?
----------
Pull requests are preferred. However, if you aren't familar with git, you can post your code in a solutions thread in the edX discussion form.

Questions
-----------
Please direct any implementation questions to the edX discussion forums.

Contributors
-----------
* kirbs- (Python)
* henryf (PHP)
* kusimari (Scala)
* BartoszKP (Python)
* danielfmt (Octave)
* Xelio (Javascript)
* Rodic (OCaml)
* davluangu (MATLAB)
* bast0079 (Java)
* fredParis (R)
* PedroCV (MATLAB)
* FranckDernoncourt (Python)
* sanealytics (R)
* akashsadashivapeth (MATLAB)
* SamLau (Octave)
* stochastictinker (C#)
* AnantSogani (R)
* Victoras (C++)
* fedelebron (Haskell)
* Legendre (Mathmatica)
* danimauri (Python)
* Mark_B2 (Python)
* kanhua (MATLAB)
