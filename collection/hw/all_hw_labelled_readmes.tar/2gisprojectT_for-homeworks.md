for-home-works
==============
[![Build Status](https://travis-ci.org/2gisprojectT/for-homeworks.svg?branch=master)](https://travis-ci.org/2gisprojectT/for-homeworks)

Репозиторий для отправки домашних заданий

1. Заходим в issues
2. Добавляем новый issue с описанием того, что и где нужно посмотреть
3. Переписка по домашнему заданию ведется в issue
4. Если issue закрывается, значит домашняя работа сделана
