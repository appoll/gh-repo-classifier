# Assignment 1

Complete the assignment as described in [hw1.pdf](hw1.pdf).


You can find the general workflow for completing and submitting homeworks in [CourseDescription](https://github.com/Bogazici-CMPE548-Spring2016/CourseDescription).
