GettingAndCleaningData
======================

Repository for Coursera course [Getting and Cleaning Data](https://class.coursera.org/getdata-002). See README.md files in individual folders.
