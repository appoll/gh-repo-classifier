using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStructures
{
    class Program
    {
        static void Main(string[] args)
        {
            int iInput;



            Console.WriteLine("1. Stack\n 2.Queue\n 3. Dictionary\n 4.Exit");
            iInput = Console.Read();

            if(iInput == 1)
            {
                Console.WriteLine();
            }
            else if(iInput == 2)
            {

            }
            else if(iInput == 3)
            {

            }
            else if (iInput == 4)
            {

            }



        }
    }
}
