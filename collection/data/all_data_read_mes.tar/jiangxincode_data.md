* ubuntu-14.04-codeblocks-default.conf # need backup timely
* windows-8.1-codeblocks-default.conf # need backup timely
* CUSTOM.DIC # Microsoft Word Dictionary
* openmpi-1.8.4_install.log # the installation of the openmpi-1.8.4 on Ubuntu 14.04
* Makefile.template # the template of Makefile
* grep_sed_awk_exercise
* UnixFamily
* browser.html
* PLLPS.md # Programming Languages Learning Pass Standard
* garbage_remove.bat # remove the garbage in your windows system
* export_software_list.bat # 导出的安装程序为注册表中有注册值的安装版程序(不包括绿色软件)
* duduvpn # Some VPN addresses
* texlive/ # Some config files for texlive.
* new_vimrc # For Vim
* .gitattributes # For git
* .gitignore # For git
* README_TEMPLATE.md # the template for README
* FileZilla.xml # Some configuration of FileZilla
* server.info # The information of the server
+ shortcut.md # Some shortcuts

