Resumes of people in the intelligence community and some tools for analysis and counting.
