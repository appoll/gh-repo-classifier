This is the notes of data mining with r. 
please refer to:
http://www.liaad.up.pt/~ltorgo/DataMiningWithR
Thanks goes to the author.
20111203