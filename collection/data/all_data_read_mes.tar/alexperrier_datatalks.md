# Data Talks

This repo contains some of my Machine Learning code.
Kaggle and Driven Data competitions.
Mostly R and Python

This is a work in progress and I just recently started building this new code portfolio.

**Available scripts:**

* Driven Data blood donation competition

  * Data set exploration
  * Feature importance selection and engineering.

* Kaggle Liberty Mutual Competition

  * Stacking script example

* Twitter: Topic Modeling of Twitter Followers

  * Extract tweets from the followers of an account
  * LDA Topic Modeling
  * Notebook on http://nbviewer.ipython.org/github/alexperrier/datatalks/blob/master/twitter/LDAvis.ipynb#topic=18&lambda=0.59&term=



