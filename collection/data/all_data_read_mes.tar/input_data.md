Mmm... input data

http://drupal.org/user/96416
