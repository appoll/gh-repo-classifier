#Data
Data analysis related projects.  The initial focus is on processing that
occurs in Apache Crunch pipelines.
