# data
Data from public resources and their analysis.
