data
====

Raw data for Chad Skelton's data journalism projects.
http://blogs.vancouversun.com/category/staff/news/the-data-trail/
