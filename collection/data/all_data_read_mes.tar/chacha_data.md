General Data
===========

This is a collection of various data points I've acquired over the years.
