## [Devenez Data-Scientist](https://ondemand.lewagon.org/tracks/devenez-data-scientist/go) avec [Le Wagon On Demand](https://ondemand.lewagon.org)

### Installation

Choisissez votre système d'exploitation pour accéder aux étapes :

- [OS X](setup/OSX.md)
- [Windows](setup/WINDOWS.md)
