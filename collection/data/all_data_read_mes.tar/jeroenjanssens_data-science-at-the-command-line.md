Data Science at the Command Line
================================

![Data Science at the Command Line Cover](book/.cover.png)

This repository contains the virtual machine, data, scripts, and custom command-line tools used in the book [Data Science at the Command Line](http://datascienceatthecommandline.com).
## License

BSD 2-Clause
