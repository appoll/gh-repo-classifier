Data from top Github users
=====================

According to a series of conditions, mainly the city that they list in their profile. Check out the source for updates.


Hecho usando el API de GitHub ([datos en otro directorio](https://github.com/JJ/top-github-users-data/tree/master/data), [script](https://github.com/JJ/top-github-users)) adaptado de [@paulmillr](http://twitter.com/paulmillr) con contribuciones de  [@lifesinger](http://twitter.com/) y adaptación de JJ con contribuciones de Benito Palacios [Benito Palacios @pleonex](http://twitter.com/pleonex). Actualizado de vez en cuando. 

This has been done using the GitHub API ([data directory](https://github.com/JJ/top-github-users-data/tree/master/data), [script project](https://github.com/JJ/top-github-users)) adapted from [@paulmillr](http://twitter.com/paulmillr) work with contributions from [@lifesinger](http://twitter.com/) and adaptation by JJ with contributions from [Benito Palacios @pleonex](http://twitter.com/pleonex). Updated from time to time.

Index
-----

* [alt-Spain](formatted/top-alt-Spain.md)

# Provincias (y otros)#
* [Álava](formatted/top-Álava.md)
* [Albacete](formatted/top-Albacete.md)
* [Alicante](formatted/top-Alicante.md)
* [Almería](formatted/top-Almería.md)
* [Asturias](formatted/top-Asturias.md)
* [Ávila](formatted/top-Ávila.md)
* [Badajoz](formatted/top-Badajoz.md)
* [Baleares](formatted/top-Baleares.md)
* [Barcelona](formatted/top-Barcelona.md)
* [Bilbao](formatted/top-Bilbao.md)
* [Burgos](formatted/top-Burgos.md)
* [Cáceres](formatted/top-Cáceres.md)
* [Cádiz](formatted/top-Cádiz.md)
* [Cantabria](formatted/top-Cantabria.md)
* [Castellón](formatted/top-Castellón.md)
* [Ceuta](formatted/top-Ceuta.md)
* [Ciudad Real](formatted/top-Ciudad Real.md)
* [Córdoba](formatted/top-Córdoba.md)
* [Coruña](formatted/top-Coruña.md)
* [Cuenca](formatted/top-Cuenca.md)
* [Donostia](formatted/top-Donostia.md)
* [España](formatted/top-España.md)
* [Gerona](formatted/top-Gerona.md)
* [Granada](formatted/top-Granada.md)
* [Huelva](formatted/top-Huelva.md)
* [Huesca](formatted/top-Huesca.md)
* [Jaén](formatted/top-Jaén.md)
* [Las Palmas](formatted/top-Las Palmas.md)
* [León](formatted/top-León.md)
* [Lleida](formatted/top-Lleida.md)
* [Lugo](formatted/top-Lugo.md)
* [Madrid](formatted/top-Madrid.md)
* [Málaga](formatted/top-Málaga.md)
* [Melilla](formatted/top-Melilla.md)
* [Murcia](formatted/top-Murcia.md)
* [Navarra](formatted/top-Navarra.md)
* [Orense](formatted/top-Orense.md)
* [Palencia](formatted/top-Palencia.md)
* [Pontevedra](formatted/top-Pontevedra.md)
* [Rioja](formatted/top-Rioja.md)
* [Salamanca](formatted/top-Salamanca.md)
* [Segovia](formatted/top-Segovia.md)
* [Sevilla](formatted/top-Sevilla.md)
* [Tarragona](formatted/top-Tarragona.md)
* [Tenerife](formatted/top-Tenerife.md)
* [Teruel](formatted/top-Teruel.md)
* [Toledo](formatted/top-Toledo.md)
* [Valencia](formatted/top-Valencia.md)
* [Valladolid](formatted/top-Valladolid.md)
* [Zamora](formatted/top-Zamora.md)
* [Zaragoza](formatted/top-Zaragoza.md)
