an assignment of database curriculum design.

The file data.txt includes all the datasets, not too many thanks to my teacher who sent me the file. All I have to do is pick a pattern (client/server or browser/server respectively) to realize these basic requirements such as altering, deleting, adding, searching. A report form is also needed.
I am trying to design the assignment with Django which is a prevalent Python Web framework . 
Here is a list of python packages <code>pip freeze</code>
Django==1.8.2
django-report-builder==3.2.0
django-report-utils==0.3.13
django-suit==0.2.15
djangorestframework==3.3.1
image==1.4.1
jdcal==1.2
mechanize==0.2.5
openpyxl==2.2.1
Pillow==3.0.0
pysqlite==2.8.1
python-dateutil==2.4.2
six==1.10.0
wheel==0.26.0

Attention:
data/settings.py   STATIC_ROOT="/home/skywhat/dj/data/admin_static/"
