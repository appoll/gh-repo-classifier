# Total WordPress Theme Sample Data
<p>This is the sample data files for the <a href="http://themeforest.net/item/total-responsive-multipurpose-wordpress-theme/6339019?ref=WPExplorer" title="Total WordPress Theme".>Total WordPress Theme</a> and has been made accessable for buyers. Please purchase the theme first before using the sample data, if you are using an illegal copy of the theme you will most likely encounter many errors while importing the files.</p>

<p>If you have any questions, feel free to <a href="http://wpexplorer-themes.com/total/support/">contact us</a> for support.</p>


## Important
<p>You must extract the zip after downloading and select only the file you wish to import, which will depend if you are importing main sample data, templatera templates sliders or theme options.

### Base
The MASSIVE sample data from the base demo - http://totaltheme.wpengine.com/base/
Takes a long time to upload and some servers may not be able to handle it

### Base Essential
Slimmed down version of the base demo that will import quickly - http://totaltheme.wpengine.com/base-essential/
Should import very quickly and doesn't include demo-only pages and bbPress forums

### Demos
Custom demos - http://wpexplorer-themes.com/total/demos/
