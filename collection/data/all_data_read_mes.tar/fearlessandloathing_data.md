# data

So far the best way I can think to share what has been pulled together is via Google Drive. Some of it is still in PDFs and need work. A number of them are in spreadsheets which maybe need a bit of tidying. 

Here's the public link: [F+L Project: Data - Google Drive](https://drive.google.com/folderview?id=0B9yrZOy5KQw7fjFXUVl4SGZPTDRRLWktMU9kNFptaElwY2JNdzdsWVpOek9NaE0xV3JweTQ&usp=sharing)

All of the data so far comes from Oberlin's Office of Institutional Research and is publicly available at [http://oberlin.edu/instres/irhome/](http://oberlin.edu/instres/irhome/). FYI: site uses frames(?!).
