# Databus

NREL works off of this repository for databus development.  

Click the Documentation link to get started on installation if you are going to try it out

1. [Energy Databus Documentation(and support available)](http://buffalosw.com/products/databus/databus-documentation/)
1. [Energy Databus Community Forum](http://en.openei.org/community/group/databus) - Where General Users can get help
1. [Energy Databus Forum for Developers or Chart Creators](https://github.com/deanhiller/databus/wiki/Developer-Support-Forums)
1. [Energy Databus Partners(they can help and support you)](http://en.openei.org/wiki/NREL_Energy_DataBus/Partners)

If something is not being addressed in the forums, you can email us at databus@nrel.gov **with the link to the forum post** and we will make sure someone responds to the forum.


