This folder is used to share some docs and code with different OS on my computer.
