Grails Datastore API
===

This repository has moved to the [Grails][Grails] Github organization.

[Grails]: https://github.com/grails/grails-data-mapping


