data
====

Data that does not need to be cloned to use the code