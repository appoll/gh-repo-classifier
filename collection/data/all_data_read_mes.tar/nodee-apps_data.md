
![MIT License][license-image]
[![Build Status][travis-image]][travis-url]

# Group, synchronize, compare data feeds

Simple, but powerfull lib for working with data feeds

## Installation
```
npm install nodee-data
```

[license-image]: https://img.shields.io/badge/license-MIT-blue.svg?style=flat
[license-url]: license.txt

[travis-url]: https://travis-ci.org/nodee-apps/data
[travis-image]: https://travis-ci.org/nodee-apps/data.svg?branch=master