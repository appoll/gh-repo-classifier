# data-vis
Data used in our papers, mainly from old ones, released under a free license
