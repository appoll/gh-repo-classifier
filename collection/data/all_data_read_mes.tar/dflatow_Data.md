# Data
This repo contains instructions for how to download data that I'm sharing with the public.

## NYC Twitter Geotagged Data
* twitter_geo/tweets.csv.gz
