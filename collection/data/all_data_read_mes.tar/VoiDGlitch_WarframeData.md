# WarframeData
This repository is an assemblage of data files that have been extracted and parsed from the WARFRAME application. Warning, this may contain spoilers.

This repository was inaugurated to reveal all of the private information that is stored in the WARFRAME application. If you use this repository as a source of anything that you post, claim, or argue, please accredit it. This will allow it to become more accessible to uninformed users.

# Warning
This repository violates the Terms of Service Agreement. Because of this, it is not recommend that you leave a link to this repository
or mention any entries you find within it on official WARFRAME websites (such as Forums - Warframe Forums) because it could result
in your thread being locked and/or deleted AND you could possibly receive a warning.
