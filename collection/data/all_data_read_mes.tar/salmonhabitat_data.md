Issues for [Project SHARE](http://salmonhabitat.org)'s datasets.
