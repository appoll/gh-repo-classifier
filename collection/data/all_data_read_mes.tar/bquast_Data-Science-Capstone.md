Data-Science-Capstone
=====================

The Swiftkey Capstone project for the Coursera Data Science Specialization.
