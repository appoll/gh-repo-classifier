# data
data python notes ideas

Here is a genral place at the moment for my ideas concerning a cross platform solution for GUI apps
And more particularly a cross platform hosting solution for Quick-Books running on VMs on OSX, Linux and Windows.
