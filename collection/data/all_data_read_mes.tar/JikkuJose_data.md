# Data

Repo for collectiing various data as flat files for easy grepping.

## Data sets:

File      | Remarks
--------- | ----------------
words     | Unix words' list
thesaurus | Moby Thesaurus
