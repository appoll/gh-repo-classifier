File blk2010.zip
----------------

File blk2010.zip is derived from the US 2010 Census database and contains 6,207,027 records of the census blocks
with non-zero population in all 50 States and the District of Columbia (compressed zip file).

Each record contains 4 fields separated by commas:

* GeographicID - concatenation of STATE+COUNTY+TRACT+BLOCK
* Latitude - decimal degrees
* Longitude - decimal degrees
* Population - positive integer number

File places2014.zip
-------------------

File places2014.zip is derived from the US Board on Geographic Names Populated Places Gazetteer (August 2014)
and contains 180,331 records (compressed zip file).

Each record contains 7 fields separated by commas:

* State Code
* County Code
* State 2-letter USPS Code
* County Name
* Place Name
* Latitude - ddmmss{N|S}
* Longitude - dddmmss{E|W}
