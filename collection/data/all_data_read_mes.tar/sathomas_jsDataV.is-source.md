jsDataV.is-source
=================

This repository contains source code for data visualizations on the [jsDataV.is](http://jsDataV.is) site, including those used as examples in the book [_Data Visualization with JavaScript_](http://www.nostarch.com/datavisualization). All code is available under MIT license and can be freely used without attribution (though attribution is always welcome).

> Note: Chapters 8, 9, and 10 in the print and ebook versions (appendices A and B in the online version) are combined in a single `running` folder.
