# data

Sample data to test oryx project

1. [sample of the Audioscrobbler data set](http://raw.github.com/wiki/cloudera/oryx/datasets/audioscrobbler-sample.csv.gz)
