Gopher listing for [gophertown.org](http://gophertown.org)
==========================================================

To add yourself:
   - fork this repo,
   - copy`template.json` to `data/USERNAME.json` (USERNAME *must* be your github username).
   - edit data/USERNAME.json
   - submit a pull request

After your PR has been merged, you should appear almost immediately.  Your
profile link will be gophertown.org/USERNAME .
