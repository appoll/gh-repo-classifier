Doing Data Science
==================

This is the sample dataset that accompanies Doing Data Science by Cathy O'Neil and Rachel Schutt (9781449358655). 

Click the Download Zip button to the right to download the sample dataset.

Visit the catalog page [here](http://shop.oreilly.com/product/0636920028529.do).

See an error? Report it [here](http://oreilly.com/catalog/errata.csp?isbn=0636920028529), or simply fork and send us a pull request.

