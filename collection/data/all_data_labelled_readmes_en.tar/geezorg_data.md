Lexical Data Repository of the Ge'ez Frontier Foundation
========================================================
