# data
A host for all open data iniciatives led by Colombia.dev

## Directory
- salaries folder holds the raw data for the yearly income survey

## License

All data here is licensed to the public by [Juan Pablo Buriticá](http://github.com/buritica) and collaborators under a [Creative Commons Attribution-ShareAlike 4.0 International](https://creativecommons.org/licenses/by-sa/4.0/legalcode)
