data
====

Source data for the stop and frisk data api


### Contents

1. [Source databases converted from SPSS Portable files into CSV (geometry in original NY State Plane Projection)](https://github.com/stopfrisknyc/data/tree/master/src)
2. [Full consolidated 2003-2011 databases as a csv file, with geometry in WGS84 (EPSG:4326) projection](https://github.com/stopfrisknyc/data/tree/master/mod)
3. [Original metadata from NYPD](https://github.com/stopfrisknyc/data/tree/master/metadata)