GameSaveInfo.Data
===
The XML data files of game save locations that power both GameSave.Info and MASGAU. Licensed under GPLv2.
