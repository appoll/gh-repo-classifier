# NPMap Data

This repository contains data used in the NPMap team's projects. It is **not** the official source for any of the data it contains. You should visit the [NPS Data Store](https://irma.nps.gov/App/Reference/Welcome) to browse and download official datasets for the National Park Service.

## License

Unless otherwise noted, all data in this repository are available in the public domain.
