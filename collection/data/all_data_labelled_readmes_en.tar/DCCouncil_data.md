data
====

Some basic open data sets for the Council.

## What's inside?

For more information, check out the [wiki](https://github.com/DCCouncil/data/wiki).