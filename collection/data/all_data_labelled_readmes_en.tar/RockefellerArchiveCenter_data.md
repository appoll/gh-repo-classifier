# data
Rockefeller Archive Center's collection data. See `LICENSE.md` for specific license terms to this data as well as best practices.

## ead
Contains EAD files for finding aids available in [DIMES](http://dimes.rockarch.org/)

## mods
Contains MODS files for library records available in [DIMES](http://dimes.rockarch.org/)
