# data
Will be used to publically share all the data used for posts at our blog, http://harvardsportsanalysis.org/
