Data Collection 
====

* odp4espm.zip: This is the ODP dataset used in paper: Generating Categorical Semantic Path via Explicit Semantic Path Mining

* sohu-dataset: 抓取自sohu网站的1000个网页，附带标题、关键词、带格式的HTML正文内容，无格式的纯文本内容等信息，以XML格式保存。可用于关键词抽取测试。

